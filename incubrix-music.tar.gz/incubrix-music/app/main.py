"""FastAPI application: /api/v1 routes, health, readiness, rate limiting, correlation ids."""
from __future__ import annotations

import hashlib
import json
import logging
import os
import time
import uuid
from typing import Any, Optional
from urllib.parse import urlparse

from fastapi import FastAPI, File, Header, Request, Response, UploadFile
from fastapi.responses import JSONResponse

from .config import Settings, get_settings
from .db import Database
from .errors import ApiError, error_body, install_error_handlers
from .logging_setup import correlation_id_var, setup_logging
from .narration import NarrationError, validate_narration_ref
from .ratelimit import TokenBucketLimiter
from .schemas import (AssetUploaded, ErrorResponse, JobAccepted, JobStatus, MusicJobRequest, RegenerateStemRequest)
from .storage import Storage, StorageError

ERR = {c: {"model": ErrorResponse, "description": d} for c, d in {
    400: "Bad request or idempotency conflict", 404: "Not found", 422: "Validation error", 429: "Rate limited",
    500: "Internal error", 504: "Upstream timeout"}.items()}


def _hash(obj: Any) -> str:
    return hashlib.sha256(json.dumps(obj, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def create_app(settings: Optional[Settings] = None, storage: Optional[Storage] = None, db: Optional[Database] = None) -> FastAPI:
    s = settings or get_settings()
    log = setup_logging(s.log_level)
    app = FastAPI(title="IncuBrix AI Background Music Engine", version="1.0.0",
                  description="Deterministic bar-grid stem engine: prompt in, mix + four aligned stems + manifest out.")
    app.state.settings = s
    app.state.db = db or Database(s.sqlite_path)
    app.state.storage = storage or Storage(s)
    app.state.started = time.time()
    app.state.first_request_done = False
    limiter_all = TokenBucketLimiter(s.rate_limit_per_minute)
    limiter_jobs = TokenBucketLimiter(s.rate_limit_jobs_per_minute)
    install_error_handlers(app, log)

    @app.on_event("startup")
    def _startup() -> None:
        try:
            app.state.storage.ensure_bucket()
        except Exception as exc:  # noqa: BLE001 - readiness reports it
            log.warning("bucket check failed at startup", extra={"error": str(exc)[:150]})

    @app.middleware("http")
    async def _mw(request: Request, call_next):  # type: ignore[no-untyped-def]
        cid = request.headers.get("X-Correlation-Id") or uuid.uuid4().hex
        correlation_id_var.set(cid)
        t0 = time.perf_counter()
        cold = not app.state.first_request_done
        path = request.url.path
        if s.rate_limit_enabled and path.startswith("/api/v1"):
            ip = request.client.host if request.client else "unknown"
            if s.trust_proxy_headers and request.headers.get("X-Forwarded-For"):
                ip = request.headers["X-Forwarded-For"].split(",")[0].strip()
            checks = [limiter_all.check(ip)]
            if request.method == "POST":
                checks.append(limiter_jobs.check(ip))
            blocked = [r for ok, r in checks if not ok]
            if blocked:
                wait = max(blocked)
                resp: Response = JSONResponse(status_code=429, content=error_body(
                    "RATE_LIMITED", "Too many requests. Slow down and retry.", True, {"retry_after_s": round(wait, 1)}),
                    headers={"Retry-After": str(int(wait) + 1)})
                resp.headers["X-Correlation-Id"] = cid
                return resp
        response = await call_next(request)
        app.state.first_request_done = True
        response.headers["X-Correlation-Id"] = cid
        if cold:
            response.headers["X-Cold-Start"] = "true"
        log.info("request", extra={"method": request.method, "path": path, "status": response.status_code,
                                   "duration_ms": round((time.perf_counter() - t0) * 1000, 1)})
        return response

    def _idem(request_hash: str, scope: str, key: Optional[str]) -> Optional[tuple[str, str, str]]:
        if key is None:
            return None
        if not (1 <= len(key) <= 255) or not key.isprintable():
            raise ApiError(400, "IDEMPOTENCY_KEY_INVALID", "Idempotency-Key must be 1 to 255 printable characters.")
        return key, scope, request_hash

    def _mismatch() -> ApiError:
        return ApiError(400, "IDEMPOTENCY_KEY_MISMATCH", "This Idempotency-Key was already used with a different request body.")

    # ------------------------------------------------------------ health
    @app.get("/health", tags=["ops"], summary="Liveness")
    def health() -> dict[str, Any]:
        return {"status": "ok", "uptime_s": round(time.time() - app.state.started, 1)}

    @app.get("/ready", tags=["ops"], summary="Readiness: MinIO, worker, SoundFont", responses={503: {"model": ErrorResponse}})
    def ready() -> dict[str, Any]:
        beat, info = app.state.db.last_beat("worker")
        worker_ok = beat is not None and time.time() - beat < 20
        checks: dict[str, Any] = {"storage": "ok" if app.state.storage.ping() else "unreachable",
                                  "worker": "ok" if worker_ok else "no_heartbeat"}
        if s.music_provider == "fluidsynth_symbolic":
            from .providers.fluidsynth_symbolic import FluidSynthSymbolicProvider
            checks["soundfont"] = "ok" if FluidSynthSymbolicProvider(soundfont=s.soundfont_path).available() else "missing"
        else:
            checks["soundfont"] = "not_required"
        ok = all(v in ("ok", "not_required") for v in checks.values())
        cold = {"uptime_s": round(time.time() - app.state.started, 1), "worker_warmed_up": bool(info.get("warmed_up"))}
        if not ok:
            raise ApiError(503, "SERVICE_NOT_READY", "One or more dependencies are not ready.", True, {"checks": checks, **cold})
        return {"status": "ready", "checks": checks, "provider": s.music_provider, **cold, "jobs": app.state.db.counts()}

    # ------------------------------------------------------------ jobs
    @app.post("/api/v1/music/jobs", status_code=202, response_model=JobAccepted, responses=ERR, tags=["music"], summary="Create a music job")
    def create_job(body: MusicJobRequest, response: Response, request: Request,
                   idempotency_key: Optional[str] = Header(default=None, alias="Idempotency-Key")) -> JobAccepted:
        if not (s.min_duration_s <= body.duration_s <= s.max_duration_s):
            raise ApiError(422, "DURATION_OUT_OF_RANGE", f"duration_s must be between {s.min_duration_s:g} and {s.max_duration_s:g}.",
                           False, {"min": s.min_duration_s, "max": s.max_duration_s, "got": body.duration_s})
        for sec in body.sections or []:
            if sec.start_s < 0 or sec.start_s != sec.start_s:
                raise ApiError(422, "VALIDATION_ERROR", "section start_s must be >= 0.", False, {"section": sec.name})
        if body.narration_url:
            try:
                validate_narration_ref(body.narration_url, s)
            except NarrationError as exc:
                raise ApiError(422, exc.code, exc.message) from exc
        if body.callback_url:
            u = urlparse(body.callback_url)
            if u.scheme not in ("http", "https") or not u.netloc:
                raise ApiError(422, "INVALID_CALLBACK_URL", "callback_url must be an http(s) URL.")
        payload = body.model_dump(mode="json")
        h = _hash(payload)
        stored = dict(payload, _correlation_id=correlation_id_var.get())
        try:
            job, created = app.state.db.create_job("generate", stored, idem=_idem(h, "POST /api/v1/music/jobs", idempotency_key))
        except KeyError:
            raise _mismatch()
        response.headers["Location"] = f"/api/v1/jobs/{job['id']}"
        if not created:
            response.headers["Idempotent-Replayed"] = "true"
        return JobAccepted(job_id=job["id"], status=job["status"])

    @app.post("/api/v1/music/jobs/{job_id}/regenerate-stem", status_code=202, response_model=JobAccepted, responses=ERR, tags=["music"],
              summary="Regenerate one stem on the original grid")
    def regenerate(job_id: str, body: RegenerateStemRequest, response: Response,
                   idempotency_key: Optional[str] = Header(default=None, alias="Idempotency-Key")) -> JobAccepted:
        src = app.state.db.get_job(job_id)
        if not src:
            raise ApiError(404, "JOB_NOT_FOUND", f"No job with id {job_id}.")
        if src["status"] != "succeeded":
            raise ApiError(400, "SOURCE_JOB_NOT_SUCCEEDED", f"Source job is '{src['status']}'; only succeeded jobs can be regenerated.", src["status"] in ("queued", "running"))
        payload = dict(body.model_dump(mode="json"), source_job_id=job_id)
        try:
            job, created = app.state.db.create_job("regenerate_stem", dict(payload, _correlation_id=correlation_id_var.get()), parent_job_id=job_id,
                                                   idem=_idem(_hash(payload), f"POST regenerate-stem {job_id}", idempotency_key))
        except KeyError:
            raise _mismatch()
        response.headers["Location"] = f"/api/v1/jobs/{job['id']}"
        if not created:
            response.headers["Idempotent-Replayed"] = "true"
        return JobAccepted(job_id=job["id"], status=job["status"])

    @app.get("/api/v1/jobs/{job_id}", response_model=JobStatus, responses=ERR, tags=["music"], summary="Job status and download URLs")
    def get_job(job_id: str) -> dict[str, Any]:
        job = app.state.db.get_job(job_id)
        if not job:
            raise ApiError(404, "JOB_NOT_FOUND", f"No job with id {job_id}.")
        result = None
        warnings: list[str] = []
        if job["status"] == "succeeded" and job["result"]:
            try:
                files = {rel: app.state.storage.presign(key) for rel, key in job["result"]["files"].items() if not rel.startswith("internal/")}
            except StorageError as exc:
                raise ApiError(504, "STORAGE_UNAVAILABLE", "Could not create download URLs.", True) from exc
            result = {"files": files, "expires_in_s": s.presign_ttl_s}
            warnings = job["result"].get("warnings", [])
        return {"job_id": job["id"], "kind": job["kind"], "status": job["status"], "progress": job["progress"], "result": result,
                "error": job["error"], "warnings": warnings, "parent_job_id": job["parent_job_id"],
                "created_at": job["created_at"], "updated_at": job["updated_at"]}

    # ------------------------------------------------------------ uploads
    @app.post("/api/v1/assets/upload", status_code=201, response_model=AssetUploaded, responses=ERR, tags=["assets"], summary="Upload narration audio")
    def upload(file: UploadFile = File(...), idempotency_key: Optional[str] = Header(default=None, alias="Idempotency-Key")) -> AssetUploaded:
        data = bytearray()
        while chunk := file.file.read(1 << 20):
            data += chunk
            if len(data) > s.max_upload_bytes:
                raise ApiError(422, "ASSET_TOO_LARGE", f"Upload exceeds {s.max_upload_bytes} bytes.", False, {"max_bytes": s.max_upload_bytes})
        if not data:
            raise ApiError(422, "VALIDATION_ERROR", "Uploaded file is empty.")
        digest = hashlib.sha256(data).hexdigest()
        key = _idem(digest, "POST /api/v1/assets/upload", idempotency_key)
        if key:
            try:
                prior = app.state.db.reserve_key(*key)
            except KeyError:
                raise _mismatch()
            asset_id = hashlib.sha256((key[0] + digest).encode()).hexdigest()[:32]
            if prior:
                return AssetUploaded(**prior)
        else:
            asset_id = uuid.uuid4().hex
        try:
            app.state.storage.put_bytes(bytes(data), f"uploads/{asset_id}", file.content_type or "application/octet-stream")
            out = {"asset_id": asset_id, "asset_url": f"asset://{asset_id}", "size_bytes": len(data),
                   "download_url": app.state.storage.presign(f"uploads/{asset_id}")}
        except StorageError as exc:
            raise ApiError(504, "STORAGE_UNAVAILABLE", "Object storage is unavailable.", True) from exc
        if key:
            app.state.db.store_response(key[0], key[1], out)
        return AssetUploaded(**out)

    return app


app = None if os.environ.get("INCUBRIX_NO_AUTOAPP") else create_app()  # type: ignore[assignment]

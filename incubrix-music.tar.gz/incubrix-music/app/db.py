"""SQLite state shared by API and worker: jobs, idempotency keys, worker heartbeat.

SQLite in WAL mode with ``BEGIN IMMEDIATE`` transactions gives cross-process
locking, so concurrent identical requests with one Idempotency-Key create
exactly one job.
"""
from __future__ import annotations

import json
import sqlite3
import time
import uuid
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterator

SCHEMA = """
CREATE TABLE IF NOT EXISTS jobs (
  id TEXT PRIMARY KEY, kind TEXT NOT NULL, status TEXT NOT NULL, progress INTEGER NOT NULL DEFAULT 0,
  request_json TEXT NOT NULL, result_json TEXT, error_json TEXT, parent_job_id TEXT,
  created_at REAL NOT NULL, updated_at REAL NOT NULL, started_at REAL, finished_at REAL, attempts INTEGER NOT NULL DEFAULT 0);
CREATE INDEX IF NOT EXISTS jobs_status ON jobs(status, created_at);
CREATE TABLE IF NOT EXISTS idempotency (
  key TEXT NOT NULL, scope TEXT NOT NULL, request_hash TEXT NOT NULL, job_id TEXT, response_json TEXT, created_at REAL NOT NULL,
  PRIMARY KEY (key, scope));
CREATE TABLE IF NOT EXISTS heartbeat (name TEXT PRIMARY KEY, beat_at REAL NOT NULL, info_json TEXT);
"""


class Database:
    def __init__(self, path: str) -> None:
        self.path = path
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        with self._conn() as c:
            c.execute("PRAGMA journal_mode=WAL")
            c.executescript(SCHEMA)

    @contextmanager
    def _conn(self) -> Iterator[sqlite3.Connection]:
        conn = sqlite3.connect(self.path, timeout=30, isolation_level=None)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
        finally:
            conn.close()

    @contextmanager
    def _tx(self) -> Iterator[sqlite3.Connection]:
        with self._conn() as c:
            c.execute("BEGIN IMMEDIATE")
            try:
                yield c
                c.execute("COMMIT")
            except BaseException:
                c.execute("ROLLBACK")
                raise

    # ---------------------------------------------------------------- jobs
    @staticmethod
    def _row(r: sqlite3.Row | None) -> dict[str, Any] | None:
        if r is None:
            return None
        d = dict(r)
        for k in ("request_json", "result_json", "error_json"):
            d[k[:-5]] = json.loads(d.pop(k)) if d.get(k) else None
        return d

    def create_job(self, kind: str, request: dict[str, Any], *, parent_job_id: str | None = None,
                   idem: tuple[str, str, str] | None = None) -> tuple[dict[str, Any], bool]:
        """Create a job, honouring an optional (key, scope, request_hash) idempotency tuple.

        Returns (job, created). A reused key with a different request hash raises KeyError('mismatch').
        """
        now = time.time()
        with self._tx() as c:
            if idem:
                key, scope, h = idem
                row = c.execute("SELECT * FROM idempotency WHERE key=? AND scope=?", (key, scope)).fetchone()
                if row:
                    if row["request_hash"] != h:
                        raise KeyError("mismatch")
                    job = self._row(c.execute("SELECT * FROM jobs WHERE id=?", (row["job_id"],)).fetchone())
                    return job, False  # type: ignore[return-value]
            job_id = uuid.uuid4().hex
            c.execute("INSERT INTO jobs(id,kind,status,progress,request_json,parent_job_id,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)",
                      (job_id, kind, "queued", 0, json.dumps(request), parent_job_id, now, now))
            if idem:
                c.execute("INSERT INTO idempotency(key,scope,request_hash,job_id,created_at) VALUES(?,?,?,?,?)", (*idem[:3], job_id, now))
            job = self._row(c.execute("SELECT * FROM jobs WHERE id=?", (job_id,)).fetchone())
        return job, True  # type: ignore[return-value]

    def reserve_key(self, key: str, scope: str, request_hash: str) -> dict[str, Any] | None:
        """For non-job POSTs (uploads). Returns the stored response, or None if this is the first use."""
        now = time.time()
        with self._tx() as c:
            row = c.execute("SELECT * FROM idempotency WHERE key=? AND scope=?", (key, scope)).fetchone()
            if row:
                if row["request_hash"] != request_hash:
                    raise KeyError("mismatch")
                return json.loads(row["response_json"]) if row["response_json"] else None
            c.execute("INSERT INTO idempotency(key,scope,request_hash,created_at) VALUES(?,?,?,?)", (key, scope, request_hash, now))
        return None

    def store_response(self, key: str, scope: str, response: dict[str, Any]) -> None:
        with self._tx() as c:
            c.execute("UPDATE idempotency SET response_json=? WHERE key=? AND scope=?", (json.dumps(response), key, scope))

    def get_job(self, job_id: str) -> dict[str, Any] | None:
        with self._conn() as c:
            return self._row(c.execute("SELECT * FROM jobs WHERE id=?", (job_id,)).fetchone())

    def claim_next(self) -> dict[str, Any] | None:
        now = time.time()
        with self._tx() as c:
            r = c.execute("SELECT id FROM jobs WHERE status='queued' ORDER BY created_at LIMIT 1").fetchone()
            if not r:
                return None
            c.execute("UPDATE jobs SET status='running', progress=1, started_at=?, updated_at=?, attempts=attempts+1 WHERE id=?", (now, now, r["id"]))
            return self._row(c.execute("SELECT * FROM jobs WHERE id=?", (r["id"],)).fetchone())

    def requeue_stale(self, older_than_s: float) -> int:
        cutoff = time.time() - older_than_s
        with self._tx() as c:
            cur = c.execute("UPDATE jobs SET status='queued', progress=0 WHERE status='running' AND updated_at<? AND attempts<3", (cutoff,))
            c.execute("UPDATE jobs SET status='failed', finished_at=?, error_json=? WHERE status='running' AND updated_at<? AND attempts>=3",
                      (time.time(), json.dumps({"code": "JOB_ABANDONED", "message": "Worker stopped repeatedly while running this job.", "retryable": True, "details": {}}), cutoff))
            return cur.rowcount

    def set_progress(self, job_id: str, progress: int) -> None:
        with self._tx() as c:
            c.execute("UPDATE jobs SET progress=?, updated_at=? WHERE id=? AND status='running'", (progress, time.time(), job_id))

    def finish_ok(self, job_id: str, result: dict[str, Any]) -> None:
        now = time.time()
        with self._tx() as c:
            c.execute("UPDATE jobs SET status='succeeded', progress=100, result_json=?, updated_at=?, finished_at=? WHERE id=?",
                      (json.dumps(result), now, now, job_id))

    def finish_fail(self, job_id: str, error: dict[str, Any]) -> None:
        now = time.time()
        with self._tx() as c:
            c.execute("UPDATE jobs SET status='failed', error_json=?, updated_at=?, finished_at=? WHERE id=?", (json.dumps(error), now, now, job_id))

    # ---------------------------------------------------------------- heartbeat
    def beat(self, name: str, info: dict[str, Any] | None = None) -> None:
        with self._tx() as c:
            c.execute("INSERT INTO heartbeat(name,beat_at,info_json) VALUES(?,?,?) ON CONFLICT(name) DO UPDATE SET beat_at=excluded.beat_at, info_json=excluded.info_json",
                      (name, time.time(), json.dumps(info or {})))

    def last_beat(self, prefix: str = "worker") -> tuple[float | None, dict[str, Any]]:
        with self._conn() as c:
            r = c.execute("SELECT beat_at, info_json FROM heartbeat WHERE name LIKE ? ORDER BY beat_at DESC LIMIT 1", (prefix + "%",)).fetchone()
        return (r["beat_at"], json.loads(r["info_json"] or "{}")) if r else (None, {})

    def counts(self) -> dict[str, int]:
        with self._conn() as c:
            return {r["status"]: r["n"] for r in c.execute("SELECT status, COUNT(*) n FROM jobs GROUP BY status")}

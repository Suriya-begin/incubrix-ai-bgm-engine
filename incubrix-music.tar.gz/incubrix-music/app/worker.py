"""Background worker: claims queued jobs from SQLite, renders, uploads to S3, fires callbacks.

Run with ``python -m app.worker``. With WORKER_ISOLATION=process (default) each job runs in
a child process that is killed when it exceeds JOB_TIMEOUT_S.
"""
from __future__ import annotations

import json
import logging
import multiprocessing as mp
import shutil
import signal
import tempfile
import threading
import time
from pathlib import Path
from typing import Any

from .audio_io import AudioError
from .callbacks import deliver
from .config import Settings, get_settings
from .db import Database
from .logging_setup import correlation_id_var, job_id_var, setup_logging
from .narration import NarrationError, fetch_narration
from .storage import Storage, StorageError

log = logging.getLogger("incubrix.worker")


def _provider(s: Settings):
    from .providers.base import get_provider
    return get_provider(s.music_provider, soundfont=s.soundfont_path) if s.music_provider == "fluidsynth_symbolic" else get_provider(s.music_provider)


def run_pipeline(kind: str, req: dict[str, Any], job_id: str, work: str, settings_json: str) -> None:
    """Runs inside the child process (or inline). Writes work/child.json."""
    from . import pipeline
    s = Settings(**json.loads(settings_json))
    w = Path(work)
    try:
        prov = _provider(s)
        if kind == "generate":
            narr = w / "narration.bin"
            pipeline.generate(req, prov, w / "out", job_id=job_id, min_duration_s=s.min_duration_s, max_duration_s=s.max_duration_s,
                              usd_per_cpu_hour=s.compute_cost_usd_per_cpu_hour, narration_path=narr if narr.exists() else None)
        else:
            manifest = json.loads((w / "src" / "music_manifest.json").read_text())
            pipeline.regenerate_stem(w / "src", manifest, req["stem"], prov, w / "out", job_id=job_id, seed=req.get("seed"),
                                     prompt_override=req.get("prompt_override"), usd_per_cpu_hour=s.compute_cost_usd_per_cpu_hour)
        (w / "child.json").write_text(json.dumps({"ok": True}))
    except AudioError as exc:
        (w / "child.json").write_text(json.dumps({"ok": False, "error": {"code": "NARRATION_DECODE_FAILED", "message": str(exc), "retryable": False, "details": {}}}))
    except ValueError as exc:
        (w / "child.json").write_text(json.dumps({"ok": False, "error": {"code": "INVALID_REQUEST", "message": str(exc), "retryable": False, "details": {}}}))
    except Exception as exc:  # noqa: BLE001
        (w / "child.json").write_text(json.dumps({"ok": False, "error": {"code": "RENDER_FAILED", "message": f"{type(exc).__name__}: {exc}", "retryable": True, "details": {}}}))


class Worker:
    def __init__(self, s: Settings, db: Database, storage: Storage) -> None:
        self.s, self.db, self.storage = s, db, storage
        self.stop = threading.Event()
        self.warmed_up = False
        self.jobs_done = 0

    # ------------------------------------------------------------ lifecycle
    def warmup(self) -> None:
        """Render a short clip once so imports, filters and ffmpeg are hot before the first real job."""
        try:
            from . import pipeline
            from .providers.base import get_provider
            t0 = time.perf_counter()
            with tempfile.TemporaryDirectory() as td:
                pipeline.generate({"prompt": "warmup", "duration_s": 5, "seed": 1}, get_provider("mock"), td, job_id="warmup")
            self.warmed_up = True
            log.info("warmup complete", extra={"warmup_ms": round((time.perf_counter() - t0) * 1000)})
        except Exception:  # noqa: BLE001
            log.exception("warmup failed")

    def _heartbeat_loop(self, name: str) -> None:
        while not self.stop.is_set():
            self.db.beat(name, {"warmed_up": self.warmed_up, "jobs_done": self.jobs_done, "provider": self.s.music_provider})
            self.stop.wait(5.0)

    def run_forever(self) -> None:
        self.storage_ready()
        self.warmup()
        threads = [threading.Thread(target=self._loop, args=(i,), daemon=True) for i in range(max(1, self.s.worker_concurrency))]
        beat = threading.Thread(target=self._heartbeat_loop, args=("worker-main",), daemon=True)
        beat.start()
        for t in threads:
            t.start()
        log.info("worker started", extra={"concurrency": len(threads), "provider": self.s.music_provider})
        while not self.stop.is_set():
            self.stop.wait(1.0)

    def storage_ready(self) -> None:
        for attempt in range(30):
            try:
                self.storage.ensure_bucket()
                return
            except Exception as exc:  # noqa: BLE001
                log.warning("waiting for object storage", extra={"attempt": attempt, "error": str(exc)[:120]})
                time.sleep(2)

    def _loop(self, idx: int) -> None:
        last_sweep = 0.0
        while not self.stop.is_set():
            if time.time() - last_sweep > 60:
                self.db.requeue_stale(self.s.stale_job_after_s)
                last_sweep = time.time()
            job = self.db.claim_next()
            if not job:
                self.stop.wait(self.s.worker_poll_interval_s)
                continue
            self.process(job)

    # ------------------------------------------------------------ one job
    def process(self, job: dict[str, Any]) -> None:
        job_id = job["id"]
        job_id_var.set(job_id)
        correlation_id_var.set(job["request"].get("_correlation_id", "-"))
        t_start = time.perf_counter()
        work = Path(tempfile.mkdtemp(prefix=f"job_{job_id}_", dir=self._work_root()))
        try:
            log.info("job started", extra={"kind": job["kind"]})
            req = {k: v for k, v in job["request"].items() if not k.startswith("_")}
            if job["kind"] == "generate":
                if req.get("narration_url"):
                    fetch_narration(req["narration_url"], work / "narration.bin", self.s, self.storage)
            else:
                self._download_source(req["source_job_id"], work / "src")
            self.db.set_progress(job_id, 10)
            err = self._run(job["kind"], req, job_id, work)
            if err:
                raise _JobFailed(err)
            self.db.set_progress(job_id, 85)
            result, manifest = self._upload(job_id, work / "out", t_start)
            self.db.finish_ok(job_id, result)
            self.jobs_done += 1
            log.info("job succeeded", extra={"total_ms": round((time.perf_counter() - t_start) * 1000)})
            self._callback(job, "succeeded", result, None)
        except _JobFailed as exc:
            self._fail(job, exc.error)
        except NarrationError as exc:
            self._fail(job, {"code": exc.code, "message": exc.message, "retryable": exc.retryable, "details": {}})
        except StorageError as exc:
            self._fail(job, {"code": "STORAGE_ERROR", "message": f"Object storage failed: {str(exc)[:200]}", "retryable": True, "details": {}})
        except Exception as exc:  # noqa: BLE001
            log.exception("job crashed")
            self._fail(job, {"code": "INTERNAL_ERROR", "message": f"{type(exc).__name__}: {str(exc)[:200]}", "retryable": True, "details": {}})
        finally:
            shutil.rmtree(work, ignore_errors=True)
            job_id_var.set("-")

    def _work_root(self) -> str:
        Path(self.s.work_dir).mkdir(parents=True, exist_ok=True)
        return self.s.work_dir

    def _run(self, kind: str, req: dict[str, Any], job_id: str, work: Path) -> dict[str, Any] | None:
        settings_json = self.s.model_dump_json()
        if self.s.worker_isolation == "inline":
            run_pipeline(kind, req, job_id, str(work), settings_json)
        else:
            proc = mp.get_context("spawn").Process(target=run_pipeline, args=(kind, req, job_id, str(work), settings_json), daemon=True)
            proc.start()
            proc.join(self.s.job_timeout_s)
            if proc.is_alive():
                proc.terminate()
                proc.join(5)
                if proc.is_alive():
                    proc.kill()
                return {"code": "JOB_TIMEOUT", "message": f"Rendering exceeded {self.s.job_timeout_s}s and was stopped.", "retryable": True, "details": {}}
        marker = work / "child.json"
        if not marker.exists():
            return {"code": "RENDER_FAILED", "message": "Render process exited without a result.", "retryable": True, "details": {}}
        data = json.loads(marker.read_text())
        return None if data.get("ok") else data["error"]

    def _download_source(self, source_job_id: str, dest: Path) -> None:
        src = self.db.get_job(source_job_id)
        if not src or src["status"] != "succeeded":
            raise _JobFailed({"code": "SOURCE_JOB_NOT_SUCCEEDED", "message": "Source job is missing or not finished.", "retryable": False, "details": {}})
        files = src["result"]["files"]
        wanted = ["music_manifest.json", "internal/limiter_gain.npz"] + [f"stems/{s}.wav" for s in ("drums", "bass", "harmony", "melody")]
        for rel in wanted:
            local = dest / ("internal_limiter_gain.npz" if rel.startswith("internal/") else rel)
            self.storage.download_file(files[rel], local)

    def _upload(self, job_id: str, out: Path, t_start: float) -> tuple[dict[str, Any], dict[str, Any]]:
        manifest_path = out / "music_manifest.json"
        manifest = json.loads(manifest_path.read_text())
        rels: dict[str, Path] = {}
        for p in sorted(out.rglob("*")):
            if p.is_file():
                rel = p.relative_to(out).as_posix()
                rel = "internal/limiter_gain.npz" if rel == "internal_limiter_gain.npz" else rel
                rels[rel] = p
        media = [r for r in rels if r != "music_manifest.json"]
        t0 = time.perf_counter()
        for i, rel in enumerate(media):
            self.storage.upload_file(rels[rel], f"jobs/{job_id}/{rel}")
            self.db.set_progress(job_id, 85 + int(14 * (i + 1) / (len(media) + 1)))
        upload_ms = round((time.perf_counter() - t0) * 1000, 2)
        manifest["timings_ms"]["upload"] = upload_ms
        manifest["timings_ms"]["total"] = round(manifest["timings_ms"]["total"] + upload_ms, 2)
        manifest_path.write_text(json.dumps(manifest, indent=2))
        self.storage.upload_file(manifest_path, f"jobs/{job_id}/music_manifest.json")
        files = {rel: f"jobs/{job_id}/{rel}" for rel in rels}
        return {"files": files, "warnings": manifest.get("warnings", [])}, manifest

    def _fail(self, job: dict[str, Any], error: dict[str, Any]) -> None:
        log.error("job failed", extra={"error_code": error["code"]})
        self.db.finish_fail(job["id"], error)
        self._callback(job, "failed", None, error)

    def _callback(self, job: dict[str, Any], status: str, result: dict[str, Any] | None, error: dict[str, Any] | None) -> None:
        url = job["request"].get("callback_url")
        if not url:
            return
        files = {}
        if result:
            files = {rel: self.storage.presign(key) for rel, key in result["files"].items() if not rel.startswith("internal/")}
        payload = {"job_id": job["id"], "status": status, "result": {"files": files, "expires_in_s": self.s.presign_ttl_s} if result else None, "error": error}
        ok = deliver(url, payload, self.s.callback_secret, self.s.callback_timeout_s, self.s.callback_max_attempts)
        log.info("callback delivered" if ok else "callback gave up", extra={"callback_url_host": url.split("/")[2] if "//" in url else url})


class _JobFailed(Exception):
    def __init__(self, error: dict[str, Any]) -> None:
        super().__init__(error.get("message", ""))
        self.error = error


def main() -> None:
    s = get_settings()
    setup_logging(s.log_level)
    worker = Worker(s, Database(s.sqlite_path), Storage(s))
    signal.signal(signal.SIGTERM, lambda *_: worker.stop.set())
    signal.signal(signal.SIGINT, lambda *_: worker.stop.set())
    worker.run_forever()


if __name__ == "__main__":
    mp.freeze_support()
    main()

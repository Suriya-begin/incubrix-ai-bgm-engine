"""Signed webhook delivery. Header: X-IncuBrix-Signature: sha256=<hex HMAC of the raw body>."""
from __future__ import annotations

import hashlib
import hmac
import json
import logging
import time
from typing import Any

import httpx

log = logging.getLogger("incubrix.callback")


def sign(secret: str, body: bytes) -> str:
    return "sha256=" + hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()


def verify(secret: str, body: bytes, header: str) -> bool:
    return hmac.compare_digest(sign(secret, body), header or "")


def deliver(url: str, payload: dict[str, Any], secret: str, timeout_s: float, attempts: int) -> bool:
    body = json.dumps(payload, separators=(",", ":"), sort_keys=True).encode()
    headers = {"Content-Type": "application/json", "X-IncuBrix-Signature": sign(secret, body),
               "X-IncuBrix-Event": f"job.{payload.get('status', 'unknown')}"}
    for i in range(1, attempts + 1):
        try:
            r = httpx.post(url, content=body, headers=headers, timeout=timeout_s, follow_redirects=False)
            if r.status_code < 300:
                return True
            log.warning("callback rejected", extra={"status": r.status_code, "attempt": i})
        except httpx.HTTPError as exc:
            log.warning("callback failed", extra={"error": type(exc).__name__, "attempt": i})
        time.sleep(min(2 ** i, 10))
    return False

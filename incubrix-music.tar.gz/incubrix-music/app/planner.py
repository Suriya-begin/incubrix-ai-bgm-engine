"""Prompt and section planner.

Pure Python, no network, no paid keys. Maps a free-text prompt to musical
parameters with a keyword table plus a character-trigram fuzzy matcher
(a tiny deterministic "embedding"), then snaps tempo so a whole number of
4/4 bars equals ``duration_s`` exactly.
"""
from __future__ import annotations

import copy
import hashlib
import math
import re
import unicodedata
from typing import Any

BEATS_PER_BAR = 4
NOTE_NAMES = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]
FLAT_TO_SHARP = {"DB": "C#", "EB": "D#", "GB": "F#", "AB": "G#", "BB": "A#", "CB": "B", "FB": "E"}

MODES = {
    "major": [0, 2, 4, 5, 7, 9, 11],
    "minor": [0, 2, 3, 5, 7, 8, 10],
    "dorian": [0, 2, 3, 5, 7, 9, 10],
    "phrygian": [0, 1, 3, 5, 7, 8, 10],
    "lydian": [0, 2, 4, 6, 7, 9, 11],
    "mixolydian": [0, 2, 4, 5, 7, 9, 10],
}

W_VOCAL_REQUEST = "VOCAL_REQUEST_IGNORED: Service produces instrumental audio only."
W_ARTIST = "ARTIST_REFERENCE_SANITIZED: Generated original composition to ensure commercial copyright safety."

# --------------------------------------------------------------------------
# Mood table
# --------------------------------------------------------------------------
# bpm: default tempo, mode, prog: scale degrees (0-based) per bar, tonics: default keys
MOODS: dict[str, dict[str, Any]] = {
    "cinematic":   dict(bpm=78,  mode="minor",    prog=[0, 5, 2, 6], tonics=["D", "A", "C", "F"], gains=dict(drums=0.80, bass=0.90, harmony=0.80, melody=0.55)),
    "lofi":        dict(bpm=76,  mode="dorian",   prog=[1, 4, 0, 5], tonics=["F", "A#", "D#", "G"], gains=dict(drums=0.80, bass=0.85, harmony=0.70, melody=0.50)),
    "corporate":   dict(bpm=108, mode="major",    prog=[0, 4, 5, 3], tonics=["C", "G", "D", "A"], gains=dict(drums=0.80, bass=0.80, harmony=0.65, melody=0.60)),
    "electronic":  dict(bpm=124, mode="minor",    prog=[0, 5, 3, 4], tonics=["A", "F", "G", "D"], gains=dict(drums=0.95, bass=0.90, harmony=0.55, melody=0.55)),
    "acoustic":    dict(bpm=96,  mode="major",    prog=[0, 3, 4, 3], tonics=["G", "D", "C", "A"], gains=dict(drums=0.60, bass=0.80, harmony=0.75, melody=0.60)),
    "tense":       dict(bpm=100, mode="phrygian", prog=[0, 0, 1, 0], tonics=["E", "C#", "A", "D"], gains=dict(drums=0.80, bass=0.90, harmony=0.70, melody=0.45)),
    "playful":     dict(bpm=122, mode="major",    prog=[0, 3, 4, 3], tonics=["C", "F", "G", "D"], gains=dict(drums=0.80, bass=0.80, harmony=0.60, melody=0.65)),
    "energetic":   dict(bpm=132, mode="mixolydian", prog=[0, 6, 3, 0], tonics=["E", "A", "D", "G"], gains=dict(drums=1.00, bass=0.90, harmony=0.60, melody=0.60)),
    "calm":        dict(bpm=68,  mode="major",    prog=[0, 5, 3, 4], tonics=["C", "F", "G", "D"], gains=dict(drums=0.45, bass=0.75, harmony=0.85, melody=0.55)),
    "melancholic": dict(bpm=70,  mode="minor",    prog=[0, 3, 5, 4], tonics=["A", "D", "E", "C"], gains=dict(drums=0.50, bass=0.80, harmony=0.80, melody=0.60)),
}

# Style presets per mood. Timbre names are understood by the procedural
# provider; gm is the General MIDI program used by the FluidSynth provider.
STYLES: dict[str, dict[str, dict[str, Any]]] = {
    "cinematic":   dict(drums=dict(groove="cinematic", swing=0.0, timbre="kit_orch"), bass=dict(pattern="root_whole", timbre="sub", gm=43),
                        harmony=dict(rhythm="sustain", ext="add9", timbre="strings", gm=48), melody=dict(style="sparse", timbre="bell", gm=46)),
    "lofi":        dict(drums=dict(groove="lofi", swing=0.16, timbre="kit_lofi"), bass=dict(pattern="root_half", timbre="sub", gm=33),
                        harmony=dict(rhythm="half", ext="7", timbre="epiano", gm=4), melody=dict(style="sparse", timbre="vibes", gm=11)),
    "corporate":   dict(drums=dict(groove="backbeat", swing=0.0, timbre="kit_pop"), bass=dict(pattern="eighth", timbre="sub", gm=33),
                        harmony=dict(rhythm="stabs", ext="add9", timbre="piano", gm=0), melody=dict(style="pluck", timbre="bell", gm=9)),
    "electronic":  dict(drums=dict(groove="four_on_floor", swing=0.0, timbre="kit_electro"), bass=dict(pattern="offbeat", timbre="saw", gm=38),
                        harmony=dict(rhythm="pump", ext="7", timbre="supersaw", gm=90), melody=dict(style="arp", timbre="pluck", gm=81)),
    "acoustic":    dict(drums=dict(groove="folk", swing=0.04, timbre="kit_soft"), bass=dict(pattern="root_half", timbre="upright", gm=32),
                        harmony=dict(rhythm="strum", ext="none", timbre="guitar", gm=25), melody=dict(style="pluck", timbre="marimba", gm=73)),
    "tense":       dict(drums=dict(groove="pulse", swing=0.0, timbre="kit_orch"), bass=dict(pattern="sixteenth_pulse", timbre="sub", gm=38),
                        harmony=dict(rhythm="sustain", ext="sus2", timbre="strings", gm=50), melody=dict(style="sparse", timbre="bell", gm=98)),
    "playful":     dict(drums=dict(groove="bounce", swing=0.08, timbre="kit_pop"), bass=dict(pattern="eighth", timbre="pizz", gm=45),
                        harmony=dict(rhythm="stabs", ext="none", timbre="piano", gm=0), melody=dict(style="pluck", timbre="marimba", gm=12)),
    "energetic":   dict(drums=dict(groove="driving", swing=0.0, timbre="kit_electro"), bass=dict(pattern="eighth", timbre="saw", gm=38),
                        harmony=dict(rhythm="stabs", ext="none", timbre="supersaw", gm=90), melody=dict(style="lead", timbre="lead", gm=80)),
    "calm":        dict(drums=dict(groove="sparse", swing=0.0, timbre="kit_soft"), bass=dict(pattern="root_whole", timbre="sub", gm=32),
                        harmony=dict(rhythm="sustain", ext="add9", timbre="pad", gm=89), melody=dict(style="sparse", timbre="vibes", gm=11)),
    "melancholic": dict(drums=dict(groove="sparse", swing=0.0, timbre="kit_soft"), bass=dict(pattern="root_whole", timbre="sub", gm=43),
                        harmony=dict(rhythm="half", ext="7", timbre="piano", gm=0), melody=dict(style="sparse", timbre="strings", gm=42)),
}

# English keyword weights per mood
KEYWORDS: dict[str, dict[str, float]] = {
    "cinematic": {"cinematic": 3, "epic": 2, "film": 1.5, "movie": 1.5, "trailer": 2, "orchestral": 2, "dramatic": 2, "heroic": 1.5, "score": 1, "grand": 1},
    "lofi": {"lofi": 3, "chill": 2, "study": 1.5, "mellow": 2, "cozy": 2, "vinyl": 1, "jazzy": 1.5, "chillhop": 3},
    "corporate": {"corporate": 3, "business": 2, "presentation": 2, "explainer": 2, "product": 1.5, "startup": 2, "professional": 2,
                  "motivational": 2, "inspiring": 1.5, "uplifting": 1.5, "optimistic": 1.5, "brand": 1, "modern": 1, "tech": 1},
    "electronic": {"electronic": 3, "edm": 3, "techno": 3, "house": 2, "synth": 2, "synthwave": 3, "dance": 2, "club": 2, "trance": 2,
                   "futuristic": 1.5, "cyberpunk": 2, "digital": 1},
    "acoustic": {"acoustic": 3, "guitar": 2, "folk": 2, "organic": 1.5, "unplugged": 2, "indie": 1, "country": 1.5, "natural": 1, "warm": 1},
    "tense": {"tense": 3, "suspense": 3, "thriller": 3, "dark": 2, "ominous": 2.5, "eerie": 2, "horror": 2, "anxious": 2,
              "mysterious": 1.5, "tension": 3, "urgent": 1.5},
    "playful": {"playful": 3, "fun": 2, "quirky": 2.5, "cheerful": 2, "happy": 2, "whimsical": 2.5, "kids": 2, "children": 2,
                "bouncy": 2, "cartoon": 2, "comedic": 2},
    "energetic": {"energetic": 3, "upbeat": 2.5, "powerful": 1.5, "sport": 2, "sports": 2, "workout": 2.5, "intense": 2, "driving": 2,
                  "action": 2, "pumping": 2, "exciting": 2, "energy": 2},
    "calm": {"calm": 3, "relaxing": 3, "relaxed": 2.5, "peaceful": 3, "ambient": 2, "soothing": 3, "gentle": 2, "serene": 3,
             "meditation": 3, "spa": 2, "soft": 1.5, "sleep": 2},
    "melancholic": {"sad": 3, "melancholic": 3, "melancholy": 3, "nostalgic": 2, "emotional": 1.5, "sorrow": 2.5, "lonely": 2,
                    "bittersweet": 2.5, "somber": 2.5, "wistful": 2.5},
}
AGGRESSIVE = {"aggressive": 3, "angry": 2.5, "brutal": 2, "fierce": 2, "violent": 2}

# Best-effort multilingual keywords (accent-folded Latin, native script otherwise).
FOREIGN: dict[str, list[str]] = {
    "calm": ["calme", "tranquilo", "tranquila", "calma", "ruhig", "entspannt", "relajado", "detendu", "tranquille",
             "平静", "安静", "放松", "穏やか", "静か", "शांत", "அமைதியான", "спокойный", "спокойная"],
    "energetic": ["energique", "energico", "energisch", "活力", "エネルギッシュ", "ऊर्जावान", "உற்சாகமான", "энергичный", "dynamique"],
    "cinematic": ["epico", "epique", "episch", "cinematografico", "cinematographique", "史诗", "电影", "映画", "壮大", "эпичный"],
    "playful": ["alegre", "joyeux", "frohlich", "欢快", "快乐", "楽しい", "खुश", "மகிழ்ச்சியான", "весёлый", "divertido"],
    "tense": ["tenso", "tendu", "spannend", "紧张", "緊張", "तनाव", "напряжённый"],
    "melancholic": ["triste", "traurig", "悲伤", "悲しい", "उदास", "சோகமான", "грустный", "melancolico"],
    "electronic": ["electronique", "elektronisch", "electronica", "电子", "電子", "электронный"],
    "acoustic": ["acoustique", "akustisch", "acustico", "原声", "アコースティック"],
    "corporate": ["corporativo", "entreprise", "unternehmen", "企业", "企業", "корпоративный"],
    "lofi": ["ローファイ", "低保真"],
}
FOREIGN_AGGRESSIVE = ["agresivo", "agressif", "aggressiv", "攻击", "激しい", "агрессивный"]

LOW_SIDE = {"calm", "melancholic"}
HIGH_SIDE = {"energetic", "playful", "aggressive"}

ARTISTS = (
    "coldplay|taylor swift|beyonc[eé]|drake|adele|ed sheeran|the beatles|beatles|billie eilish|the weeknd|eminem|kanye west|kanye|"
    "rihanna|ariana grande|bruno mars|justin bieber|dua lipa|post malone|michael jackson|madonna|metallica|nirvana|radiohead|"
    "daft punk|avicii|calvin harris|skrillex|hans zimmer|john williams|ludovico einaudi|enya|imagine dragons|maroon 5|pink floyd|"
    "led zeppelin|ac/dc|blackpink|bts|disney|pixar|marvel|star wars|harry potter|game of thrones|lady gaga|katy perry|oasis|"
    "linkin park|queen|u2|the chainsmokers|martin garrix|marshmello|zedd|lana del rey"
)
RE_ARTIST_KNOWN = re.compile(r"\b(?:" + ARTISTS + r")\b(?:'s)?", re.I)
RE_ARTIST_PATTERN = re.compile(
    r"\b(?:in the style of|sounds? like|similar to|reminiscent of|inspired by|à la|like|by)\s+"
    r"(?:the\s+)?((?:[A-Z][\w'’.&-]*\s?){1,4}|[\"“][^\"”]{1,60}[\"”])"
)
RE_STYLE_LEAD = re.compile(r"\b(?:in the style of|sounds? like|similar to|reminiscent of|inspired by|in the vein of)\b\s*(?:the\s+)?", re.I)
VOCAL_WORDS = r"vocals?|vocalists?|singing|singers?|sings?|lyrics?|rapping|rap|humming|choir|chanting|chants?|a cappella|acapella|spoken word"
RE_NEG_VOCAL = re.compile(r"\b(?:no|without|non|zero|minus)[\s-]+(?:" + VOCAL_WORDS + r")\b", re.I)
RE_VOCAL = re.compile(r"\b(?:" + VOCAL_WORDS + r")\b", re.I)


def _fold(s: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFKD", s) if not unicodedata.combining(c)).lower()


def _trigrams(w: str) -> set[str]:
    w = f"^{w}$"
    return {w[i:i + 3] for i in range(len(w) - 2)}


def _dice(a: str, b: str) -> float:
    ta, tb = _trigrams(a), _trigrams(b)
    return 2 * len(ta & tb) / (len(ta) + len(tb)) if ta and tb else 0.0


def stable_int(*parts: Any, bits: int = 31) -> int:
    h = hashlib.sha256("|".join(str(p) for p in parts).encode()).digest()
    return int.from_bytes(h[:8], "big") % (1 << bits)


# --------------------------------------------------------------------------
# Prompt sanitising and mood detection
# --------------------------------------------------------------------------
def sanitize_prompt(prompt: str) -> tuple[str, list[str], dict[str, bool]]:
    warnings: list[str] = []
    flags = {"vocal": False, "artist": False}
    text = prompt
    text = RE_NEG_VOCAL.sub(" ", text)
    if RE_VOCAL.search(text):
        flags["vocal"] = True
        text = RE_VOCAL.sub(" ", text)
    cleaned = RE_ARTIST_KNOWN.sub(" ", text)
    if cleaned != text:
        flags["artist"] = True
    text = cleaned
    cleaned = RE_ARTIST_PATTERN.sub(" ", text)
    if cleaned != text:
        flags["artist"] = True
    text = cleaned
    text = RE_STYLE_LEAD.sub(" ", text) if flags["artist"] else text
    text = re.sub(r"\s+", " ", text).strip(" ,.;:-")
    if flags["vocal"]:
        warnings.append(W_VOCAL_REQUEST)
    if flags["artist"]:
        warnings.append(W_ARTIST)
    return text, warnings, flags


def _is_non_latin(text: str) -> bool:
    for ch in text:
        if ch.isalpha() and ord(ch) > 0x24F:
            return True
    return False


def detect_mood(text: str) -> dict[str, Any]:
    norm = re.sub(r"\blo[\s-]?fi\b", "lofi", text, flags=re.I)
    norm = re.sub(r"\bhigh[\s-]energy\b", "energy", norm, flags=re.I)
    low = norm.lower()
    folded = _fold(norm)
    tokens = re.findall(r"[a-z0-9]+", folded)
    scores = {m: 0.0 for m in MOODS}
    aggressive = 0.0
    english_hit = False
    foreign_hit = False

    def tok_score(tok: str, table: dict[str, float]) -> float:
        best = 0.0
        for kw, w in table.items():
            if tok == kw or (tok.endswith("s") and tok[:-1] == kw) or (tok.endswith("ly") and tok[:-2] == kw):
                best = max(best, w)
            elif len(tok) >= 5 and len(kw) >= 5 and _dice(tok, kw) >= 0.8:
                best = max(best, w * 0.8)
        return best

    for tok in tokens:
        for mood, table in KEYWORDS.items():
            s = tok_score(tok, table)
            if s:
                scores[mood] += s
                english_hit = True
        s = tok_score(tok, AGGRESSIVE)
        if s:
            aggressive += s
            english_hit = True

    for mood, kws in FOREIGN.items():
        for kw in kws:
            ascii_kw = kw.isascii()
            hit = (kw in tokens) if ascii_kw else (kw in low)
            if hit:
                scores[mood] += 2.5
                foreign_hit = True
    for kw in FOREIGN_AGGRESSIVE:
        if (kw in tokens) if kw.isascii() else (kw in low):
            aggressive += 2.5
            foreign_hit = True

    accented = any(ord(c) > 0x7F and c.isalpha() for c in text)
    non_english = _is_non_latin(text) or (not english_hit and (foreign_hit or accented))
    return {"scores": scores, "aggressive": aggressive, "non_english": bool(non_english), "matched": any(scores.values()) or aggressive > 0}


# --------------------------------------------------------------------------
# Key parsing, tempo and chords
# --------------------------------------------------------------------------
def parse_key(key: str | None) -> tuple[int, str] | None:
    if not key:
        return None
    m = re.fullmatch(r"\s*([A-Ga-g])\s*([#b♯♭]?)\s*(major|maj|minor|min|m|dorian|phrygian|lydian|mixolydian)?\s*", key)
    if not m:
        return None
    letter, acc, mode = m.group(1).upper(), m.group(2), (m.group(3) or "").lower()
    name = letter + {"♯": "#", "♭": "b"}.get(acc, acc)
    if name.endswith("b"):
        name = FLAT_TO_SHARP.get(name.upper(), name)
    if name.upper() not in [n.upper() for n in NOTE_NAMES]:
        return None
    pc = [n.upper() for n in NOTE_NAMES].index(name.upper())
    mode = {"": None, "maj": "major", "min": "minor", "m": "minor"}.get(mode, mode)
    return pc, mode or "major"


def scale_pcs(tonic: int, mode: str) -> list[int]:
    return [(tonic + i) % 12 for i in MODES[mode]]


def chord_for(tonic: int, mode: str, degree: int, ext: str, dominant: bool = False) -> dict[str, Any]:
    sc = scale_pcs(tonic, mode)
    root = sc[degree % 7]
    third, fifth = sc[(degree + 2) % 7], sc[(degree + 4) % 7]
    seventh = sc[(degree + 6) % 7]
    if dominant and mode in ("minor", "phrygian", "dorian") and degree == 4:
        third = (root + 4) % 12
    pcs = [root, third, fifth]
    if ext == "7":
        pcs.append(seventh)
    elif ext == "add9":
        pcs.append(sc[(degree + 1) % 7])
    elif ext == "sus2":
        pcs = [root, sc[(degree + 1) % 7], fifth]
    minor = (third - root) % 12 == 3
    name = NOTE_NAMES[root] + ("m" if minor else "") + {"7": "7", "add9": "add9", "sus2": "sus2"}.get(ext, "")
    return {"root_pc": root, "pcs": pcs, "degree": degree, "name": name}


def _blend(scores: dict[str, float], aggressive: float) -> tuple[str, str | None, bool]:
    ranked = sorted(((s, m) for m, s in scores.items() if s > 0), reverse=True)
    low = sum(scores[m] for m in LOW_SIDE)
    high = sum(scores[m] for m in HIGH_SIDE - {"aggressive"}) + aggressive
    contradictory = low > 0 and high > 0
    if not ranked:
        return "corporate", None, False
    primary = ranked[0][1]
    secondary = ranked[1][1] if len(ranked) > 1 and ranked[1][0] >= 0.5 * ranked[0][0] else None
    return primary, secondary, contradictory


def make_styles(primary: str, secondary: str | None, contradictory: bool) -> dict[str, dict[str, Any]]:
    styles = copy.deepcopy(STYLES[primary])
    if contradictory:
        styles["drums"] = dict(groove="blend_driving", swing=0.0, timbre="kit_electro")
        styles["bass"] = dict(pattern="eighth", timbre="saw", gm=38)
        styles["harmony"] = dict(rhythm="sustain", ext="add9", timbre="pad", gm=89)
        styles["melody"] = dict(style="sparse", timbre="bell", gm=46)
    elif secondary:
        styles["melody"] = copy.deepcopy(STYLES[secondary]["melody"])
    return styles


def snap_tempo(duration_s: float, bpm: float) -> tuple[int, float]:
    bars = max(2, int(round(duration_s * bpm / (60.0 * BEATS_PER_BAR))))
    return bars, bars * 60.0 * BEATS_PER_BAR / duration_s


SECTION_ENERGY = {"intro": 0.30, "verse": 0.55, "main": 0.60, "build": 0.75, "buildup": 0.75, "chorus": 0.95, "drop": 1.0,
                  "hook": 0.95, "climax": 0.95, "bridge": 0.40, "breakdown": 0.35, "outro": 0.30, "ending": 0.30}


def _energy_for(name: str, given: Any) -> float:
    if isinstance(given, (int, float)) and not isinstance(given, bool):
        return float(min(1.0, max(0.0, given)))
    if isinstance(given, str):
        return {"low": 0.3, "medium": 0.6, "high": 0.9}.get(given.lower(), SECTION_ENERGY.get(name.lower(), 0.6))
    for k, v in SECTION_ENERGY.items():
        if k in name.lower():
            return v
    return 0.6


def plan_sections(sections: list[dict[str, Any]] | None, duration_s: float, bars: int, bar_s: float,
                  loopable: bool, warnings: list[str]) -> list[dict[str, Any]]:
    entries: list[dict[str, Any]] = []
    if sections:
        items = []
        for i, s in enumerate(sections):
            name = str(s.get("name") or f"section_{i + 1}")
            start = float(s.get("start_s", 0.0))
            if start >= duration_s:
                warnings.append(f"SECTION_OUT_OF_RANGE: section '{name}' start_s={start:g} >= duration_s={duration_s:g}; section dropped.")
                continue
            if start < 0:
                warnings.append(f"SECTION_START_CLAMPED: section '{name}' start_s={start:g} clamped to 0.")
                start = 0.0
            items.append({"name": name, "start": start, "energy": _energy_for(name, s.get("energy", s.get("intensity")))})
        items.sort(key=lambda x: x["start"])
        merged: list[dict[str, Any]] = []
        for it in items:
            if merged:
                prev = merged[-1]
                snapped_gap = abs(round(it["start"] / bar_s) - round(prev["start"] / bar_s)) * bar_s
                if it["start"] - prev["start"] < 1.5 or snapped_gap < 1.5:
                    warnings.append(f"SECTIONS_MERGED: '{it['name']}' (start_s={it['start']:g}) is closer than 1.5s to '{prev['name']}'; merged.")
                    prev["energy"] = max(prev["energy"], it["energy"])
                    prev.setdefault("merged", []).append(it["name"])
                    continue
            merged.append(dict(it))
        if merged and merged[0]["start"] > 0:
            if merged[0]["start"] < 1.5:
                warnings.append(f"SECTION_START_CLAMPED: first section '{merged[0]['name']}' start_s={merged[0]['start']:g} moved to 0.")
                merged[0]["start"] = 0.0
            else:
                warnings.append("SECTIONS_PREPENDED_INTRO: first section did not start at 0; an implicit intro was added.")
                merged.insert(0, {"name": "intro", "start": 0.0, "energy": 0.3})
        entries = merged
    if not entries:
        if bars < 8 or duration_s < 15:
            entries = [{"name": "main", "start": 0.0, "energy": 0.7}]
        elif loopable:
            half = bars // 2
            entries = [{"name": "verse", "start": 0.0, "energy": 0.55}, {"name": "chorus", "start": half * bar_s, "energy": 0.8}]
        else:
            intro = max(1, round(bars * 0.12))
            outro = max(1, round(bars * 0.12))
            climax = max(1, round(bars * 0.25))
            main = bars - intro - outro - climax
            entries = [{"name": "intro", "start": 0.0, "energy": 0.3},
                       {"name": "main", "start": intro * bar_s, "energy": 0.6},
                       {"name": "climax", "start": (intro + main) * bar_s, "energy": 0.95},
                       {"name": "outro", "start": (intro + main + climax) * bar_s, "energy": 0.35}]
    out: list[dict[str, Any]] = []
    for i, e in enumerate(entries):
        start_bar = min(bars - 1, max(0, int(round(e["start"] / bar_s))))
        if out and start_bar <= out[-1]["start_bar"]:
            warnings.append(f"SECTIONS_MERGED: '{e['name']}' snapped onto the same bar as '{out[-1]['name']}'; merged.")
            out[-1]["energy"] = max(out[-1]["energy"], e["energy"])
            continue
        out.append({"name": e["name"], "planned_start_s": round(e["start"], 4), "start_bar": start_bar, "energy": round(e["energy"], 3)})
    out[0]["start_bar"] = 0
    for i, s in enumerate(out):
        s["end_bar"] = out[i + 1]["start_bar"] if i + 1 < len(out) else bars
        s["start_s"] = round(s["start_bar"] * bar_s, 6)
        s["end_s"] = round(s["end_bar"] * bar_s, 6)
        s["bars"] = s["end_bar"] - s["start_bar"]
    return out


# --------------------------------------------------------------------------
# Public planning API
# --------------------------------------------------------------------------
def plan(prompt: str, duration_s: float, sections: list[dict[str, Any]] | None = None, tempo_bpm: float | None = None,
         key: str | None = None, loopable: bool = False, seed: int | None = None,
         min_duration_s: float = 5.0, max_duration_s: float = 300.0) -> dict[str, Any]:
    if not (min_duration_s <= duration_s <= max_duration_s):
        raise ValueError(f"duration_s must be within [{min_duration_s}, {max_duration_s}]")
    warnings: list[str] = []
    if seed is None:
        seed = stable_int(prompt, duration_s, tempo_bpm, key, loopable)
    clean, w, flags = sanitize_prompt(prompt)
    warnings += w

    det = detect_mood(clean)
    if det["non_english"]:
        warnings.append("NON_ENGLISH_PROMPT: Prompt is not English; multilingual keyword mapping was used.")
    primary, secondary, contradictory = _blend(det["scores"], det["aggressive"])
    if not det["matched"]:
        warnings.append(f"MOOD_FALLBACK: No mood keywords recognised; defaulted to '{primary}'.")
    if contradictory:
        warnings.append("CONTRADICTORY_PROMPT: Prompt mixes calm and aggressive/energetic cues; blended slow sparse harmony with driving drums and bass.")

    mdef = MOODS[primary]
    base_bpm = mdef["bpm"]
    low = clean.lower()
    if secondary and not contradictory:
        base_bpm = 0.7 * base_bpm + 0.3 * MOODS[secondary]["bpm"]
    if contradictory:
        base_bpm = 84.0
    if re.search(r"\bslow(?:er|ly)?\b", low):
        base_bpm *= 0.88
    if re.search(r"\bfast(?:er)?\b|\bquick\b", low):
        base_bpm *= 1.12
    requested = tempo_bpm
    target_bpm = float(tempo_bpm) if tempo_bpm else base_bpm
    target_bpm = min(220.0, max(40.0, target_bpm))
    bars, bpm = snap_tempo(duration_s, target_bpm)
    if tempo_bpm and abs(bpm - tempo_bpm) / tempo_bpm > 0.03:
        warnings.append(f"TEMPO_SNAPPED: requested {tempo_bpm:g} BPM adjusted to {bpm:.3f} BPM so {bars} whole bars equal duration_s exactly.")
    bar_s = duration_s / bars

    parsed = parse_key(key)
    if key and not parsed:
        warnings.append(f"INVALID_KEY_FALLBACK: key '{key}' not understood; using the mood default.")
    if parsed:
        tonic, mode = parsed
        if not re.search(r"(major|maj|minor|min|m|dorian|phrygian|lydian|mixolydian)\s*$", key or "", re.I):
            mode = mdef["mode"] if mdef["mode"] in ("major", "minor") else mode
    else:
        tonic = [n for n in NOTE_NAMES].index(mdef["tonics"][stable_int(seed, "key") % len(mdef["tonics"])])
        mode = "minor" if contradictory else mdef["mode"]
    key_name = f"{NOTE_NAMES[tonic]} {mode}"

    styles = make_styles(primary, secondary, contradictory)
    ext = styles["harmony"]["ext"]
    prog = mdef["prog"] if not contradictory else [0, 5, 3, 4]

    degrees: list[int] = []
    for b in range(bars):
        degrees.append(prog[b % len(prog)])
    if not loopable:
        degrees[-1] = 0
        if bars >= 2:
            degrees[-2] = 4
        if bars >= 4:
            degrees[-3] = 3
    elif bars >= 4:
        degrees[-1] = 4
    chords = []
    for b, d in enumerate(degrees):
        dom = d == 4 and (b >= bars - 2)
        chords.append(chord_for(tonic, mode, d, ext, dominant=dom))

    secs = plan_sections(sections, duration_s, bars, bar_s, loopable, warnings)
    bar_energy = []
    for s in secs:
        bar_energy += [s["energy"]] * s["bars"]

    return {
        "prompt_original": prompt,
        "prompt_effective": clean,
        "mood": {"primary": primary, "secondary": secondary, "contradictory": contradictory,
                 "scores": {k: round(v, 2) for k, v in det["scores"].items() if v},
                 "non_english": det["non_english"], "artist_reference": flags["artist"], "vocal_request": flags["vocal"]},
        "tempo_requested_bpm": requested,
        "tempo_bpm": bpm,
        "beats_per_bar": BEATS_PER_BAR,
        "time_signature": "4/4",
        "bars": bars,
        "bar_s": bar_s,
        "duration_s": duration_s,
        "key": key_name,
        "tonic_pc": tonic,
        "mode": mode,
        "loopable": loopable,
        "seed": seed,
        "styles": styles,
        "stem_gains": dict(mdef["gains"]),
        "chords": chords,
        "sections": secs,
        "bar_energy": bar_energy,
        "warnings": warnings,
    }


def apply_prompt_override(base: dict[str, Any], stem: str, prompt: str) -> tuple[dict[str, Any], list[str]]:
    """Return a copy of ``base`` where only ``stem``'s style follows ``prompt``.

    Tempo, key, chords, sections and bar grid are left untouched.
    """
    out = copy.deepcopy(base)
    clean, warnings, _ = sanitize_prompt(prompt)
    det = detect_mood(clean)
    primary, secondary, contradictory = _blend(det["scores"], det["aggressive"])
    if not det["matched"]:
        warnings.append(f"MOOD_FALLBACK: No mood keywords recognised in prompt_override; kept the original {stem} style.")
        return out, warnings
    styles = make_styles(primary, secondary, contradictory)
    out["styles"][stem] = styles[stem]
    return out, warnings

"""All runtime configuration, read from environment variables (see .env.example)."""
from __future__ import annotations

from functools import lru_cache

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore", case_sensitive=False)

    # generation
    music_provider: str = "fluidsynth_symbolic"   # fluidsynth_symbolic | procedural_synth | mock
    soundfont_path: str = "/usr/share/sounds/sf2/FluidR3_GM.sf2"
    min_duration_s: float = 5.0
    max_duration_s: float = 300.0
    default_sample_rate: int = 48000
    default_target_lufs: float = -16.0
    compute_cost_usd_per_cpu_hour: float = 0.04

    # paths and state
    data_dir: str = "/data"
    work_dir: str = "/tmp/incubrix"
    db_path: str = ""   # defaults to <data_dir>/incubrix.sqlite3

    # object storage (MinIO / any S3)
    s3_endpoint_url: str = "http://minio:9000"
    s3_public_endpoint_url: str = "http://localhost:9000"   # host used inside presigned URLs
    s3_access_key: str = "minioadmin"
    s3_secret_key: str = "minioadmin"
    s3_bucket: str = "incubrix-music"
    s3_region: str = "us-east-1"
    presign_ttl_s: int = 3600

    # worker
    worker_concurrency: int = 1
    worker_poll_interval_s: float = 0.5
    worker_isolation: str = "process"   # process (killable, enforces job_timeout_s) | inline (tests)
    job_timeout_s: int = 900
    stale_job_after_s: int = 1800

    # API protection
    rate_limit_per_minute: int = 120            # all /api/v1 requests per client IP
    rate_limit_jobs_per_minute: int = 12        # POSTs that create work, per client IP
    rate_limit_enabled: bool = True
    trust_proxy_headers: bool = False
    max_upload_bytes: int = 50 * 1024 * 1024

    # narration input
    narration_max_bytes: int = 50 * 1024 * 1024
    narration_fetch_timeout_s: float = 20.0
    allow_private_narration_hosts: bool = False
    allow_local_narration_paths: bool = False
    allow_private_callback_hosts: bool = False

    # callbacks
    callback_secret: str = Field(default="change-me")
    callback_timeout_s: float = 10.0
    callback_max_attempts: int = 3

    log_level: str = "INFO"

    @property
    def sqlite_path(self) -> str:
        return self.db_path or f"{self.data_dir.rstrip('/')}/incubrix.sqlite3"


@lru_cache
def get_settings() -> Settings:
    return Settings()

"""Swappable music generator provider interface."""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

import numpy as np

from ..arranger import Event, Grid

TAIL_S = 3.0


class MusicGeneratorProvider(ABC):
    name = "base"
    model_version = "0"
    license = "unspecified"

    @abstractmethod
    def render_stem(self, stem: str, events: list[Event], grid: Grid, style: dict[str, Any],
                    seed: int, loopable: bool) -> np.ndarray:
        """Return a mono float64 array of exactly ``grid.n_samples`` samples.

        Implementations render ``TAIL_S`` extra seconds and call
        ``finalize_buffer`` so release tails wrap into bar 1 when looping.
        """

    def available(self) -> bool:
        return True

    @property
    def effective_name(self) -> str:
        return self.name

    def info(self) -> dict[str, str]:
        return {"provider": self.effective_name, "model_version": self.model_version, "license": self.license}


def finalize_buffer(buf: np.ndarray, n: int, loopable: bool) -> np.ndarray:
    """Trim a render that has a tail to ``n`` samples.

    Loopable: the tail is added back onto the start, so release/reverb that
    crosses the end carries into bar 1 and the loop point is continuous.
    """
    out = buf[:n].copy()
    if loopable and buf.shape[0] > n:
        tail = buf[n:n + (buf.shape[0] - n)]
        k = min(tail.shape[0], n)
        out[:k] += tail[:k]
    if out.shape[0] < n:
        out = np.pad(out, (0, n - out.shape[0]))
    return out


def get_provider(name: str, **kwargs: Any) -> MusicGeneratorProvider:
    from .fluidsynth_symbolic import FluidSynthSymbolicProvider
    from .mock import MockProvider
    from .procedural import ProceduralSynthProvider
    registry = {
        "fluidsynth_symbolic": FluidSynthSymbolicProvider,
        "procedural_synth": ProceduralSynthProvider,
        "mock": MockProvider,
    }
    if name not in registry:
        raise ValueError(f"Unknown MUSIC_PROVIDER '{name}'. Choose one of: {', '.join(sorted(registry))}")
    return registry[name](**kwargs) if name == "fluidsynth_symbolic" else registry[name]()

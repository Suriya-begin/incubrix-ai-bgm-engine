"""Fast CI provider (implementation lives next to the procedural voices)."""
from .procedural import MockProvider

__all__ = ["MockProvider"]

"""Pure NumPy/SciPy synthesis: additive, FM and subtractive voices plus a drum synth.

No samples, no third-party audio assets: everything is generated from math, so
the output has no sample-licence exposure. Also hosts the fast ``mock`` provider.
"""
from __future__ import annotations

import random
from typing import Any

import numpy as np
from scipy.signal import butter, sosfilt

from ..arranger import CRASH, HAT_C, HAT_O, KICK, SHAKER, SNARE, CLAP, TOM, Event, Grid
from .base import TAIL_S, MusicGeneratorProvider, finalize_buffer

MIN_ATTACK_S = 0.004


def hz(p: float) -> float:
    return 440.0 * 2.0 ** ((p - 69.0) / 12.0)


def _env(hold: int, release: int, sr: int, a: float, d: float, s: float, r: float) -> np.ndarray:
    n = hold + release
    t = np.arange(n) / sr
    a = max(a, MIN_ATTACK_S)
    env = np.where(t < a, t / a, s + (1.0 - s) * np.exp(-(t - a) / max(d, 1e-3)))
    rel_t = np.clip(t - hold / sr, 0.0, None)
    rel = np.where(t >= hold / sr, np.exp(-rel_t / max(r / 4.0, 1e-3)), 1.0)
    out = env * rel
    fade = min(release, int(0.01 * sr))  # force exact zero at note end
    if fade > 0:
        out[-fade:] *= np.linspace(1.0, 0.0, fade)
    return out


# ------------------------------------------------------------------ voices
def _harm_stack(f: float, t: np.ndarray, sr: int, ks: range, power: float, detunes: tuple[float, ...]) -> np.ndarray:
    y = np.zeros_like(t)
    for cents in detunes:
        fd = f * 2.0 ** (cents / 1200.0)
        for k in ks:
            if fd * k < sr / 2.2:
                y += np.sin(2 * np.pi * fd * k * t + 0.7 * k) / (k ** power)
    return y / len(detunes)


def voice_bass(timbre: str, f: float, hold: int, sr: int) -> np.ndarray:
    rel = int(0.12 * sr)
    n = hold + rel
    t = np.arange(n) / sr
    if timbre == "saw":
        y = sum(np.sin(2 * np.pi * f * k * t) / k * np.exp(-t * (1.5 + 2.0 * k)) for k in range(1, 9)) + 0.6 * np.sin(2 * np.pi * f * t)
        env = _env(hold, rel, sr, 0.004, 0.4, 0.8, 0.12)
    elif timbre == "upright":
        y = np.sin(2 * np.pi * f * t) + 0.5 * np.sin(4 * np.pi * f * t) * np.exp(-t * 4)
        env = _env(hold, rel, sr, 0.006, 0.35, 0.35, 0.15)
    elif timbre == "pizz":
        y = np.sin(2 * np.pi * f * t) + 0.4 * np.sin(4 * np.pi * f * t)
        env = np.exp(-t * 9.0) * _env(hold, rel, sr, 0.003, 1.0, 1.0, 0.05)
    else:  # sub
        y = np.sin(2 * np.pi * f * t) + 0.30 * np.sin(4 * np.pi * f * t) + 0.12 * np.sin(6 * np.pi * f * t)
        env = _env(hold, rel, sr, 0.006, 0.5, 0.75, 0.12)
    return y * env


def voice_harmony(timbre: str, f: float, hold: int, sr: int) -> np.ndarray:
    if timbre in ("piano", "epiano", "guitar"):
        rel = int(0.25 * sr)
        n = hold + rel
        t = np.arange(n) / sr
        d0 = {"piano": 1.3, "epiano": 1.8, "guitar": 2.4}[timbre]
        y = np.zeros(n)
        for k in range(1, 6):
            if f * k < sr / 2.2:
                y += np.sin(2 * np.pi * f * k * t) / k * np.exp(-t * d0 * (1 + 0.7 * k))
        if timbre == "epiano":
            y += 0.4 * np.sin(2 * np.pi * f * t + 2.0 * np.exp(-t * 6) * np.sin(2 * np.pi * f * t)) * np.exp(-t * d0)
        return y * _env(hold, rel, sr, 0.004, 5.0, 1.0, 0.25)
    rel = int((0.7 if timbre != "supersaw" else 0.3) * sr)
    n = hold + rel
    t = np.arange(n) / sr
    if timbre == "supersaw":
        y = _harm_stack(f, t, sr, range(1, 7), 1.0, (-12, -5, 0, 5, 12))
        env = _env(hold, rel, sr, 0.015, 0.5, 0.7, 0.3)
    elif timbre == "strings":
        vib = 1.0 + 0.0025 * np.sin(2 * np.pi * 5.0 * t) * np.minimum(1.0, t / 0.5)
        y = _harm_stack(f, t * vib, sr, range(1, 6), 1.2, (-7, 0, 7))
        env = _env(hold, rel, sr, 0.25, 0.5, 0.9, 0.7)
    else:  # pad
        y = _harm_stack(f, t, sr, range(1, 5), 1.6, (-6, 0, 6))
        env = _env(hold, rel, sr, 0.5, 0.5, 0.95, 0.7)
    return y * env


def voice_melody(timbre: str, f: float, hold: int, sr: int) -> np.ndarray:
    rel = int(0.35 * sr)
    n = hold + rel
    t = np.arange(n) / sr
    if timbre == "bell":
        y = sum(a * np.sin(2 * np.pi * f * r * t) * np.exp(-t * dc)
                for r, a, dc in ((1.0, 1.0, 2.2), (2.76, 0.5, 3.4), (5.4, 0.25, 5.0), (8.93, 0.12, 7.0)) if f * r < sr / 2.2)
        env = _env(hold, rel, sr, 0.003, 3.0, 1.0, 0.35)
    elif timbre == "vibes":
        trem = 1.0 + 0.15 * np.sin(2 * np.pi * 5.0 * t)
        y = (np.sin(2 * np.pi * f * t) + 0.3 * np.sin(2 * np.pi * 4 * f * t) * np.exp(-t * 6)) * np.exp(-t * 1.8) * trem
        env = _env(hold, rel, sr, 0.003, 3.0, 1.0, 0.3)
    elif timbre == "marimba":
        y = np.sin(2 * np.pi * f * t) * np.exp(-t * 3.0) + 0.5 * np.sin(2 * np.pi * 4 * f * t) * np.exp(-t * 14.0)
        env = _env(hold, rel, sr, 0.002, 3.0, 1.0, 0.2)
    elif timbre == "lead":
        vib = 1.0 + 0.004 * np.sin(2 * np.pi * 5.5 * t) * np.minimum(1.0, t / 0.2)
        y = _harm_stack(f, t * vib, sr, range(1, 7), 1.0, (-4, 4))
        env = _env(hold, rel, sr, 0.01, 0.3, 0.8, 0.2)
    elif timbre == "strings":
        vib = 1.0 + 0.003 * np.sin(2 * np.pi * 5.2 * t) * np.minimum(1.0, t / 0.4)
        y = _harm_stack(f, t * vib, sr, range(1, 6), 1.2, (-5, 5))
        env = _env(hold, rel, sr, 0.12, 0.5, 0.9, 0.35)
    else:  # pluck (FM)
        idx = 3.0 * np.exp(-t * 8.0)
        y = np.sin(2 * np.pi * f * t + idx * np.sin(2 * np.pi * 2 * f * t)) * np.exp(-t * 4.5)
        env = _env(hold, rel, sr, 0.002, 3.0, 1.0, 0.25)
    return y * env


# ------------------------------------------------------------------ drums
KIT = {
    "kit_pop":    dict(kick=(48, 110, 0.16, 0.45), snare=(190, 0.10), lp=None, level=1.0),
    "kit_rock":   dict(kick=(50, 120, 0.18, 0.50), snare=(180, 0.13), lp=None, level=1.0),
    "kit_electro": dict(kick=(44, 150, 0.14, 0.40), snare=(200, 0.09), lp=None, level=1.0),
    "kit_lofi":   dict(kick=(52, 90, 0.17, 0.45), snare=(175, 0.11), lp=4500, level=0.85),
    "kit_soft":   dict(kick=(54, 80, 0.12, 0.30), snare=(170, 0.07), lp=5500, level=0.7),
    "kit_orch":   dict(kick=(40, 70, 0.30, 0.80), snare=(160, 0.18), lp=7000, level=1.0),
}


def _hp(x: np.ndarray, fc: float, sr: int, order: int = 2) -> np.ndarray:
    return sosfilt(butter(order, fc / (sr / 2), "high", output="sos"), x)


def _lp(x: np.ndarray, fc: float, sr: int, order: int = 2) -> np.ndarray:
    return sosfilt(butter(order, min(fc, sr / 2.2) / (sr / 2), "low", output="sos"), x)


def _bp(x: np.ndarray, lo: float, hi: float, sr: int) -> np.ndarray:
    return sosfilt(butter(2, [lo / (sr / 2), min(hi, sr / 2.2) / (sr / 2)], "band", output="sos"), x)


def make_drum_hits(kit: str, sr: int, rng: random.Random, variants: int = 3) -> dict[int, list[np.ndarray]]:
    k = KIT.get(kit, KIT["kit_pop"])
    nrng = np.random.default_rng(rng.randrange(1 << 31))
    hits: dict[int, list[np.ndarray]] = {n: [] for n in (KICK, SNARE, CLAP, HAT_C, HAT_O, TOM, CRASH, SHAKER)}
    f_lo, f_hi, kd, _ = k["kick"]
    for _ in range(variants):
        t = np.arange(int(0.6 * sr)) / sr
        freq = f_lo + (f_hi - f_lo) * np.exp(-t / 0.03)
        phase = 2 * np.pi * np.cumsum(freq) / sr
        y = np.sin(phase) * np.exp(-t / kd)
        y += 0.25 * nrng.standard_normal(t.size) * np.exp(-t / 0.003)
        hits[KICK].append(y * _smooth_tail(t.size, sr))
        n = int(0.35 * sr); t = np.arange(n) / sr
        noise = _hp(nrng.standard_normal(n), 1200, sr) * np.exp(-t / k["snare"][1])
        tone = np.sin(2 * np.pi * k["snare"][0] * t) * np.exp(-t / 0.06)
        hits[SNARE].append((0.7 * noise + 0.5 * tone) * _smooth_tail(n, sr))
        n = int(0.3 * sr); t = np.arange(n) / sr
        burst = np.zeros(n)
        for off in (0.0, 0.011, 0.022):
            i = int(off * sr)
            burst[i:] += np.exp(-(t[: n - i]) / 0.008)
        burst += 0.6 * np.exp(-t / 0.09)
        hits[CLAP].append(_bp(nrng.standard_normal(n), 900, 3000, sr) * burst * 0.8 * _smooth_tail(n, sr))
        n = int(0.08 * sr); t = np.arange(n) / sr
        hits[HAT_C].append(_hp(nrng.standard_normal(n), 7000, sr) * np.exp(-t / 0.018) * 0.5 * _smooth_tail(n, sr))
        n = int(0.45 * sr); t = np.arange(n) / sr
        hits[HAT_O].append(_hp(nrng.standard_normal(n), 7000, sr) * np.exp(-t / 0.12) * 0.45 * _smooth_tail(n, sr))
        n = int(0.12 * sr); t = np.arange(n) / sr
        sh = _bp(nrng.standard_normal(n), 4000, 12000, sr) * np.minimum(1.0, t / 0.006) * np.exp(-t / 0.03)
        hits[SHAKER].append(sh * 0.5 * _smooth_tail(n, sr))
        n = int(0.5 * sr); t = np.arange(n) / sr
        freq = 70 + 60 * np.exp(-t / 0.08)
        hits[TOM].append(np.sin(2 * np.pi * np.cumsum(freq) / sr) * np.exp(-t / 0.25) * _smooth_tail(n, sr))
        n = int(2.8 * sr); t = np.arange(n) / sr
        hits[CRASH].append(_hp(nrng.standard_normal(n), 4500, sr) * np.exp(-t / 0.9) * 0.45 * _smooth_tail(n, sr))
    if k["lp"]:
        for note in hits:
            hits[note] = [_lp(h, k["lp"], sr) for h in hits[note]]
    for note in hits:
        hits[note] = [h * k["level"] for h in hits[note]]
    return hits


def _smooth_tail(n: int, sr: int) -> np.ndarray:
    w = np.ones(n)
    m = min(n, int(0.005 * sr))
    if m:
        w[-m:] = np.linspace(1.0, 0.0, m)
    return w


# ------------------------------------------------------------------ providers
class ProceduralSynthProvider(MusicGeneratorProvider):
    name = "procedural_synth"
    model_version = "procedural-1.0"
    license = "Original DSP synthesis (no third-party samples); project licence applies"

    def render_stem(self, stem: str, events: list[Event], grid: Grid, style: dict[str, Any],
                    seed: int, loopable: bool) -> np.ndarray:
        sr, n = grid.sample_rate, grid.n_samples
        buf = np.zeros(n + int(TAIL_S * sr))
        if stem == "drums":
            rng = random.Random(seed ^ 0x5EED)
            hits = make_drum_hits(style.get("timbre", "kit_pop"), sr, rng)
            for i, ev in enumerate(events):
                pool = hits.get(ev.pitch)
                if not pool:
                    continue
                h = pool[i % len(pool)]
                s = grid.beat_to_sample(ev.beat)
                if s >= buf.size:
                    continue
                m = min(h.size, buf.size - s)
                buf[s:s + m] += h[:m] * (ev.vel ** 1.2)
        else:
            voice = {"bass": voice_bass, "harmony": voice_harmony, "melody": voice_melody}[stem]
            timbre = style.get("timbre", "sub")
            cache: dict[tuple[int, int], np.ndarray] = {}
            for ev in events:
                s = grid.beat_to_sample(ev.beat)
                if s >= buf.size:
                    continue
                hold = max(int(ev.dur_beats * grid.beat_s * sr), int(0.02 * sr))
                key = (ev.pitch, hold)
                if key not in cache:
                    cache[key] = voice(timbre, hz(ev.pitch), hold, sr)
                w = cache[key]
                m = min(w.size, buf.size - s)
                buf[s:s + m] += w[:m] * ev.vel
        return finalize_buffer(buf, n, loopable)


class MockProvider(MusicGeneratorProvider):
    """Instant deterministic stand-in for CI: short enveloped blips on the grid."""
    name = "mock"
    model_version = "mock-1.0"
    license = "Test-only synthetic signal"

    def render_stem(self, stem: str, events: list[Event], grid: Grid, style: dict[str, Any],
                    seed: int, loopable: bool) -> np.ndarray:
        sr, n = grid.sample_rate, grid.n_samples
        buf = np.zeros(n + int(0.5 * sr))
        rng = np.random.default_rng(seed & 0x7FFFFFFF)
        blip_len = int(0.12 * sr)
        t = np.arange(blip_len) / sr
        env = np.minimum(1.0, t / 0.003) * np.exp(-t * 25.0)
        noise = rng.standard_normal(blip_len)
        for ev in events:
            s = grid.beat_to_sample(ev.beat)
            if s >= buf.size:
                continue
            if stem == "drums":
                w = (np.sin(2 * np.pi * 60 * t) if ev.pitch == KICK else noise * 0.5) * env
            else:
                w = np.sin(2 * np.pi * hz(ev.pitch) * t) * env
            m = min(blip_len, buf.size - s)
            buf[s:s + m] += w[:m] * ev.vel * 0.5
        return finalize_buffer(buf, n, loopable)

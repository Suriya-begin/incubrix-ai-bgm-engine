"""Minimal Standard MIDI File (type 0) writer. No third-party dependency."""
from __future__ import annotations

from ..arranger import Event

PPQ = 960


def _vlq(n: int) -> bytes:
    out = [n & 0x7F]
    n >>= 7
    while n:
        out.append((n & 0x7F) | 0x80)
        n >>= 7
    return bytes(reversed(out))


def write_midi(events: list[Event], bpm: float, total_beats: float, program: int, drums: bool,
               tail_beats: float = 8.0) -> bytes:
    ch = 9 if drums else 0
    msgs: list[tuple[int, int, bytes]] = []  # (tick, order, data); order 0 = note off first
    for ev in events:
        on = int(round(ev.beat * PPQ))
        dur = ev.dur_beats if not drums else min(ev.dur_beats, 0.25)
        off = on + max(1, int(round(dur * PPQ * 0.98)))
        vel = max(1, min(127, int(round(ev.vel * 127))))
        msgs.append((on, 1, bytes([0x90 | ch, ev.pitch & 0x7F, vel])))
        msgs.append((off, 0, bytes([0x80 | ch, ev.pitch & 0x7F, 0])))
    msgs.sort(key=lambda m: (m[0], m[1]))
    trk = bytearray()
    trk += b"\x00\xFF\x51\x03" + int(round(60_000_000 / bpm)).to_bytes(3, "big")
    trk += b"\x00\xFF\x58\x04\x04\x02\x18\x08"
    if not drums:
        trk += b"\x00" + bytes([0xC0 | ch, program & 0x7F])
    trk += b"\x00" + bytes([0xB0 | ch, 7, 127])
    last = 0
    for tick, _, data in msgs:
        trk += _vlq(tick - last) + data
        last = tick
    end = max(last, int(round((total_beats + tail_beats) * PPQ)))
    trk += _vlq(end - last) + b"\xFF\x2F\x00"
    header = b"MThd" + (6).to_bytes(4, "big") + (0).to_bytes(2, "big") + (1).to_bytes(2, "big") + PPQ.to_bytes(2, "big")
    return header + b"MTrk" + len(trk).to_bytes(4, "big") + bytes(trk)

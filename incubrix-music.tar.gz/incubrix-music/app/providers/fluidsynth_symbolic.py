"""FluidSynth + General MIDI SoundFont provider (default in Docker).

Each stem is written as its own MIDI file on the shared bar grid and rendered
independently with the ``fluidsynth`` CLI, so stems never bleed into each
other. If the binary or SoundFont is missing, rendering falls back to the
procedural synth and reports that honestly in the manifest.
"""
from __future__ import annotations

import os
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Any

import numpy as np

from ..arranger import Event, Grid
from ..audio_io import read_wav, resample_linear
from .base import TAIL_S, MusicGeneratorProvider, finalize_buffer
from .midi_writer import write_midi
from .procedural import ProceduralSynthProvider


class FluidSynthSymbolicProvider(MusicGeneratorProvider):
    name = "fluidsynth_symbolic"
    model_version = "fluidsynth-cli+GM"
    license = "FluidR3_GM SoundFont (permissive licence permitting commercial use; see SOURCES.md)"

    def __init__(self, soundfont: str | None = None, binary: str | None = None, timeout_s: float = 120.0) -> None:
        self.soundfont = soundfont or os.environ.get("SOUNDFONT_PATH", "/usr/share/sounds/sf2/FluidR3_GM.sf2")
        self.binary = binary or shutil.which("fluidsynth")
        self.timeout_s = timeout_s
        self._fallback = ProceduralSynthProvider()
        self._used_fallback = False

    def available(self) -> bool:
        return bool(self.binary) and Path(self.soundfont).is_file()

    @property
    def effective_name(self) -> str:
        return f"{self.name}(fallback:{self._fallback.name})" if self._used_fallback else self.name

    def render_stem(self, stem: str, events: list[Event], grid: Grid, style: dict[str, Any],
                    seed: int, loopable: bool) -> np.ndarray:
        if not self.available():
            self._used_fallback = True
            return self._fallback.render_stem(stem, events, grid, style, seed, loopable)
        sr, n = grid.sample_rate, grid.n_samples
        midi = write_midi(events, grid.bpm, grid.total_beats, int(style.get("gm", 0)), stem == "drums",
                          tail_beats=TAIL_S * grid.bpm / 60.0)
        with tempfile.TemporaryDirectory() as td:
            mid, wav = Path(td, "stem.mid"), Path(td, "stem.wav")
            mid.write_bytes(midi)
            cmd = [self.binary, "-ni", "-g", "0.8", "-r", str(sr), "-T", "wav", "-O", "float", "-F", str(wav), self.soundfont, str(mid)]
            try:
                subprocess.run(cmd, check=True, capture_output=True, timeout=self.timeout_s)
                data, file_sr = read_wav(str(wav))
            except (subprocess.SubprocessError, OSError, ValueError):
                self._used_fallback = True
                return self._fallback.render_stem(stem, events, grid, style, seed, loopable)
        mono = data.mean(axis=1) if data.ndim == 2 else data
        if file_sr != sr:
            mono = resample_linear(mono, file_sr, sr)
        want = n + int(TAIL_S * sr)
        buf = np.zeros(want)
        buf[: min(want, mono.size)] = mono[:want]
        return finalize_buffer(buf, n, loopable)

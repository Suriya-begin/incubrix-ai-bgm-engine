"""Fetch narration audio from an http(s) URL, an uploaded asset, or (if enabled) a local path."""
from __future__ import annotations

import ipaddress
import shutil
import socket
from pathlib import Path
from urllib.parse import urlparse

import httpx

from .config import Settings
from .storage import Storage, StorageError


class NarrationError(Exception):
    def __init__(self, code: str, message: str, retryable: bool = False, status: int = 422) -> None:
        super().__init__(message)
        self.code, self.message, self.retryable, self.status = code, message, retryable, status


def validate_narration_ref(ref: str, s: Settings) -> None:
    if ref.startswith("asset://"):
        if not ref[8:].isalnum():
            raise NarrationError("INVALID_NARRATION_URL", "asset:// id must be alphanumeric.")
        return
    p = urlparse(ref)
    if p.scheme in ("http", "https") and p.netloc:
        return
    if s.allow_local_narration_paths and (p.scheme in ("", "file")):
        return
    raise NarrationError("INVALID_NARRATION_URL", "narration_url must be an http(s) URL or an asset:// id from /api/v1/assets/upload.")


def _host_is_private(host: str) -> bool:
    try:
        infos = socket.getaddrinfo(host, None)
    except socket.gaierror:
        return False  # let the HTTP client report DNS failure
    for info in infos:
        ip = ipaddress.ip_address(info[4][0])
        if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved or ip.is_multicast:
            return True
    return False


def fetch_narration(ref: str, dest: Path, s: Settings, storage: Storage) -> Path:
    validate_narration_ref(ref, s)
    dest.parent.mkdir(parents=True, exist_ok=True)
    if ref.startswith("asset://"):
        try:
            storage.download_file(f"uploads/{ref[8:]}", dest)
        except StorageError as exc:
            raise NarrationError("NARRATION_FETCH_FAILED", f"Uploaded asset not found: {ref}", False) from exc
        return dest
    p = urlparse(ref)
    if p.scheme in ("", "file"):
        src = Path(p.path)
        if not src.is_file():
            raise NarrationError("NARRATION_FETCH_FAILED", "Local narration file not found.", False)
        shutil.copyfile(src, dest)
        return dest
    if not s.allow_private_narration_hosts and p.hostname and _host_is_private(p.hostname):
        raise NarrationError("INVALID_NARRATION_URL", "narration_url resolves to a private or loopback address, which is blocked.")
    try:
        with httpx.stream("GET", ref, timeout=s.narration_fetch_timeout_s, follow_redirects=False) as r:
            if r.status_code >= 400:
                raise NarrationError("NARRATION_FETCH_FAILED", f"narration_url returned HTTP {r.status_code}.", r.status_code >= 500)
            size = 0
            with open(dest, "wb") as fh:
                for chunk in r.iter_bytes(65536):
                    size += len(chunk)
                    if size > s.narration_max_bytes:
                        raise NarrationError("NARRATION_TOO_LARGE", f"Narration exceeds {s.narration_max_bytes} bytes.")
                    fh.write(chunk)
    except httpx.TimeoutException as exc:
        raise NarrationError("NARRATION_FETCH_TIMEOUT", "Timed out downloading narration_url.", True, 504) from exc
    except httpx.HTTPError as exc:
        raise NarrationError("NARRATION_FETCH_FAILED", f"Could not download narration_url: {type(exc).__name__}.", True) from exc
    return dest

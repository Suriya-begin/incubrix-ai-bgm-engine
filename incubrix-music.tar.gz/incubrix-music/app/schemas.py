"""Request/response models. Duration limits are checked in the route against env-configurable settings."""
from __future__ import annotations

from typing import Any, Literal, Optional, Union

from pydantic import BaseModel, ConfigDict, Field


class SectionIn(BaseModel):
    model_config = ConfigDict(extra="forbid")
    name: str = Field(min_length=1, max_length=64, examples=["intro"])
    start_s: float = Field(description="Section start in seconds; snapped to the nearest bar line.", examples=[0])
    energy: Optional[Union[float, Literal["low", "medium", "high"]]] = Field(default=None, description="0..1 or low/medium/high. Defaults from the section name.")


class OutputOptions(BaseModel):
    model_config = ConfigDict(extra="forbid")
    sample_rate: Literal[44100, 48000] = 48000
    bit_depth: Literal[16, 24] = 24
    target_lufs: float = Field(default=-16.0, ge=-30.0, le=-8.0)
    mp3_bitrate_kbps: int = Field(default=192, ge=96, le=320)
    duck_db: float = Field(default=-11.0, ge=-12.0, le=-10.0, description="Music attenuation while narration is speaking.")


class MusicJobRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    prompt: str = Field(min_length=1, max_length=2000, examples=["Warm cinematic strings, slow build"])
    duration_s: float = Field(examples=[30])
    sections: Optional[list[SectionIn]] = Field(default=None, max_length=64)
    tempo_bpm: Optional[float] = Field(default=None, ge=40, le=220)
    key: Optional[str] = Field(default=None, max_length=16, examples=["D minor"])
    loopable: bool = False
    seed: Optional[int] = Field(default=None, ge=0, le=2**31 - 1)
    narration_url: Optional[str] = Field(default=None, max_length=2048, description="http(s) URL or asset://<id> from /api/v1/assets/upload")
    callback_url: Optional[str] = Field(default=None, max_length=2048)
    output: OutputOptions = Field(default_factory=OutputOptions)


class RegenerateStemRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    stem: Literal["drums", "bass", "harmony", "melody"]
    seed: Optional[int] = Field(default=None, ge=0, le=2**31 - 1)
    prompt_override: Optional[str] = Field(default=None, max_length=2000)


class JobAccepted(BaseModel):
    job_id: str
    status: Literal["queued", "running", "succeeded", "failed"] = "queued"


class ErrorInfo(BaseModel):
    code: str
    message: str
    retryable: bool
    details: dict[str, Any] = {}


class ErrorResponse(BaseModel):
    error: ErrorInfo


class JobResult(BaseModel):
    files: dict[str, str] = Field(description="Relative output path to a time-limited download URL, e.g. 'stems/drums.wav'.")
    expires_in_s: int


class JobStatus(BaseModel):
    job_id: str
    kind: Literal["generate", "regenerate_stem"]
    status: Literal["queued", "running", "succeeded", "failed"]
    progress: int = Field(ge=0, le=100)
    result: Optional[JobResult] = None
    error: Optional[ErrorInfo] = None
    warnings: list[str] = []
    parent_job_id: Optional[str] = None
    created_at: float
    updated_at: float


class AssetUploaded(BaseModel):
    asset_id: str
    asset_url: str = Field(description="Pass as narration_url, e.g. asset://<id>")
    size_bytes: int
    download_url: str

"""Stem post-processing, mastering with stem-sum integrity, and voiceover ducking."""
from __future__ import annotations

import math
from typing import Any

import numpy as np

from .audio_io import dequantize, quantize
from .loudness import (db_to_lin, gated_lufs, integrated_lufs, k_weighted, limiter_gain, lin_to_db, peak_envelope,
                       true_peak_db)

STEM_PLACEMENT = {  # pan in [-1, 1], Haas delay in ms (0 = mono)
    "drums": (0.0, 0.0),
    "bass": (0.0, 0.0),
    "harmony": (0.0, 11.0),
    "melody": (0.2, 6.0),
}
RESIDUAL_FLOOR_DB = -300.0


# ---------------------------------------------------------------- stems
def normalize_peak(x: np.ndarray, peak: float = 0.9) -> np.ndarray:
    m = float(np.max(np.abs(x))) if x.size else 0.0
    return x * (peak / m) if m > 1e-9 else x


def fade_out_curve(n: int, sr: int, bar_s: float) -> np.ndarray:
    """Raised-cosine fade over the last 0.75 bar, exactly 0 at the final sample."""
    length = max(2, min(n, int(0.75 * bar_s * sr)))
    g = np.ones(n)
    x = np.linspace(0.0, 1.0, length)
    g[-length:] = 0.5 * (1.0 + np.cos(np.pi * x))
    return g


def _shift(x: np.ndarray, d: int, circular: bool) -> np.ndarray:
    if d == 0:
        return x
    if circular:
        return np.roll(x, d)
    out = np.zeros_like(x)
    out[d:] = x[:-d]
    return out


def to_stereo(mono: np.ndarray, stem: str, sr: int, loopable: bool) -> np.ndarray:
    pan, haas_ms = STEM_PLACEMENT[stem]
    theta = (pan + 1.0) * math.pi / 4.0
    left = mono * math.cos(theta)
    right = _shift(mono, int(round(haas_ms * 1e-3 * sr)), loopable) * math.sin(theta)
    return np.stack([left, right], axis=1)


def prepare_stem(raw_mono: np.ndarray, stem: str, sr: int, loopable: bool, bar_s: float, weight: float) -> np.ndarray:
    x = normalize_peak(raw_mono)
    if not loopable:
        x = x * fade_out_curve(x.shape[0], sr, bar_s)
    return (to_stereo(x, stem, sr, loopable) * weight).astype(np.float32)


# ---------------------------------------------------------------- mastering
def master(stems_w: dict[str, np.ndarray], sr: int, target_lufs: float, ceiling_db: float,
           loopable: bool, iters: int = 5) -> dict[str, Any]:
    """Scale all stems by one scalar and one limiter curve so sum(stems) == mix."""
    names = list(stems_w)
    mix0 = sum(stems_w[k].astype(np.float64) for k in names)
    l0 = integrated_lufs(mix0, sr)
    if l0 <= -100.0:
        return {"scale": 1.0, "limiter": np.ones(mix0.shape[0]), "stems": stems_w, "mix": mix0, "silent": True}
    scale = db_to_lin(target_lufs - l0)
    pk0 = peak_envelope(mix0)   # linear in gain, so reused for every iteration
    kw0 = k_weighted(mix0, sr)  # K-weighting is linear too; the limiter gain is applied on top of it
    for _ in range(iters):
        g = limiter_gain(None, sr, ceiling_db, wrap=loopable, pk=pk0 * scale)
        err = target_lufs - gated_lufs(kw0 * (scale * g[:, None]), sr)
        if abs(err) <= 0.02:
            break
        scale *= db_to_lin(err)
    g = limiter_gain(None, sr, ceiling_db, wrap=loopable, pk=pk0 * scale)
    err = target_lufs - integrated_lufs(mix0 * (scale * g[:, None]), sr)   # exact check on the real signal
    if abs(err) > 0.02:
        scale *= db_to_lin(err)
        g = limiter_gain(None, sr, ceiling_db, wrap=loopable, pk=pk0 * scale)
    del kw0
    stems = {k: (stems_w[k] * (scale * g[:, None]).astype(np.float32)) for k in names}
    return {"scale": scale, "limiter": g, "stems": stems, "mix": None, "silent": False}


def quantize_stems(stems: dict[str, np.ndarray], bits: int) -> tuple[dict[str, np.ndarray], np.ndarray]:
    """Quantize every stem, then define the mix as the exact integer sum of the stem files."""
    q = {k: quantize(v, bits) for k, v in stems.items()}
    total = sum(v.astype(np.int64) for v in q.values())
    lim = (1 << (bits - 1))
    mix_q = np.clip(total, -lim, lim - 1).astype(np.int32)
    return q, mix_q


def residual_db(stems_q: dict[str, np.ndarray], mix_q: np.ndarray, bits: int) -> float:
    total = sum(dequantize(v, bits) for v in stems_q.values())
    mix = dequantize(mix_q, bits)
    diff = float(np.sqrt(np.mean((total - mix) ** 2)))
    ref = float(np.sqrt(np.mean(mix ** 2)))
    if diff <= 0 or ref <= 0:
        return RESIDUAL_FLOOR_DB
    return max(RESIDUAL_FLOOR_DB, 20 * math.log10(diff / ref))


def loudness_report(mix_float: np.ndarray, sr: int) -> dict[str, float]:
    return {"integrated_lufs": round(integrated_lufs(mix_float, sr), 3), "true_peak_dbtp": round(true_peak_db(mix_float), 3)}


def loop_click_ratio(mix: np.ndarray) -> float:
    """Boundary jump divided by the 99.9th percentile sample-to-sample step (<= ~1.5 means no click)."""
    x = mix.reshape(mix.shape[0], -1)
    jump = float(np.max(np.abs(x[0] - x[-1])))
    steps = np.abs(np.diff(x, axis=0))
    ref = float(np.percentile(steps, 99.9)) or 1e-12
    return jump / ref


# ---------------------------------------------------------------- ducking
HOP_S = 0.010


def _rdp(t: np.ndarray, y: np.ndarray, eps: float) -> list[int]:
    keep = {0, len(t) - 1}
    stack = [(0, len(t) - 1)]
    while stack:
        i, j = stack.pop()
        if j <= i + 1:
            continue
        seg_t, seg_y = t[i + 1:j], y[i + 1:j]
        line = y[i] + (y[j] - y[i]) * (seg_t - t[i]) / (t[j] - t[i])
        dev = np.abs(seg_y - line)
        k = int(np.argmax(dev))
        if dev[k] > eps:
            m = i + 1 + k
            keep.add(m)
            stack += [(i, m), (m, j)]
    return sorted(keep)


def detect_speech(narr: np.ndarray, sr: int) -> dict[str, Any]:
    hop = int(HOP_S * sr)
    nf = narr.shape[0] // hop
    if nf < 3:
        return {"active": np.zeros(0, dtype=bool), "segments": [], "ratio": 0.0}
    frames = narr[: nf * hop].reshape(nf, hop)
    db = 10 * np.log10(np.mean(frames ** 2, axis=1) + 1e-12)
    pk, floor = float(np.percentile(db, 95)), float(np.percentile(db, 10))
    if pk < -55.0:
        return {"active": np.zeros(nf, dtype=bool), "segments": [], "ratio": 0.0}
    thr = max(-50.0, pk - 30.0, floor + 10.0)
    act = db > thr

    def runs(mask: np.ndarray, value: bool) -> list[tuple[int, int]]:
        edges = np.flatnonzero(np.diff(np.concatenate([[not value], mask == value, [not value]]).astype(int)))
        return [(int(a), int(b)) for a, b in zip(edges[::2], edges[1::2])]

    for a, b in runs(act, True):          # drop clicks shorter than 60 ms
        if b - a < 6:
            act[a:b] = False
    for a, b in runs(act, False):         # bridge gaps shorter than 250 ms between speech
        if a > 0 and b < nf and b - a < 25:
            act[a:b] = True
    segs = [{"start_s": round(a * HOP_S, 3), "end_s": round(b * HOP_S, 3)} for a, b in runs(act, True)]
    return {"active": act, "segments": segs, "ratio": float(act.mean())}


def ducking_curve(active: np.ndarray, duration_s: float, depth_db: float = -11.0, attack_ms: float = 80.0,
                  release_ms: float = 350.0, lookahead_ms: float = 80.0) -> list[dict[str, float]]:
    """Smoothed duck gain in dB as a compact list of {time_s, gain_db} breakpoints."""
    nf = int(math.ceil(duration_s / HOP_S)) + 1
    target = np.zeros(nf)
    act = active[:nf]
    target[: act.shape[0]] = np.where(act, depth_db, 0.0)
    la = int(round(lookahead_ms / (HOP_S * 1000)))
    if la:
        target = np.concatenate([target[la:], np.zeros(la)])
    att = 1 - math.exp(-HOP_S * 1000 / (attack_ms / 3.0))
    rel = 1 - math.exp(-HOP_S * 1000 / (release_ms / 3.0))
    g = np.zeros(nf)
    cur = 0.0
    for i in range(nf):
        tgt = target[i]
        cur += (tgt - cur) * (att if tgt < cur else rel)
        g[i] = cur
    t = np.arange(nf) * HOP_S
    t[-1] = duration_s
    idx = _rdp(t, g, 0.1)
    return [{"time_s": round(float(t[i]), 4), "gain_db": round(float(g[i]), 3)} for i in idx]


def curve_to_gain(curve: list[dict[str, float]], n: int, sr: int) -> np.ndarray:
    t = np.array([p["time_s"] for p in curve])
    g = np.array([p["gain_db"] for p in curve])
    return 10 ** (np.interp(np.arange(n) / sr, t, g) / 20.0)


def prepare_narration(narr: np.ndarray, n: int, sr: int, warnings: list[str]) -> np.ndarray:
    if narr.shape[0] > n:
        warnings.append(f"NARRATION_LONGER_THAN_MUSIC: narration is {narr.shape[0] / sr:.2f}s, music is {n / sr:.2f}s; speech after the music ends was ignored.")
        return narr[:n]
    if narr.shape[0] < n:
        warnings.append(f"NARRATION_SHORTER_THAN_MUSIC: narration is {narr.shape[0] / sr:.2f}s, music is {n / sr:.2f}s; music is un-ducked after narration ends.")
        return np.pad(narr, (0, n - narr.shape[0]))
    return narr


def build_ducking(narr_raw: np.ndarray, n: int, sr: int, duration_s: float, depth_db: float,
                  warnings: list[str]) -> dict[str, Any]:
    narr = prepare_narration(narr_raw, n, sr, warnings)
    det = detect_speech(narr, sr)
    if not det["segments"]:
        warnings.append("NARRATION_NO_SPEECH: no speech detected in narration; returned the un-ducked mix.")
        curve = [{"time_s": 0.0, "gain_db": 0.0}, {"time_s": round(duration_s, 4), "gain_db": 0.0}]
    else:
        curve = ducking_curve(det["active"], duration_s, depth_db)
    return {"curve": curve, "segments": det["segments"][:500], "speech_ratio": round(det["ratio"], 4),
            "depth_db": depth_db, "attack_ms": 80.0, "release_ms": 350.0, "lookahead_ms": 80.0}

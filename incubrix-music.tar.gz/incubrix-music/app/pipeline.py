"""End-to-end generation and single-stem regeneration (no web framework imports)."""
from __future__ import annotations

import copy
import hashlib
import json
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import numpy as np

from . import arranger, planner
from .arranger import STEMS, grid_from_plan
from .audio_io import AudioError, decode_to_mono, dequantize, encode_mp3, quantize, read_wav_pcm, write_wav
from .audio_processor import (RESIDUAL_FLOOR_DB, build_ducking, curve_to_gain, loop_click_ratio, loudness_report, master,
                              prepare_stem, quantize_stems, residual_db)
from .loudness import db_to_lin, integrated_lufs, lin_to_db, limiter_gain, true_peak_db
from .providers.base import MusicGeneratorProvider

PEAK_CEILING_DB = -1.5      # limiter target
PEAK_LIMIT_DB = -1.0        # hard requirement
DEFAULT_TARGET_LUFS = -16.0
STEM_INSTRUMENT = {"drums": "drum kit", "bass": "bass", "harmony": "chords/pad", "melody": "lead/arpeggio"}


@dataclass
class GenerationResult:
    manifest: dict[str, Any]
    files: dict[str, Path] = field(default_factory=dict)   # relative path -> local path


def _ms(t0: float) -> float:
    return round((time.perf_counter() - t0) * 1000.0, 2)


def _db_str(x: float) -> float:
    return round(x, 3)


def _licenses(provider: MusicGeneratorProvider) -> list[dict[str, str]]:
    return [
        {"component": f"music provider: {provider.name}", "license": provider.license, "url": "see SOURCES.md"},
        {"component": "numpy / scipy", "license": "BSD-3-Clause", "url": "https://numpy.org/ , https://scipy.org/"},
        {"component": "pyloudnorm", "license": "MIT", "url": "https://github.com/csteinmetz1/pyloudnorm"},
        {"component": "ffmpeg (MP3 encode, narration decode)", "license": "LGPL/GPL build dependent", "url": "https://ffmpeg.org/legal.html"},
    ]


def _estimated_cost(cpu_seconds: float, usd_per_cpu_hour: float) -> float:
    return round(cpu_seconds / 3600.0 * usd_per_cpu_hour, 6)


def _write_outputs(out_dir: Path, stems_q: dict[str, np.ndarray], mix_q: np.ndarray, sr: int, bits: int,
                   mp3_kbps: int, ducked: np.ndarray | None, only_stems: tuple[str, ...] | None = None) -> dict[str, Path]:
    files: dict[str, Path] = {}
    for name, q in stems_q.items():
        if only_stems is not None and name not in only_stems:
            continue
        p = out_dir / "stems" / f"{name}.wav"
        write_wav(p, q, sr, bits)
        files[f"stems/{name}.wav"] = p
    p = out_dir / "mix.wav"
    write_wav(p, mix_q, sr, bits)
    files["mix.wav"] = p
    encode_mp3(dequantize(mix_q, bits), sr, out_dir / "mix.mp3", mp3_kbps)
    files["mix.mp3"] = out_dir / "mix.mp3"
    if ducked is not None:
        dq = quantize(ducked, bits)
        write_wav(out_dir / "mix_ducked.wav", dq, sr, bits)
        files["mix_ducked.wav"] = out_dir / "mix_ducked.wav"
    return files


def _stem_entries(plan: dict[str, Any], provider_info: dict[str, str], weights: dict[str, float], scale: float,
                  seeds: dict[str, int], extra: dict[str, Any] | None = None) -> list[dict[str, Any]]:
    out = []
    for s in STEMS:
        eff = weights[s] * scale
        st = plan["styles"][s]
        out.append({
            "name": s,
            "instrument": f"{STEM_INSTRUMENT[s]} ({st.get('timbre')}; GM {st.get('gm', 'kit')})",
            "gain_linear": round(eff, 6),
            "gain_db": _db_str(lin_to_db(eff)),
            "mix_weight_linear": round(weights[s], 4),
            "seed": seeds[s],
            "provider": provider_info["provider"],
            "model_version": provider_info["model_version"],
            "license": provider_info["license"],
            **(extra or {}),
        })
    return out


def generate(req: dict[str, Any], provider: MusicGeneratorProvider, out_dir: str | Path, *, job_id: str,
             min_duration_s: float = 5.0, max_duration_s: float = 300.0, usd_per_cpu_hour: float = 0.04,
             narration_path: str | Path | None = None) -> GenerationResult:
    t_total = time.perf_counter()
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    opts = req.get("output") or {}
    sr = int(opts.get("sample_rate", 48000))
    bits = int(opts.get("bit_depth", 24))
    target_lufs = float(opts.get("target_lufs", DEFAULT_TARGET_LUFS))
    mp3_kbps = int(opts.get("mp3_bitrate_kbps", 192))
    duck_depth = float(opts.get("duck_db", -11.0))

    t0 = time.perf_counter()
    plan = planner.plan(req["prompt"], float(req["duration_s"]), req.get("sections"), req.get("tempo_bpm"), req.get("key"),
                        bool(req.get("loopable", False)), req.get("seed"), min_duration_s, max_duration_s)
    grid = grid_from_plan(plan, sr)
    events = arranger.build_all(plan)
    t_plan = _ms(t0)

    t0 = time.perf_counter()
    raw = {s: provider.render_stem(s, events[s], grid, plan["styles"][s], plan["seed"], plan["loopable"]) for s in STEMS}
    t_render = _ms(t0)

    t0 = time.perf_counter()
    weights = plan["stem_gains"]
    weighted = {s: prepare_stem(raw[s], s, sr, plan["loopable"], grid.bar_s, weights[s]) for s in STEMS}
    del raw
    m = master(weighted, sr, target_lufs, PEAK_CEILING_DB, plan["loopable"])
    del weighted
    stems_q, mix_q = quantize_stems(m["stems"], bits)
    mix_f = dequantize(mix_q, bits)

    warnings = list(plan["warnings"])
    ducking = None
    ducked = None
    if narration_path:
        try:
            narr = decode_to_mono(narration_path, sr)
        except AudioError as exc:
            raise
        ducking = build_ducking(narr, grid.n_samples, sr, plan["duration_s"], duck_depth, warnings)
        gain = curve_to_gain(ducking["curve"], grid.n_samples, sr)
        ducked = mix_f * gain[:, None]
    files = _write_outputs(out, stems_q, mix_q, sr, bits, mp3_kbps, ducked)

    loud = loudness_report(mix_f, sr)
    if abs(loud["integrated_lufs"] - target_lufs) > 0.5:
        warnings.append(f"LOUDNESS_TARGET_MISSED: measured {loud['integrated_lufs']} LUFS vs target {target_lufs}.")
    loud["stem_sum_residual_db"] = round(residual_db(stems_q, mix_q, bits), 3)
    loud["target_lufs"] = target_lufs
    loud["global_scale_linear"] = round(m["scale"], 8)
    if plan["loopable"]:
        loud["loop_click_ratio"] = round(loop_click_ratio(mix_f), 3)
    t_mix = _ms(t0)

    seeds = {s: plan["seed"] for s in STEMS}
    info = provider.info()
    # the limiter curve is kept so a regenerated stem can reuse it
    np.savez_compressed(out / "internal_limiter_gain.npz", g=m["limiter"].astype(np.float32))
    files["internal/limiter_gain.npz"] = out / "internal_limiter_gain.npz"

    manifest: dict[str, Any] = {
        "job_id": job_id,
        "ai_generated": True,
        "prompt": req["prompt"],
        "prompt_effective": plan["prompt_effective"],
        "tempo_bpm": round(plan["tempo_bpm"], 4),
        "tempo_requested_bpm": plan["tempo_requested_bpm"],
        "key": plan["key"],
        "time_signature": plan["time_signature"],
        "loopable": plan["loopable"],
        "duration_requested_s": plan["duration_s"],
        "duration_actual_s": round(mix_q.shape[0] / sr, 6),
        "sample_rate": sr,
        "bit_depth": bits,
        "bars": plan["bars"],
        "sections": [{"name": s["name"], "planned_start_s": s["planned_start_s"], "actual_start_s": s["start_s"], "end_s": s["end_s"],
                      "start_bar": s["start_bar"] + 1, "bars": s["bars"], "energy": s["energy"]} for s in plan["sections"]],
        "beat_grid_s": grid.beat_grid_s(),
        "bar_grid_s": grid.bar_grid_s(),
        "chords": [c["name"] for c in plan["chords"]],
        "mood": plan["mood"],
        "stems": _stem_entries(plan, info, weights, m["scale"], seeds),
        "loudness": loud,
        "seed": plan["seed"],
        "warnings": warnings,
        "licenses": _licenses(provider),
        "plan": plan,
        "regenerations": [],
    }
    if ducking:
        manifest["ducking"] = {k: v for k, v in ducking.items() if k != "curve"}
        manifest["ducking_curve"] = ducking["curve"]
    total_ms = _ms(t_total)
    manifest["timings_ms"] = {"planning": t_plan, "rendering": t_render, "mixing": t_mix, "upload": 0.0, "total": total_ms}
    manifest["estimated_cost_usd"] = _estimated_cost(total_ms / 1000.0, usd_per_cpu_hour)
    (out / "music_manifest.json").write_text(json.dumps(manifest, indent=2))
    files["music_manifest.json"] = out / "music_manifest.json"
    return GenerationResult(manifest, files)


def _file_sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def regenerate_stem(source_dir: str | Path, manifest: dict[str, Any], stem: str, provider: MusicGeneratorProvider,
                    out_dir: str | Path, *, job_id: str, seed: int | None = None, prompt_override: str | None = None,
                    usd_per_cpu_hour: float = 0.04) -> GenerationResult:
    """Re-render ONE stem on the original tempo/key/bar grid.

    ``source_dir`` holds the original ``stems/*.wav`` and ``internal_limiter_gain.npz``.
    The other stems are copied byte for byte; the mix is the exact sum of all four stem files.
    """
    if stem not in STEMS:
        raise ValueError(f"stem must be one of {STEMS}")
    t_total = time.perf_counter()
    src, out = Path(source_dir), Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    plan = copy.deepcopy(manifest["plan"])
    sr, bits = int(manifest["sample_rate"]), int(manifest["bit_depth"])
    extra_warnings: list[str] = []

    t0 = time.perf_counter()
    if prompt_override:
        plan, extra_warnings = planner.apply_prompt_override(plan, stem, prompt_override)
    new_seed = int(seed) if seed is not None else int(plan["seed"])
    grid = grid_from_plan(plan, sr)
    events = arranger.build_events(plan, stem, seed=new_seed)
    t_plan = _ms(t0)

    t0 = time.perf_counter()
    raw = provider.render_stem(stem, events, grid, plan["styles"][stem], new_seed, plan["loopable"])
    t_render = _ms(t0)

    t0 = time.perf_counter()
    old_pcm, _, _ = read_wav_pcm(src / "stems" / f"{stem}.wav")
    old_f = dequantize(old_pcm, bits)
    scale = float(manifest["loudness"]["global_scale_linear"])
    weights = plan["stem_gains"]
    lim = np.load(src / "internal_limiter_gain.npz")["g"].astype(np.float64)
    new = prepare_stem(raw, stem, sr, plan["loopable"], grid.bar_s, weights[stem]) * scale * lim[:, None]
    # loudness-match to the stem it replaces so the mix level does not drift
    l_old, l_new = integrated_lufs(old_f, sr), integrated_lufs(new, sr)
    match_db = float(np.clip(l_old - l_new, -12.0, 12.0)) if l_old > -100 and l_new > -100 else 0.0
    new = new * db_to_lin(match_db)

    others_q: dict[str, np.ndarray] = {}
    for s in STEMS:
        if s != stem:
            others_q[s], _, _ = read_wav_pcm(src / "stems" / f"{s}.wav")
    for _ in range(4):  # keep the new mix under -1 dBTP by trimming only the new stem
        new_q = quantize(new, bits)
        stems_q = {**others_q, stem: new_q}
        _, mix_q = quantize_stems({k: dequantize(v, bits) for k, v in stems_q.items()}, bits)
        tp = true_peak_db(dequantize(mix_q, bits))
        if tp <= PEAK_LIMIT_DB:
            break
        new = new * db_to_lin(PEAK_CEILING_DB - tp)
        match_db += PEAK_CEILING_DB - tp
    mix_f = dequantize(mix_q, bits)

    ducked = None
    if manifest.get("ducking_curve"):
        ducked = mix_f * curve_to_gain(manifest["ducking_curve"], mix_q.shape[0], sr)[:, None]

    files = _write_outputs(out, stems_q, mix_q, sr, bits, int(manifest.get("mp3_bitrate_kbps", 192)), ducked, only_stems=(stem,))
    for s in STEMS:
        if s != stem:  # untouched stems: byte-identical copies
            dst = out / "stems" / f"{s}.wav"
            dst.parent.mkdir(parents=True, exist_ok=True)
            dst.write_bytes((src / "stems" / f"{s}.wav").read_bytes())
            files[f"stems/{s}.wav"] = dst
    np.savez_compressed(out / "internal_limiter_gain.npz", g=lim.astype(np.float32))
    files["internal/limiter_gain.npz"] = out / "internal_limiter_gain.npz"

    new_manifest = copy.deepcopy(manifest)
    new_manifest["job_id"] = job_id
    new_manifest["plan"] = plan
    new_manifest["warnings"] = list(manifest.get("warnings", [])) + extra_warnings
    for entry in new_manifest["stems"]:
        if entry["name"] == stem:
            eff = weights[stem] * scale * db_to_lin(match_db)
            entry.update(gain_linear=round(eff, 6), gain_db=_db_str(lin_to_db(eff)), seed=new_seed,
                         instrument=f"{STEM_INSTRUMENT[stem]} ({plan['styles'][stem].get('timbre')}; GM {plan['styles'][stem].get('gm', 'kit')})",
                         provider=provider.info()["provider"], regenerated=True)
    loud = loudness_report(mix_f, sr)
    loud.update({k: manifest["loudness"][k] for k in ("target_lufs", "global_scale_linear") if k in manifest["loudness"]})
    loud["stem_sum_residual_db"] = round(residual_db(stems_q, mix_q, bits), 3)
    if abs(loud["integrated_lufs"] - loud.get("target_lufs", DEFAULT_TARGET_LUFS)) > 0.5:
        new_manifest["warnings"].append(f"LOUDNESS_DRIFT: regenerated mix measures {loud['integrated_lufs']} LUFS; other stems were left untouched by design.")
    new_manifest["loudness"] = loud
    new_manifest["regenerations"] = list(manifest.get("regenerations", [])) + [
        {"stem": stem, "seed": new_seed, "prompt_override": prompt_override, "source_job_id": manifest["job_id"],
         "unchanged_stem_sha256": {s: _file_sha(out / "stems" / f"{s}.wav") for s in STEMS if s != stem}}]
    total_ms = _ms(t_total)
    new_manifest["timings_ms"] = {"planning": t_plan, "rendering": t_render, "mixing": _ms(t0), "upload": 0.0, "total": total_ms}
    new_manifest["estimated_cost_usd"] = _estimated_cost(total_ms / 1000.0, usd_per_cpu_hour)
    (out / "music_manifest.json").write_text(json.dumps(new_manifest, indent=2))
    files["music_manifest.json"] = out / "music_manifest.json"
    return GenerationResult(new_manifest, files)

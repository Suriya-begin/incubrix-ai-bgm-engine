"""ITU-R BS.1770-4 loudness, 4x-oversampled true peak, and a look-ahead limiter.

``pyloudnorm`` is used when installed (it is in requirements.txt). A built-in
implementation of the same K-weighting and gating is used only if the import
fails, so the engine can still run in minimal environments.
"""
from __future__ import annotations

import math

import numpy as np
from scipy.ndimage import minimum_filter1d, uniform_filter1d
from scipy.signal import lfilter, resample_poly

try:  # pragma: no cover - exercised when pyloudnorm is installed
    import pyloudnorm as _pyln
except Exception:  # noqa: BLE001
    _pyln = None

FLOOR_DB = -120.0


def _biquad_shelf(fs: float, g_db: float, q: float, fc: float) -> tuple[np.ndarray, np.ndarray]:
    a = 10 ** (g_db / 40.0)
    w0 = 2 * math.pi * fc / fs
    alpha = math.sin(w0) / (2.0 * q)
    c = math.cos(w0)
    sa = math.sqrt(a)
    b = np.array([a * ((a + 1) + (a - 1) * c + 2 * sa * alpha), -2 * a * ((a - 1) + (a + 1) * c), a * ((a + 1) + (a - 1) * c - 2 * sa * alpha)])
    den = np.array([(a + 1) - (a - 1) * c + 2 * sa * alpha, 2 * ((a - 1) - (a + 1) * c), (a + 1) - (a - 1) * c - 2 * sa * alpha])
    return b / den[0], den / den[0]


def _biquad_highpass(fs: float, q: float, fc: float) -> tuple[np.ndarray, np.ndarray]:
    w0 = 2 * math.pi * fc / fs
    alpha = math.sin(w0) / (2.0 * q)
    c = math.cos(w0)
    b = np.array([(1 + c) / 2, -(1 + c), (1 + c) / 2])
    den = np.array([1 + alpha, -2 * c, 1 - alpha])
    return b / den[0], den / den[0]


def _k_weight(x: np.ndarray, fs: int) -> np.ndarray:
    b1, a1 = _biquad_shelf(fs, 3.99984385397, 0.7071752369554193, 1681.9744509555319)
    b2, a2 = _biquad_highpass(fs, 0.5003270373253953, 38.13547087613982)
    return lfilter(b2, a2, lfilter(b1, a1, x, axis=0), axis=0)


def _internal_lufs(x: np.ndarray, fs: int) -> float:
    return gated_lufs(_k_weight(x, fs), fs)


def k_weighted(x: np.ndarray, fs: int) -> np.ndarray:
    """K-weighted signal; loudness is linear in it, so callers can reuse it across gain changes."""
    return _k_weight(x.reshape(-1, 1) if x.ndim == 1 else x, fs)


def gated_lufs(y: np.ndarray, fs: int) -> float:
    """BS.1770-4 gated integrated loudness of an already K-weighted signal (n, ch)."""
    block, step = int(0.4 * fs), int(0.1 * fs)
    if y.shape[0] < block:
        return FLOOR_DB
    csum = np.vstack([np.zeros((1, y.shape[1])), np.cumsum(y ** 2, axis=0)])
    starts = np.arange(0, y.shape[0] - block + 1, step)
    z = (csum[starts + block] - csum[starts]) / block          # (blocks, ch)
    zs = z.sum(axis=1)                                         # L/R weights are 1.0
    with np.errstate(divide="ignore"):
        lj = -0.691 + 10 * np.log10(np.maximum(zs, 1e-30))
    keep = lj > -70.0
    if not keep.any():
        return FLOOR_DB
    rel = -0.691 + 10 * math.log10(zs[keep].mean()) - 10.0
    keep &= lj > rel
    if not keep.any():
        return FLOOR_DB
    return -0.691 + 10 * math.log10(zs[keep].mean())


def integrated_lufs(x: np.ndarray, fs: int) -> float:
    """Integrated loudness of float audio shaped (n,) or (n, ch)."""
    x = x.reshape(-1, 1) if x.ndim == 1 else x
    if x.shape[0] < int(0.4 * fs) or not np.any(x):
        return FLOOR_DB
    if _pyln is not None:
        v = float(_pyln.Meter(fs).integrated_loudness(x))
        return FLOOR_DB if not math.isfinite(v) else v
    return _internal_lufs(x, fs)


def peak_envelope(x: np.ndarray, oversample: int = 4, chunk: int = 1 << 19, pad: int = 4096) -> np.ndarray:
    """Per-sample true-peak estimate (max over channels, 4x oversampled), computed in chunks to bound memory."""
    x = x.reshape(-1, 1) if x.ndim == 1 else x
    n = x.shape[0]
    out = np.empty(n)
    for a in range(0, n, chunk):
        b = min(n, a + chunk)
        lo, hi = max(0, a - pad), min(n, b + pad)
        up = resample_poly(x[lo:hi].astype(np.float64), oversample, 1, axis=0)
        env = np.abs(up).max(axis=1).reshape(hi - lo, oversample).max(axis=1)
        out[a:b] = env[a - lo:a - lo + (b - a)]
    return out


def true_peak_db(x: np.ndarray) -> float:
    if not np.any(x):
        return FLOOR_DB
    pk = float(peak_envelope(x).max())
    return 20 * math.log10(max(pk, 1e-12))


def db_to_lin(db: float) -> float:
    return 10 ** (db / 20.0)


def lin_to_db(v: float) -> float:
    return 20 * math.log10(max(v, 1e-12))


def limiter_gain(x: np.ndarray | None, sr: int, ceiling_db: float, lookahead_ms: float = 10.0, wrap: bool = False,
                 pk: np.ndarray | None = None) -> np.ndarray:
    """Time-varying gain (<= 1) that keeps the true peak under ``ceiling_db``.

    The same curve can be applied to every stem so that sum(stems) stays equal
    to the mix. ``wrap`` treats the signal as circular for seamless loops.
    ``pk`` is an optional precomputed per-sample true-peak envelope (it scales
    linearly with gain, so callers can reuse it across iterations).
    """
    if pk is None:
        pk = peak_envelope(x)
    n = pk.shape[0]
    ceil = db_to_lin(ceiling_db)
    need = np.minimum(1.0, ceil / np.maximum(pk, 1e-12))
    if need.min() >= 1.0:
        return np.ones(n)
    size = max(3, int(lookahead_ms * 1e-3 * sr)) | 1
    mode = "wrap" if wrap else "nearest"
    g = uniform_filter1d(minimum_filter1d(need, size=size, mode=mode), size=size, mode=mode)
    return np.minimum(g, 1.0)

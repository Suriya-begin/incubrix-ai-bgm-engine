"""S3-compatible object storage (MinIO). Presigned URLs use the public endpoint."""
from __future__ import annotations

import mimetypes
from pathlib import Path

import boto3
from botocore.client import Config
from botocore.exceptions import BotoCoreError, ClientError

from .config import Settings

CONTENT_TYPES = {".wav": "audio/wav", ".mp3": "audio/mpeg", ".json": "application/json"}


class StorageError(RuntimeError):
    pass


class Storage:
    def __init__(self, s: Settings) -> None:
        self.s = s
        cfg = Config(signature_version="s3v4", s3={"addressing_style": "path"}, connect_timeout=5, read_timeout=30, retries={"max_attempts": 3})
        kw = dict(aws_access_key_id=s.s3_access_key, aws_secret_access_key=s.s3_secret_key, region_name=s.s3_region, config=cfg)
        self.client = boto3.client("s3", endpoint_url=s.s3_endpoint_url, **kw)
        self.public = boto3.client("s3", endpoint_url=s.s3_public_endpoint_url, **kw)
        self.bucket = s.s3_bucket

    def ensure_bucket(self) -> None:
        try:
            self.client.head_bucket(Bucket=self.bucket)
        except ClientError:
            try:
                self.client.create_bucket(Bucket=self.bucket)
            except ClientError as exc:
                if exc.response.get("Error", {}).get("Code") not in ("BucketAlreadyOwnedByYou", "BucketAlreadyExists"):
                    raise StorageError(str(exc)) from exc

    def ping(self) -> bool:
        try:
            self.client.head_bucket(Bucket=self.bucket)
            return True
        except (ClientError, BotoCoreError):
            return False

    def upload_file(self, local: str | Path, key: str) -> None:
        ctype = CONTENT_TYPES.get(Path(local).suffix, mimetypes.guess_type(str(local))[0] or "application/octet-stream")
        try:
            self.client.upload_file(str(local), self.bucket, key, ExtraArgs={"ContentType": ctype})
        except (ClientError, BotoCoreError) as exc:
            raise StorageError(str(exc)) from exc

    def put_bytes(self, data: bytes, key: str, content_type: str = "application/octet-stream") -> None:
        try:
            self.client.put_object(Bucket=self.bucket, Key=key, Body=data, ContentType=content_type)
        except (ClientError, BotoCoreError) as exc:
            raise StorageError(str(exc)) from exc

    def download_file(self, key: str, local: str | Path) -> None:
        Path(local).parent.mkdir(parents=True, exist_ok=True)
        try:
            self.client.download_file(self.bucket, key, str(local))
        except (ClientError, BotoCoreError) as exc:
            raise StorageError(str(exc)) from exc

    def exists(self, key: str) -> bool:
        try:
            self.client.head_object(Bucket=self.bucket, Key=key)
            return True
        except ClientError:
            return False

    def presign(self, key: str, ttl: int | None = None) -> str:
        try:
            return self.public.generate_presigned_url("get_object", Params={"Bucket": self.bucket, "Key": key}, ExpiresIn=ttl or self.s.presign_ttl_s)
        except (ClientError, BotoCoreError) as exc:
            raise StorageError(str(exc)) from exc

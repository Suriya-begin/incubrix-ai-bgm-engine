"""Deterministic bar-grid arranger.

Turns a plan (see planner.plan) into per-stem note events on one shared
beat/bar grid. Events are expressed in beats, never in seconds, so every
stem is locked to the same grid and a single stem can be regenerated
without touching tempo, key or bar lines.
"""
from __future__ import annotations

import random
from dataclasses import dataclass
from typing import Any, NamedTuple

import numpy as np

from .planner import BEATS_PER_BAR, MODES, scale_pcs, stable_int

STEMS = ("drums", "bass", "harmony", "melody")

KICK, SNARE, CLAP, HAT_C, HAT_O, TOM, CRASH, SHAKER = 36, 38, 39, 42, 46, 45, 49, 70


class Event(NamedTuple):
    beat: float       # absolute beat position from the start of bar 1
    dur_beats: float
    pitch: int        # MIDI note (drum note numbers for the drums stem)
    vel: float        # 0..1
    tag: str = ""


@dataclass(frozen=True)
class Grid:
    bpm: float
    bars: int
    sample_rate: int
    duration_s: float
    beats_per_bar: int = BEATS_PER_BAR

    @property
    def beat_s(self) -> float:
        return 60.0 / self.bpm

    @property
    def bar_s(self) -> float:
        return self.beat_s * self.beats_per_bar

    @property
    def total_beats(self) -> int:
        return self.bars * self.beats_per_bar

    @property
    def n_samples(self) -> int:
        return int(round(self.duration_s * self.sample_rate))

    def beat_to_sample(self, beat: float) -> int:
        return int(round(beat * self.beat_s * self.sample_rate))

    def beat_grid_s(self) -> list[float]:
        return [round(i * self.beat_s, 6) for i in range(self.total_beats + 1)]

    def bar_grid_s(self) -> list[float]:
        return [round(i * self.bar_s, 6) for i in range(self.bars + 1)]


def grid_from_plan(plan: dict[str, Any], sample_rate: int) -> Grid:
    return Grid(bpm=plan["tempo_bpm"], bars=plan["bars"], sample_rate=sample_rate, duration_s=plan["duration_s"])


def stem_rng(seed: int, stem: str) -> random.Random:
    return random.Random(stable_int(seed, stem, bits=48))


# --------------------------------------------------------------------------
# Drums
# --------------------------------------------------------------------------
# 16-step patterns, per groove: (light, full). Each maps drum note -> steps.
GROOVES: dict[str, tuple[dict[int, list[int]], dict[int, list[int]]]] = {
    "four_on_floor": ({KICK: [0, 4, 8, 12], HAT_O: [2, 6, 10, 14]},
                      {KICK: [0, 4, 8, 12], CLAP: [4, 12], HAT_O: [2, 6, 10, 14], HAT_C: [1, 3, 5, 7, 9, 11, 13, 15]}),
    "backbeat": ({KICK: [0, 8], HAT_C: [0, 4, 8, 12]},
                 {KICK: [0, 8, 10], SNARE: [4, 12], HAT_C: [0, 2, 4, 6, 8, 10, 12, 14]}),
    "lofi": ({KICK: [0], HAT_C: [0, 4, 8, 12]},
             {KICK: [0, 7, 10], SNARE: [4, 12], HAT_C: [0, 2, 4, 6, 8, 10, 12, 14]}),
    "cinematic": ({TOM: [0]}, {KICK: [0], TOM: [0, 6, 10], CLAP: [8]}),
    "sparse": ({SHAKER: [0, 4, 8, 12]}, {KICK: [0], SHAKER: [0, 2, 4, 6, 8, 10, 12, 14]}),
    "pulse": ({KICK: [0], HAT_C: [0, 4, 8, 12]}, {KICK: [0, 10], HAT_C: [0, 2, 4, 6, 8, 10, 12, 14], SNARE: [12]}),
    "bounce": ({KICK: [0, 8], HAT_C: [2, 6, 10, 14]}, {KICK: [0, 6, 8], SNARE: [4, 12], HAT_C: [2, 6, 10, 14], CLAP: [12]}),
    "driving": ({KICK: [0, 4, 8, 12], HAT_C: [2, 6, 10, 14]},
                {KICK: [0, 4, 8, 12], SNARE: [4, 12], HAT_C: [0, 2, 4, 6, 8, 10, 12, 14], HAT_O: [14]}),
    "folk": ({KICK: [0], HAT_C: [0, 4, 8, 12]}, {KICK: [0, 10], SNARE: [4, 12], HAT_C: [0, 2, 4, 6, 8, 10, 12, 14]}),
    "blend_driving": ({KICK: [0, 6, 10], HAT_C: [0, 4, 8, 12]},
                      {KICK: [0, 3, 6, 10], SNARE: [4, 12], HAT_C: [0, 2, 4, 6, 8, 10, 12, 14], TOM: [14]}),
}


def _swing_shift(step: int, swing: float) -> float:
    if step % 4 == 2:
        return swing * 0.5
    if step % 2 == 1:
        return swing * 0.25
    return 0.0


def drums_events(plan: dict[str, Any], rng: random.Random) -> list[Event]:
    style = plan["styles"]["drums"]
    light, full = GROOVES[style["groove"]]
    swing = style.get("swing", 0.0)
    bars, energy = plan["bars"], plan["bar_energy"]
    loop = plan["loopable"]
    starts = {s["start_bar"] for s in plan["sections"]}
    events: list[Event] = []
    for b in range(bars):
        e = energy[b]
        base = b * BEATS_PER_BAR
        last = (b == bars - 1) and not loop
        if last:
            events.append(Event(base, 3.0, KICK, 1.0, "final"))
            events.append(Event(base, 3.0, CRASH, 0.95, "final"))
            continue
        pattern = full if e >= 0.55 else light
        if e < 0.2 and style["groove"] not in ("sparse", "cinematic"):
            pattern = {k: v for k, v in light.items() if k in (HAT_C, SHAKER)}
        for note, steps in pattern.items():
            for st in steps:
                accent = 1.0 if st % 4 == 0 else 0.78
                if note in (HAT_C, SHAKER, HAT_O):
                    accent *= 0.7 if st % 2 else 0.85
                vel = min(1.0, (0.40 + 0.55 * e) * accent + rng.random() * 0.06)
                events.append(Event(base + st / 4 + _swing_shift(st, swing), 0.25, note, vel))
        if e >= 0.85 and style["groove"] in ("four_on_floor", "driving", "backbeat", "bounce", "blend_driving"):
            for st in (1, 3, 5, 7, 9, 11, 13, 15):
                if (HAT_C in pattern and st in pattern[HAT_C]):
                    continue
                events.append(Event(base + st / 4, 0.25, HAT_C, 0.4 + rng.random() * 0.08))
        if b in starts and e >= 0.6:
            events.append(Event(base, 2.0, CRASH, min(1.0, 0.6 + 0.4 * e), "section"))
        nxt = energy[b + 1] if b + 1 < bars else e
        pre_final = (b == bars - 2) and not loop
        if (nxt > e + 0.05 and (b + 1) in starts) or pre_final:
            for k, st in enumerate((12, 13, 14, 15)):
                events.append(Event(base + st / 4, 0.25, SNARE if k < 3 else TOM, 0.55 + 0.1 * k, "fill"))
    return events


# --------------------------------------------------------------------------
# Bass
# --------------------------------------------------------------------------
def _bass_root(pc: int) -> int:
    return 28 + ((pc - 4) % 12)  # E1..D#2


def bass_events(plan: dict[str, Any], rng: random.Random) -> list[Event]:
    pattern = plan["styles"]["bass"]["pattern"]
    bars, energy, loop = plan["bars"], plan["bar_energy"], plan["loopable"]
    events: list[Event] = []
    for b in range(bars):
        e = energy[b]
        base = b * BEATS_PER_BAR
        chord = plan["chords"][b]
        root = _bass_root(chord["root_pc"])
        fifth = root + 7
        last = (b == bars - 1) and not loop
        if last:
            events.append(Event(base, 4.0, root, 0.95, "final"))
            continue
        if e < 0.3 and pattern != "sixteenth_pulse":
            continue
        pat = pattern if e >= 0.5 else ("root_half" if e >= 0.4 else "root_whole")
        v = 0.55 + 0.4 * e
        if pat == "root_whole":
            events.append(Event(base, 4.0, root, v))
        elif pat == "root_half":
            events += [Event(base, 2.0, root, v), Event(base + 2, 1.5, fifth if rng.random() < 0.25 else root, v * 0.85)]
        elif pat == "eighth":
            for i in range(8):
                p = root + (12 if i in (3, 7) and rng.random() < 0.4 else 0)
                events.append(Event(base + i * 0.5, 0.45, p, v * (1.0 if i % 2 == 0 else 0.75)))
        elif pat == "offbeat":
            events.append(Event(base, 0.5, root, v))
            for i in range(4):
                events.append(Event(base + i + 0.5, 0.45, root + (12 if i == 3 else 0), v * 0.9))
        elif pat == "sixteenth_pulse":
            for i in range(16):
                if i % 4 == 0 or rng.random() < 0.55:
                    events.append(Event(base + i / 4, 0.22, root, v * (0.8 if i % 4 else 1.0)))
    return events


# --------------------------------------------------------------------------
# Harmony
# --------------------------------------------------------------------------
HARMONY_RHYTHMS: dict[str, list[tuple[float, float]]] = {
    "sustain": [(0.0, 4.0)],
    "half": [(0.0, 2.0), (2.0, 2.0)],
    "stabs": [(0.0, 1.5), (1.5, 1.0), (2.5, 1.5)],
    "strum": [(0.0, 1.0), (1.5, 0.5), (2.0, 1.0), (3.5, 0.5)],
    "pump": [(0.5, 0.5), (1.5, 0.5), (2.5, 0.5), (3.5, 0.5)],
}


def _voice(pcs: list[int], prev: list[int] | None, center: int = 60) -> list[int]:
    best: list[int] | None = None
    best_cost = 1e9
    n = len(pcs)
    for inv in range(n):
        order = pcs[inv:] + pcs[:inv]
        notes: list[int] = []
        cur = center - 7
        for pc in order:
            while cur % 12 != pc:
                cur += 1
            notes.append(cur)
            cur += 1
        for shift in (-12, 0, 12):
            cand = [x + shift for x in notes]
            if cand[0] < 48 or cand[-1] > 79:
                continue
            if prev is None:
                cost = abs(sum(cand) / n - center)
            else:
                cost = sum(abs(a - b) for a, b in zip(sorted(cand), sorted(prev)))
            if cost < best_cost:
                best, best_cost = cand, cost
    return best or [center + i * 4 for i in range(n)]


def harmony_events(plan: dict[str, Any], rng: random.Random) -> list[Event]:
    rhythm = HARMONY_RHYTHMS[plan["styles"]["harmony"]["rhythm"]]
    bars, energy, loop = plan["bars"], plan["bar_energy"], plan["loopable"]
    events: list[Event] = []
    prev: list[int] | None = None
    for b in range(bars):
        e = energy[b]
        base = b * BEATS_PER_BAR
        notes = _voice(plan["chords"][b]["pcs"], prev)
        prev = notes
        last = (b == bars - 1) and not loop
        hits = [(0.0, 4.0)] if (last or e < 0.3) else rhythm
        v = 0.45 + 0.4 * e
        for off, dur in hits:
            for i, p in enumerate(notes):
                events.append(Event(base + off + i * 0.012, dur, p, v * (1.0 - 0.04 * i), "final" if last else ""))
    return events


# --------------------------------------------------------------------------
# Melody
# --------------------------------------------------------------------------
RHYTHMS = {
    "sparse": [[(0, 8)], [(0, 6), (8, 6)], [(0, 4), (8, 8)], [(4, 4), (8, 4), (12, 4)]],
    "pluck": [[(0, 3), (3, 3), (6, 2), (8, 4)], [(0, 2), (4, 2), (6, 2), (8, 2), (12, 4)], [(2, 2), (4, 2), (8, 3), (11, 2), (14, 2)]],
    "lead": [[(0, 4), (4, 2), (6, 2), (8, 4), (12, 4)], [(0, 3), (3, 3), (6, 2), (8, 2), (10, 2), (12, 4)]],
}
ARP_SHAPES = [[0, 1, 2, 1], [0, 2, 1, 2], [0, 1, 2, 3]]


def _scale_notes(tonic: int, mode: str, lo: int = 62, hi: int = 88) -> list[int]:
    pcs = set(scale_pcs(tonic, mode))
    return [n for n in range(lo, hi + 1) if n % 12 in pcs]


def melody_events(plan: dict[str, Any], rng: random.Random) -> list[Event]:
    style = plan["styles"]["melody"]["style"]
    bars, energy, loop = plan["bars"], plan["bar_energy"], plan["loopable"]
    sc = _scale_notes(plan["tonic_pc"], plan["mode"])
    events: list[Event] = []
    idx = len(sc) // 2
    templates = RHYTHMS.get(style, RHYTHMS["pluck"])
    motif = [templates[rng.randrange(len(templates))] for _ in range(4)]
    arp_shape = ARP_SHAPES[rng.randrange(len(ARP_SHAPES))]
    for b in range(bars):
        e = energy[b]
        base = b * BEATS_PER_BAR
        chord = plan["chords"][b]
        ct = [n for n in sc if n % 12 in chord["pcs"]]
        last = (b == bars - 1) and not loop
        if last:
            tonic_note = min((n for n in sc if n % 12 == plan["tonic_pc"] and n >= 70), default=sc[idx])
            events.append(Event(base, 4.0, tonic_note, 0.8, "final"))
            continue
        if e < 0.4:
            continue
        v = 0.5 + 0.4 * e
        if style == "arp":
            tones = sorted(ct)[:4] or [sc[idx]]
            for i in range(16):
                if e < 0.6 and i % 2:
                    continue
                n = tones[arp_shape[i % 4] % len(tones)] + (12 if (i // 8) % 2 and e > 0.8 and tones[0] + 12 <= 96 else 0)
                events.append(Event(base + i / 4, 0.24, n, v * (1.0 if i % 4 == 0 else 0.7)))
            continue
        rhythm = motif[b % 4]
        for k, (st, ln) in enumerate(rhythm):
            if e < 0.55 and k % 2 == 1 and rng.random() < 0.6:
                continue
            strong = st % 8 == 0
            if strong or (b % 4 == 3 and k == len(rhythm) - 1):
                cands = sorted(ct, key=lambda n: abs(n - sc[idx]))
                n = cands[0] if cands else sc[idx]
                idx = sc.index(n)
            else:
                step = rng.choice((-2, -1, -1, 1, 1, 2))
                idx = min(len(sc) - 1, max(0, idx + step))
                n = sc[idx]
            events.append(Event(base + st / 4, max(0.25, ln / 4 * 0.95), n, v * (1.0 if strong else 0.8), ""))
    return events


BUILDERS = {"drums": drums_events, "bass": bass_events, "harmony": harmony_events, "melody": melody_events}


def build_events(plan: dict[str, Any], stem: str, seed: int | None = None) -> list[Event]:
    """Events for one stem. ``seed`` overrides the plan seed for this stem only."""
    rng = stem_rng(plan["seed"] if seed is None else seed, stem)
    return sorted(BUILDERS[stem](plan, rng), key=lambda ev: (ev.beat, ev.pitch))


def build_all(plan: dict[str, Any]) -> dict[str, list[Event]]:
    return {s: build_events(plan, s) for s in STEMS}


def events_to_json(events: list[Event]) -> list[list[Any]]:
    return [[round(e.beat, 5), round(e.dur_beats, 5), e.pitch, round(e.vel, 4), e.tag] for e in events]

"""Audio file I/O: 16/24-bit PCM WAV reader/writer, ffmpeg decode and MP3 encode."""
from __future__ import annotations

import struct
import subprocess
from pathlib import Path

import numpy as np


class AudioError(ValueError):
    pass


def full_scale(bits: int) -> int:
    return (1 << (bits - 1)) - 1


def quantize(x: np.ndarray, bits: int) -> np.ndarray:
    fs = full_scale(bits)
    return np.clip(np.rint(x.astype(np.float64) * fs), -fs - 1, fs).astype(np.int32)


def dequantize(pcm: np.ndarray, bits: int) -> np.ndarray:
    return pcm.astype(np.float64) / full_scale(bits)


def write_wav(path: str | Path, pcm: np.ndarray, sample_rate: int, bits: int) -> None:
    """Write integer PCM shaped (n, channels) as a canonical WAV file."""
    if bits not in (16, 24):
        raise AudioError("bit_depth must be 16 or 24")
    pcm = np.atleast_2d(pcm.T).T if pcm.ndim == 1 else pcm
    n, ch = pcm.shape
    if bits == 16:
        raw = pcm.astype("<i2").tobytes()
    else:
        b = pcm.astype("<i4").reshape(-1).view(np.uint8).reshape(-1, 4)[:, :3]
        raw = b.tobytes()
    block = ch * bits // 8
    hdr = b"RIFF" + struct.pack("<I", 36 + len(raw)) + b"WAVE"
    hdr += b"fmt " + struct.pack("<IHHIIHH", 16, 1, ch, sample_rate, sample_rate * block, block, bits)
    hdr += b"data" + struct.pack("<I", len(raw))
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(hdr)
        fh.write(raw)


def read_wav_pcm(path: str | Path) -> tuple[np.ndarray, int, int]:
    """Return (int32 samples (n, ch), sample_rate, bits) for integer PCM files."""
    data = Path(path).read_bytes()
    if data[:4] != b"RIFF" or data[8:12] != b"WAVE":
        raise AudioError("not a RIFF/WAVE file")
    pos, fmt, raw = 12, None, None
    while pos + 8 <= len(data):
        cid, size = data[pos:pos + 4], struct.unpack("<I", data[pos + 4:pos + 8])[0]
        body = data[pos + 8:pos + 8 + size]
        if cid == b"fmt ":
            tag, ch, sr, _, _, bits = struct.unpack("<HHIIHH", body[:16])
            if tag == 0xFFFE and len(body) >= 26:
                tag = struct.unpack("<H", body[24:26])[0]
            fmt = (tag, ch, sr, bits)
        elif cid == b"data":
            raw = body
            break
        pos += 8 + size + (size & 1)
    if fmt is None or raw is None:
        raise AudioError("missing fmt or data chunk")
    tag, ch, sr, bits = fmt
    if tag == 3 and bits in (32, 64):
        arr = np.frombuffer(raw, dtype="<f4" if bits == 32 else "<f8").reshape(-1, ch)
        return arr.astype(np.float64), sr, bits  # float data is returned unscaled
    if tag != 1:
        raise AudioError(f"unsupported WAV format tag {tag}")
    if bits == 16:
        pcm = np.frombuffer(raw, dtype="<i2").astype(np.int32)
    elif bits == 24:
        b = np.frombuffer(raw[: len(raw) // 3 * 3], dtype=np.uint8).reshape(-1, 3)
        pcm = (b[:, 0].astype(np.int32) | (b[:, 1].astype(np.int32) << 8) | (b[:, 2].astype(np.int32) << 16))
        pcm = np.where(pcm & 0x800000, pcm - (1 << 24), pcm).astype(np.int32)
    elif bits == 32:
        pcm = np.frombuffer(raw, dtype="<i4").astype(np.int32)
    else:
        raise AudioError(f"unsupported bit depth {bits}")
    return pcm.reshape(-1, ch), sr, bits


def read_wav(path: str | Path) -> tuple[np.ndarray, int]:
    """Return (float64 samples in [-1, 1] shaped (n, ch), sample_rate)."""
    pcm, sr, bits = read_wav_pcm(path)
    if pcm.dtype == np.float64:
        return pcm, sr
    return dequantize(pcm, bits if bits != 32 else 32), sr


def resample_linear(x: np.ndarray, sr_in: int, sr_out: int) -> np.ndarray:
    if sr_in == sr_out:
        return x
    from scipy.signal import resample_poly
    from math import gcd
    g = gcd(sr_in, sr_out)
    return resample_poly(x, sr_out // g, sr_in // g)


def decode_to_mono(path: str | Path, sample_rate: int, max_seconds: float = 900.0) -> np.ndarray:
    """Decode any ffmpeg-readable file to mono float64 at ``sample_rate``."""
    cmd = ["ffmpeg", "-v", "error", "-nostdin", "-i", str(path), "-t", str(max_seconds), "-vn",
           "-f", "f32le", "-ac", "1", "-ar", str(sample_rate), "pipe:1"]
    try:
        res = subprocess.run(cmd, capture_output=True, timeout=120)
    except (OSError, subprocess.SubprocessError) as exc:
        raise AudioError(f"ffmpeg could not run: {exc}") from exc
    if res.returncode != 0 or not res.stdout:
        raise AudioError("narration audio could not be decoded: " + res.stderr.decode(errors="replace")[:200])
    return np.frombuffer(res.stdout, dtype="<f4").astype(np.float64)


def encode_mp3(stereo: np.ndarray, sample_rate: int, path: str | Path, bitrate_kbps: int = 192) -> None:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    cmd = ["ffmpeg", "-v", "error", "-y", "-f", "f32le", "-ar", str(sample_rate), "-ac", str(stereo.shape[1]), "-i", "pipe:0",
           "-c:a", "libmp3lame", "-b:a", f"{bitrate_kbps}k", str(path)]
    res = subprocess.run(cmd, input=stereo.astype("<f4").tobytes(), capture_output=True, timeout=300)
    if res.returncode != 0:
        raise AudioError("mp3 encode failed: " + res.stderr.decode(errors="replace")[:200])

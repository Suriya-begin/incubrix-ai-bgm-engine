# AI use disclosure

This repository was written with Claude (Anthropic) acting as the engineer, from a single
specification prompt. A human reviewer should treat everything as AI-authored code that has been
tested to the extent stated below.

## What Claude did

* Scaffolded the repository: planner, arranger, providers, DSP and mastering, FastAPI service,
  SQLite state, worker, scripts, Docker files and documentation.
* Chose and implemented the DSP: BS.1770-4 K-weighting and gating (used only if `pyloudnorm` is not
  importable), 4x-oversampled true-peak estimation, a look-ahead limiter whose single gain curve is
  applied to all stems, RMS voice-activity detection with a smoothed ducking gain, Ramer-Douglas-Peucker
  decimation of the gain curve.
* Verified the DSP maths by running it: exact sample counts, stem sum residual, loudness, true peak,
  ducking depth, loop seam. Results are in `REPORT.md` and `report_data/`.
* Wrote the tests in `tests/`.

## What Claude did not do

* Run Docker, MinIO, FluidSynth, `pyloudnorm`, FastAPI or pytest. The sandbox had no network and
  only NumPy, SciPy, PyYAML and ffmpeg. The API layer, storage layer and `tests/test_api.py` have
  been compiled but never executed. Engine tests were executed with a small ad-hoc runner.
* Verify licence URLs (see `SOURCES.md`).
* Listen to the audio. Metrics say nothing about whether it sounds good.

## Human review checklist

1. `pip install -r requirements-dev.txt && pytest`, then fix whatever the untested API tests find.
2. `docker compose up --build`, then `python -m scripts.batch_runner ...`.
3. Listen to every provider on at least five genres.
4. Confirm each licence row marked **verify** in `SOURCES.md`.

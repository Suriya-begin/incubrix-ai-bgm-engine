# IncuBrix AI Background Music Engine

Prompt in, royalty-clean background music out: a stereo mix, four aligned stems
(`drums`, `bass`, `harmony`, `melody`), an optional voiceover-ducked mix, and a
`music_manifest.json` that explains every decision.

The engine does **not** separate a mixed track. It composes on a shared bar grid and
renders each stem on its own, so stems cannot bleed into each other and
`sum(stems) == mix` holds exactly (the mix file is the integer sum of the stem files).

## Architecture

```mermaid
flowchart LR
  C[Client] -->|POST /api/v1/music/jobs| API[FastAPI api]
  API -->|job row + idempotency key| DB[(SQLite WAL<br/>shared volume)]
  W[Worker] -->|claim queued job| DB
  W --> P[planner.py<br/>mood, key, tempo snap, sections, chords]
  P --> A[arranger.py<br/>events per stem on one bar grid]
  A --> PR{provider}
  PR -->|default| FS[fluidsynth_symbolic<br/>GM SoundFont, per-stem MIDI]
  PR --> PS[procedural_synth<br/>NumPy/SciPy DSP]
  PR --> MK[mock<br/>CI]
  FS --> M[audio_processor.py<br/>weights, one LUFS scalar, one limiter curve, ducking]
  PS --> M
  MK --> M
  M -->|stems, mix, mp3, manifest| S3[(MinIO)]
  C -->|GET /api/v1/jobs/id| API -->|presigned URLs| C
```

```
client -> api -> sqlite <- worker -> planner -> arranger -> provider -> mastering -> minio
```

Key properties

* **Exact duration.** Tempo is snapped so a whole number of 4/4 bars equals `duration_s`
  (`bpm = bars * 240 / duration_s`). Every file has `round(duration_s * sample_rate)` samples.
* **Stem integrity.** Stems are scaled by one global scalar and one look-ahead limiter curve, then
  quantized. `mix = sum(quantized stems)`, so the residual is exactly zero (reported as `-300 dB`).
* **Loudness.** Integrated loudness targets `-16 LUFS` (BS.1770-4 via `pyloudnorm`), true peak
  limited at `-1.5 dBTP` with 4x oversampling; the hard requirement is `<= -1.0 dBTP`.
* **Endings.** Non-loop: V to I cadence, final hit on the last downbeat, raised-cosine fade to
  exactly zero on the final sample. Loop: release tails wrap into bar 1 and the limiter is circular.
* **Ducking.** RMS voice activity detection, 80 ms look-ahead, 80 ms attack, 350 ms release,
  `-11 dB` by default (`output.duck_db` accepts -10 to -12). `mix_ducked.wav` is the **music only**
  with ducking applied, so an editor can layer the narration; the gain curve is in the manifest.
* **Single-stem regeneration.** Re-renders one stem on the original tempo, key and bars. The other
  three stem files are byte-identical copies; the mix is re-summed.
* **Providers.** `MUSIC_PROVIDER=fluidsynth_symbolic` (default), `procedural_synth`, `mock`.
  If FluidSynth or the SoundFont is missing the default provider falls back to the procedural
  synth for that render and says so in `stems[].provider`; `/ready` reports the missing SoundFont.

## Quick start

```bash
cp .env.example .env            # optional: compose already reads .env.example
docker compose up --build       # api :8000, worker, MinIO :9000 (console :9001)
curl localhost:8000/ready
curl -s -X POST localhost:8000/api/v1/music/jobs -H 'Content-Type: application/json' \
  -d '{"prompt":"warm cinematic strings, slow build","duration_s":30,"seed":1}'
curl -s localhost:8000/api/v1/jobs/<job_id>
docker compose run --rm api pytest                       # all tests, no API keys
python -m scripts.batch_runner --input tests/batch_inputs.json --output ./test_pack_output --api-url http://localhost:8000
```

Local (no Docker): `pip install -r requirements-dev.txt && pytest`. Engine tests need only
`numpy`, `scipy`, `ffmpeg`. API tests use an in-memory storage fake.

### Request

```json
{
  "prompt": "uplifting corporate explainer",
  "duration_s": 45,
  "sections": [{"name": "intro", "start_s": 0}, {"name": "main", "start_s": 8}, {"name": "outro", "start_s": 38, "energy": 0.3}],
  "tempo_bpm": 110, "key": "C major", "loopable": false, "seed": 42,
  "narration_url": "https://example.com/vo.mp3",
  "callback_url": "https://example.com/hook",
  "output": {"sample_rate": 48000, "bit_depth": 24, "target_lufs": -16, "mp3_bitrate_kbps": 192, "duck_db": -11}
}
```

`narration_url` may be an http(s) URL or `asset://<id>` returned by `POST /api/v1/assets/upload`.
Private and loopback hosts are blocked unless `ALLOW_PRIVATE_NARRATION_HOSTS=true`.

### Endpoints

| Method | Path | Notes |
|---|---|---|
| POST | `/api/v1/music/jobs` | 202 `{job_id, status}`; `Idempotency-Key` supported |
| GET | `/api/v1/jobs/{job_id}` | status, progress 0 to 100, `result.files` (presigned URLs), `error` |
| POST | `/api/v1/music/jobs/{job_id}/regenerate-stem` | `{stem, seed?, prompt_override?}` returns a new job |
| POST | `/api/v1/assets/upload` | multipart `file`; returns `asset://` URL |
| GET | `/health`, `/ready` | liveness; MinIO + worker heartbeat + SoundFont |

`result.files` keys: `mix.wav`, `mix.mp3`, `stems/{drums,bass,harmony,melody}.wav`,
`mix_ducked.wav` (only with narration), `music_manifest.json`.

Callbacks: the worker POSTs the final job payload to `callback_url` with header
`X-IncuBrix-Signature: sha256=<hex HMAC-SHA256 of the raw body, key CALLBACK_SECRET>` and retries
with backoff. Verify with `app.callbacks.verify`.

Operations: every response carries `X-Correlation-Id` (generated if absent). The first response
after process start also carries `X-Cold-Start: true`. `/ready` reports uptime and whether the
worker finished its warm-up render. Rate limits are per client IP, in process.

## Warnings in the manifest

`VOCAL_REQUEST_IGNORED`, `ARTIST_REFERENCE_SANITIZED` (exact strings from the brief),
`NON_ENGLISH_PROMPT`, `MOOD_FALLBACK`, `CONTRADICTORY_PROMPT`, `TEMPO_SNAPPED`,
`INVALID_KEY_FALLBACK`, `SECTIONS_MERGED`, `SECTION_OUT_OF_RANGE`, `SECTION_START_CLAMPED`,
`SECTIONS_PREPENDED_INTRO`, `NARRATION_NO_SPEECH`, `NARRATION_SHORTER_THAN_MUSIC`,
`NARRATION_LONGER_THAN_MUSIC`, `LOUDNESS_TARGET_MISSED`, `LOUDNESS_DRIFT` (regeneration only).

## Error format and codes

Every error: `{"error": {"code": "UPPER_SNAKE", "message": "...", "retryable": false, "details": {}}}`.

| HTTP | Code | Meaning | Retryable |
|---|---|---|---|
| 400 | `BAD_REQUEST` | malformed request | no |
| 400 | `IDEMPOTENCY_KEY_MISMATCH` | key reused with a different body | no |
| 400 | `IDEMPOTENCY_KEY_INVALID` | key empty, too long or unprintable | no |
| 400 | `SOURCE_JOB_NOT_SUCCEEDED` | regenerate on a job that is not finished (retryable while queued/running) | maybe |
| 404 | `JOB_NOT_FOUND`, `NOT_FOUND` | unknown job or route | no |
| 405 | `METHOD_NOT_ALLOWED` | wrong HTTP method | no |
| 422 | `VALIDATION_ERROR` | schema violation (`details.issues`) | no |
| 422 | `DURATION_OUT_OF_RANGE` | outside `MIN_DURATION_S`..`MAX_DURATION_S` | no |
| 422 | `INVALID_NARRATION_URL`, `INVALID_CALLBACK_URL` | bad scheme or blocked host | no |
| 422 | `ASSET_TOO_LARGE` | upload above `MAX_UPLOAD_BYTES` | no |
| 429 | `RATE_LIMITED` | slow down; see `Retry-After` | yes |
| 500 | `INTERNAL_ERROR` | unexpected failure | yes |
| 503 | `SERVICE_NOT_READY` | `/ready` check failed (`details.checks`) | yes |
| 504 | `STORAGE_UNAVAILABLE`, `GATEWAY_TIMEOUT` | object storage did not answer | yes |

Job-level errors (in `GET /jobs/{id}` `error`, same shape): `NARRATION_FETCH_FAILED`,
`NARRATION_FETCH_TIMEOUT`, `NARRATION_TOO_LARGE`, `NARRATION_DECODE_FAILED`, `INVALID_REQUEST`,
`RENDER_FAILED`, `JOB_TIMEOUT`, `STORAGE_ERROR`, `JOB_ABANDONED`, `SOURCE_JOB_NOT_SUCCEEDED`, `INTERNAL_ERROR`.

## Configuration

All settings come from environment variables (Pydantic `BaseSettings`, see `app/config.py` and
`.env.example`). Main ones: `MUSIC_PROVIDER`, `SOUNDFONT_PATH`, `MIN_DURATION_S`, `MAX_DURATION_S`,
`DEFAULT_TARGET_LUFS`, `S3_ENDPOINT_URL`, `S3_PUBLIC_ENDPOINT_URL`, `S3_ACCESS_KEY`, `S3_SECRET_KEY`,
`S3_BUCKET`, `PRESIGN_TTL_S`, `DATA_DIR`, `WORK_DIR`, `WORKER_CONCURRENCY`, `WORKER_ISOLATION`,
`JOB_TIMEOUT_S`, `RATE_LIMIT_ENABLED`, `RATE_LIMIT_PER_MINUTE`, `RATE_LIMIT_JOBS_PER_MINUTE`,
`TRUST_PROXY_HEADERS`, `MAX_UPLOAD_BYTES`, `NARRATION_MAX_BYTES`, `NARRATION_FETCH_TIMEOUT_S`,
`ALLOW_PRIVATE_NARRATION_HOSTS`, `ALLOW_LOCAL_NARRATION_PATHS`, `ALLOW_PRIVATE_CALLBACK_HOSTS`,
`CALLBACK_SECRET`, `CALLBACK_TIMEOUT_S`, `CALLBACK_MAX_ATTEMPTS`, `COMPUTE_COST_USD_PER_CPU_HOUR`, `LOG_LEVEL`.

## Scripts

* `scripts/batch_runner.py`: submit a pack, poll, download, verify (duration, LUFS, true peak, stem sum
  residual, non-silence, ducking, regeneration), write `summary_report.json` and `metrics.csv`.
* `scripts/evaluate_metrics.py`: in-process benchmark with cold vs warm latency, bleed correlation,
  loop click ratio; writes CSV/JSON/Markdown tables and SVG charts to `report_data/`.
* `scripts/export_openapi.py`: writes `openapi.yaml` from the app (`--check` for CI). The Docker build runs it.
* `scripts/make_sample_narration.py`: synthetic narration for demos.

## Verification status

See `REPORT.md` section "What was and was not verified". Short version: the DSP engine, planner,
arranger, SQLite idempotency, and hard cases were executed and measured. The HTTP layer, MinIO,
Docker build, FluidSynth rendering, and `pyloudnorm` were written to spec but not run in the
environment this repo was produced in (no network, no Docker).

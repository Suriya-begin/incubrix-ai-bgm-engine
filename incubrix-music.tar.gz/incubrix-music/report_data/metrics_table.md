| provider | genre | dur s | bpm | LUFS | TP dBTP | sum err (LSB) | max stem corr | wall s | x realtime |
|---|---|---|---|---|---|---|---|---|---|
| procedural_synth | cinematic | 5 | 96.0 | -16.0 | -3.92 | 0 | 0.056 | 1.15 | 4.3 |
| procedural_synth | lofi | 10 | 72.0 | -16.0 | -1.73 | 0 | 0.039 | 1.2 | 8.3 |
| procedural_synth | corporate | 20 | 108.0 | -16.0 | -1.6 | 0 | 0.03 | 2.15 | 9.3 |
| procedural_synth | electronic | 30 | 128.0 | -16.0 | -1.72 | 0 | 0.016 | 2.83 | 10.6 |
| procedural_synth | acoustic | 45 | 96.0 | -16.02 | -1.5 | 0 | 0.026 | 3.93 | 11.4 |
| procedural_synth | tense | 60 | 100.0 | -16.0 | -1.7 | 0 | 0.006 | 5.45 | 11.0 |
| procedural_synth | playful | 90 | 122.67 | -16.0 | -1.5 | 0 | 0.057 | 8.62 | 10.4 |
| procedural_synth | energetic | 120 | 132.0 | -16.0 | -1.5 | 0 | 0.09 | 12.61 | 9.5 |
| procedural_synth | calm | 180 | 68.0 | -16.0 | -1.5 | 0 | 0.036 | 18.66 | 9.6 |
| procedural_synth | melancholic | 300 | 70.4 | -16.0 | -1.56 | 0 | 0.03 | 28.66 | 10.5 |
| procedural_synth | cinematic (loop) | 5 | 96.0 | -16.0 | -4.27 | 0 | 0.015 | 0.82 | 6.1 |
| procedural_synth | lofi (loop) | 10 | 72.0 | -16.0 | -1.99 | 0 | 0.035 | 1.26 | 8.0 |
| procedural_synth | corporate (loop) | 20 | 108.0 | -16.0 | -3.47 | 0 | 0.042 | 2.09 | 9.6 |
| mock | cinematic | 5 | 96.0 | -16.03 | -1.5 | 0 | 0.007 | 0.67 | 7.4 |
| mock | lofi | 10 | 72.0 | -16.1 | -1.5 | 0 | 0.022 | 1.31 | 7.6 |
| mock | corporate | 20 | 108.0 | -16.05 | -1.5 | 0 | 0.04 | 2.5 | 8.0 |
| mock | electronic | 30 | 128.0 | -16.01 | -1.5 | 0 | 0.07 | 3.04 | 9.9 |
| mock | acoustic | 45 | 96.0 | -16.03 | -1.5 | 0 | 0.047 | 5.64 | 8.0 |
| mock | tense | 60 | 100.0 | -16.02 | -1.5 | 0 | 0.024 | 6.62 | 9.1 |
| mock | playful | 90 | 122.67 | -16.03 | -1.5 | 0 | 0.061 | 10.18 | 8.8 |
| mock | energetic | 120 | 132.0 | -16.06 | -1.5 | 0 | 0.049 | 14.56 | 8.2 |
| mock | calm | 180 | 68.0 | -16.28 | -1.5 | 0 | 0.11 | 29.13 | 6.2 |
| mock | melancholic | 300 | 70.4 | -16.87 | -1.5 | 0 | 0.009 | 47.78 | 6.3 |
| mock | cinematic (loop) | 5 | 96.0 | -16.08 | -1.5 | 0 | 0.021 | 0.84 | 5.9 |
| mock | lofi (loop) | 10 | 72.0 | -16.22 | -1.5 | 0 | 0.015 | 1.22 | 8.2 |
| mock | corporate (loop) | 20 | 108.0 | -16.05 | -1.5 | 0 | 0.049 | 2.51 | 8.0 |
"""The eight hard cases from the brief."""
import numpy as np

from app import planner
from tests.helpers import load, make_narration, run, tmpdir

VOCAL = "VOCAL_REQUEST_IGNORED: Service produces instrumental audio only."
ARTIST = "ARTIST_REFERENCE_SANITIZED: Generated original composition to ensure commercial copyright safety."


def test_1_real_artist_reference_is_sanitized():
    for prompt in ("uplifting like Coldplay", "in the style of Taylor Swift, bright", "sounds like Hans Zimmer epic"):
        res = run("mock", prompt, 10)
        assert ARTIST in res.manifest["warnings"], prompt
        plan = res.manifest["plan"]
        for name in ("coldplay", "taylor", "zimmer"):
            assert name not in plan["prompt_effective"].lower()


def test_2_vocal_request_is_ignored_with_warning():
    res = run("mock", "happy pop with female vocals and lyrics about summer", 10)
    assert VOCAL in res.manifest["warnings"]
    assert "vocal" not in res.manifest["plan"]["prompt_effective"].lower()
    assert {s["name"] for s in res.manifest["stems"]} == {"drums", "bass", "harmony", "melody"}


def test_2b_no_vocals_is_not_a_warning():
    res = run("mock", "calm piano, no vocals", 10)
    assert VOCAL not in res.manifest["warnings"]


def test_3_non_english_prompts():
    for prompt, mood in (("música tranquilo y relajado", "calm"), ("平静 放松 音乐", "calm"), ("épique cinématographique", "cinematic")):
        p = planner.plan(prompt, 20)
        assert any(w.startswith("NON_ENGLISH_PROMPT") for w in p["warnings"]), prompt
        assert p["mood"]["primary"] == mood, (prompt, p["mood"])
    p = planner.plan("かわいい音楽", 20)  # no known keyword: still produces music, with a fallback warning
    assert any(w.startswith("MOOD_FALLBACK") for w in p["warnings"])
    assert run("mock", "かわいい音楽", 8).manifest["duration_actual_s"] == 8


def test_4_contradictory_prompt_is_blended():
    p = planner.plan("calm but aggressive", 30)
    assert any(w.startswith("CONTRADICTORY_PROMPT") for w in p["warnings"])
    assert p["tempo_bpm"] < 100
    assert p["styles"]["harmony"]["rhythm"] == "sustain"
    assert p["styles"]["drums"]["groove"] == "blend_driving" and p["styles"]["bass"]["pattern"] == "eighth"


def test_5_sections_closer_than_1_5_s_are_merged():
    res = run("mock", "corporate", 30, sections='[{"name":"a","start_s":0},{"name":"b","start_s":1.0},{"name":"c","start_s":15}]')
    m = res.manifest
    assert any(w.startswith("SECTIONS_MERGED") for w in m["warnings"])
    assert [s["name"] for s in m["sections"]] == ["a", "c"]
    starts = [s["actual_start_s"] for s in m["sections"]]
    assert all(b - a >= 1.5 for a, b in zip(starts, starts[1:]))


def test_6_section_start_beyond_duration_is_dropped():
    res = run("mock", "corporate", 20, sections='[{"name":"a","start_s":0},{"name":"late","start_s":20},{"name":"later","start_s":45}]')
    names = [s["name"] for s in res.manifest["sections"]]
    assert names == ["a"]
    assert sum(w.startswith("SECTION_OUT_OF_RANGE") for w in res.manifest["warnings"]) == 2
    assert res.manifest["sections"][0]["end_s"] == 20


def test_7_narration_with_zero_speech_returns_unducked_mix():
    from app.audio_io import quantize, write_wav
    p = tmpdir() / "silent.wav"
    write_wav(p, quantize(np.zeros((48000 * 8, 1)), 16), 48000, 16)
    res = run("mock", "calm", 8, narration=str(p))
    assert any(w.startswith("NARRATION_NO_SPEECH") for w in res.manifest["warnings"])
    mix, _ = load(res, "mix.wav")
    duck, _ = load(res, "mix_ducked.wav")
    assert np.max(np.abs(duck - mix)) < 1e-6
    assert all(abs(pt["gain_db"]) < 1e-9 for pt in res.manifest["ducking_curve"])


def test_8_narration_length_mismatch_and_long_silences():
    short = make_narration([(1, 3)], 4)
    r1 = run("mock", "calm", 12, narration=str(short))
    assert any(w.startswith("NARRATION_SHORTER_THAN_MUSIC") for w in r1.manifest["warnings"])
    assert r1.manifest["ducking_curve"][-1]["time_s"] == 12.0
    long_ = make_narration([(1, 3), (20, 22)], 25)
    r2 = run("mock", "calm", 12, narration=str(long_))
    assert any(w.startswith("NARRATION_LONGER_THAN_MUSIC") for w in r2.manifest["warnings"])
    assert r2.manifest["duration_actual_s"] == 12
    # long silence 3s..12s: music fully restored well before the end
    mix, sr = load(r2, "mix.wav")
    duck, _ = load(r2, "mix_ducked.wav")
    seg = slice(int(6 * sr), int(11 * sr))
    assert 10 * np.log10(np.mean(duck[seg] ** 2) / np.mean(mix[seg] ** 2)) > -0.5


def test_duration_extremes():
    for d in (5, 300):
        res = run("mock", "energetic sports", d)
        assert abs(res.manifest["duration_actual_s"] - d) < 0.005

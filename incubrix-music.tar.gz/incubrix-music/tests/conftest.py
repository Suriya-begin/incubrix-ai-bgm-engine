"""Fixtures: in-memory storage, app + TestClient, inline worker. No external services or API keys."""
from __future__ import annotations

import os
from pathlib import Path

os.environ.setdefault("INCUBRIX_NO_AUTOAPP", "1")

import pytest
from fastapi.testclient import TestClient

from app.config import Settings
from app.db import Database
from app.main import create_app
from app.worker import Worker


class FakeStorage:
    """Dict-backed stand-in with the same interface as app.storage.Storage."""

    def __init__(self) -> None:
        self.objects: dict[str, bytes] = {}

    def ensure_bucket(self) -> None: ...
    def ping(self) -> bool: return True
    def upload_file(self, local, key) -> None: self.objects[key] = Path(local).read_bytes()
    def put_bytes(self, data, key, content_type="") -> None: self.objects[key] = data
    def exists(self, key) -> bool: return key in self.objects
    def presign(self, key, ttl=None) -> str: return f"http://fake-s3/{key}"

    def download_file(self, key, local) -> None:
        from app.storage import StorageError
        if key not in self.objects:
            raise StorageError(f"missing {key}")
        Path(local).parent.mkdir(parents=True, exist_ok=True)
        Path(local).write_bytes(self.objects[key])


@pytest.fixture()
def settings(tmp_path) -> Settings:
    return Settings(music_provider="mock", data_dir=str(tmp_path / "data"), work_dir=str(tmp_path / "work"), worker_isolation="inline",
                    rate_limit_enabled=False, callback_secret="test-secret", allow_private_narration_hosts=True)


@pytest.fixture()
def storage() -> FakeStorage:
    return FakeStorage()


@pytest.fixture()
def env(settings, storage):
    db = Database(settings.sqlite_path)
    app = create_app(settings, storage, db)  # type: ignore[arg-type]
    db.beat("worker-test", {"warmed_up": True})
    return {"client": TestClient(app), "db": db, "worker": Worker(settings, db, storage), "storage": storage, "settings": settings}  # type: ignore[arg-type]


@pytest.fixture()
def client(env) -> TestClient:
    return env["client"]


def drain(env) -> None:
    """Run every queued job to completion on the inline worker."""
    while (job := env["db"].claim_next()) is not None:
        env["worker"].process(job)

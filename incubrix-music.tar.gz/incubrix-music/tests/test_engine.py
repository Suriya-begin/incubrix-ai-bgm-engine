"""Core engine: exact duration, stem integrity, loudness, grid, loops, determinism, ducking, regeneration."""
import hashlib
import math
from pathlib import Path

import numpy as np

from app import arranger, planner
from app.audio_processor import loop_click_ratio
from app.loudness import integrated_lufs, true_peak_db
from app.pipeline import generate, regenerate_stem
from app.providers.base import get_provider
from tests.helpers import STEMS, load, make_narration, run, stem_sum_error, tmpdir

DURATIONS = (5, 12.5, 30, 61.3)


def test_exact_duration_all_files():
    for d in DURATIONS:
        res = run("procedural_synth", "cinematic strings", d)
        want = int(round(d * 48000))
        for rel in ["mix.wav"] + [f"stems/{s}.wav" for s in STEMS]:
            x, sr = load(res, rel)
            assert x.shape[0] == want, (d, rel, x.shape[0])
        assert abs(res.manifest["duration_actual_s"] - d) < 0.005


def test_four_distinct_nonsilent_stems():
    res = run("procedural_synth", "electronic dance", 20)
    rms = {}
    for s in STEMS:
        x, _ = load(res, f"stems/{s}.wav")
        rms[s] = float(np.sqrt(np.mean(x ** 2)))
        assert rms[s] > 1e-4, f"{s} is silent"
    a, b = load(res, "stems/drums.wav")[0][:, 0], load(res, "stems/bass.wav")[0][:, 0]
    corr = abs(float(np.corrcoef(a, b)[0, 1]))
    assert corr < 0.3, corr


def test_stem_sum_equals_mix_below_minus_90_db():
    for p in ("mock", "procedural_synth"):
        res = run(p, "corporate upbeat", 15)
        assert stem_sum_error(res) <= 1  # at most one LSB of 24-bit
        assert res.manifest["loudness"]["stem_sum_residual_db"] < -90


def test_loudness_and_true_peak():
    for p, loop in (("mock", False), ("procedural_synth", False), ("procedural_synth", True)):
        res = run(p, "lofi chill", 30, loop)
        mix, sr = load(res, "mix.wav")
        assert abs(integrated_lufs(mix, sr) - (-16.0)) <= 0.5
        assert true_peak_db(mix) <= -1.0


def test_manifest_has_required_fields():
    m = run("mock", "playful kids", 10).manifest
    for k in ["job_id", "ai_generated", "tempo_bpm", "key", "time_signature", "duration_requested_s", "duration_actual_s", "sections",
              "beat_grid_s", "bar_grid_s", "stems", "loudness", "seed", "timings_ms", "estimated_cost_usd", "warnings", "licenses"]:
        assert k in m, k
    assert m["ai_generated"] is True
    assert {s["name"] for s in m["stems"]} == set(STEMS)
    for s in m["stems"]:
        assert {"instrument", "gain_linear", "gain_db", "provider", "model_version", "license"} <= set(s)
    assert {"integrated_lufs", "true_peak_dbtp", "stem_sum_residual_db"} <= set(m["loudness"])
    assert {"planning", "rendering", "mixing", "upload", "total"} <= set(m["timings_ms"])


def test_events_sit_on_the_shared_grid_and_sections_snap_to_bars():
    res = run("mock", "cinematic", 40, sections='[{"name":"a","start_s":0},{"name":"b","start_s":11.3},{"name":"c","start_s":27}]')
    m = res.manifest
    bars = m["bar_grid_s"]
    for s in m["sections"]:
        assert any(abs(s["actual_start_s"] - b) < 1e-4 for b in bars)
        assert abs(s["actual_start_s"] - s["planned_start_s"]) <= m["bar_grid_s"][1] / 2 + 1e-6 or s["planned_start_s"] == 0
    plan = m["plan"]
    for stem in STEMS:
        for ev in arranger.build_events(plan, stem):
            assert 0 <= ev.beat < plan["bars"] * 4 + 1e-9
            assert abs(ev.beat * 4 - round(ev.beat * 4)) < 0.2 or stem == "harmony"  # 16th grid (+ swing / strum offsets)
    assert abs(bars[-1] - 40) < 1e-4


def test_tempo_snap_makes_whole_bars_fit_duration():
    for d in (5, 17, 33.3, 120, 300):
        for bpm in (60, 90, 128, 170):
            bars, snapped = planner.snap_tempo(d, bpm)
            assert abs(bars * 4 * 60 / snapped - d) < 1e-9
            assert bars >= 2


def test_non_loop_ends_with_cadence_and_decays_to_zero():
    res = run("procedural_synth", "calm piano", 20)
    mix, sr = load(res, "mix.wav")
    assert np.abs(mix[-1]).max() < 1e-4
    last = mix[-int(0.05 * sr):]
    assert np.abs(last).max() < 0.02
    assert res.manifest["plan"]["chords"][-1]["degree"] == 0 and res.manifest["plan"]["chords"][-2]["degree"] == 4
    peak_last_bar = np.abs(mix[-int(res.manifest["bar_grid_s"][1] * sr):]).max()
    assert peak_last_bar > 0.02  # the final chord is audible, not cut


def test_loop_boundary_has_no_click():
    for prompt in ("lofi chill", "electronic dance", "cinematic strings"):
        res = run("procedural_synth", prompt, 24, True)
        mix, _ = load(res, "mix.wav")
        assert loop_click_ratio(mix) < 1.5, (prompt, loop_click_ratio(mix))
        tiled = np.concatenate([mix, mix])
        steps = np.abs(np.diff(tiled, axis=0)).max(axis=1)
        seam = steps[mix.shape[0] - 1]
        assert seam <= np.percentile(steps, 99.9) * 1.5


def test_deterministic_for_same_seed_and_different_for_new_seed():
    def sha(seed):
        d = tmpdir()
        r = generate({"prompt": "acoustic folk", "duration_s": 10, "seed": seed}, get_provider("procedural_synth"), d, job_id="x")
        return hashlib.sha256(Path(r.files["mix.wav"]).read_bytes()).hexdigest()
    assert sha(5) == sha(5)
    assert sha(5) != sha(6)


def test_sample_rate_and_bit_depth_options():
    d = tmpdir()
    r = generate({"prompt": "calm", "duration_s": 6, "seed": 1, "output": {"sample_rate": 44100, "bit_depth": 16}},
                 get_provider("mock"), d, job_id="x")
    from app.audio_io import read_wav_pcm
    pcm, sr, bits = read_wav_pcm(r.files["mix.wav"])
    assert (sr, bits, pcm.shape[0]) == (44100, 16, int(round(6 * 44100)))
    assert r.files["mix.mp3"].stat().st_size > 1000


def _rms_db(x):
    return 10 * math.log10(float(np.mean(x ** 2)) + 1e-20)


def test_ducking_depth_timing_and_curve_in_manifest():
    nar = make_narration([(2, 5), (9, 11), (16, 19)], 20)
    res = run("procedural_synth", "corporate upbeat", 24, narration=str(nar))
    m = res.manifest
    assert len(m["ducking_curve"]) > 4 and m["ducking_curve"][0] == {"time_s": 0.0, "gain_db": 0.0}
    mix, sr = load(res, "mix.wav")
    duck, _ = load(res, "mix_ducked.wav")

    def delta(a, b):
        sl = slice(int(a * sr), int(b * sr))
        return _rms_db(duck[sl]) - _rms_db(mix[sl])
    assert -12.2 <= delta(2.5, 4.8) <= -10.0
    assert -12.2 <= delta(9.3, 10.8) <= -10.0
    assert delta(6, 8) > -0.5 and delta(13, 15) > -0.5
    # attack is smooth: gain at speech onset is already mostly down, but not a step
    g = {round(p["time_s"], 2): p["gain_db"] for p in m["ducking_curve"]}
    assert min(g.values()) >= -12.0 and min(g.values()) <= -10.0


def test_regenerate_only_changes_requested_stem():
    src = run("procedural_synth", "corporate upbeat", 20)
    before = {s: hashlib.sha256(Path(src.files[f"stems/{s}.wav"]).read_bytes()).hexdigest() for s in STEMS}
    out = tmpdir()
    reg = regenerate_stem(Path(src.files["mix.wav"]).parent, src.manifest, "drums", get_provider("procedural_synth"), out,
                          job_id="r1", seed=99, prompt_override="heavy electronic techno")
    after = {s: hashlib.sha256(Path(reg.files[f"stems/{s}.wav"]).read_bytes()).hexdigest() for s in STEMS}
    assert after["drums"] != before["drums"]
    assert all(after[s] == before[s] for s in STEMS if s != "drums")
    m0, m1 = src.manifest, reg.manifest
    assert (m1["tempo_bpm"], m1["key"], m1["bar_grid_s"], m1["beat_grid_s"]) == (m0["tempo_bpm"], m0["key"], m0["bar_grid_s"], m0["beat_grid_s"])
    assert stem_sum_error(reg) <= 1
    mix, sr = load(reg, "mix.wav")
    assert true_peak_db(mix) <= -1.0 and abs(integrated_lufs(mix, sr) + 16) <= 0.7
    assert m1["regenerations"][-1]["stem"] == "drums"

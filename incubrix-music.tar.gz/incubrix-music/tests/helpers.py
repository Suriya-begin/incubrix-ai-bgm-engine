"""Shared test helpers (no pytest fixtures, so engine tests also run as plain functions)."""
from __future__ import annotations

import tempfile
from functools import lru_cache
from pathlib import Path

import numpy as np

from app.audio_io import dequantize, quantize, read_wav_pcm, write_wav
from app.pipeline import GenerationResult, generate
from app.providers.base import get_provider

STEMS = ("drums", "bass", "harmony", "melody")


def tmpdir() -> Path:
    return Path(tempfile.mkdtemp(prefix="incubrix_test_"))


def make_narration(segments: list[tuple[float, float]], total_s: float, sr: int = 48000, path: Path | None = None) -> Path:
    """Speech-like signal: amplitude-modulated harmonic tone bursts inside ``segments``."""
    t = np.arange(int(total_s * sr)) / sr
    rng = np.random.default_rng(1)
    x = np.zeros_like(t)
    for a, b in segments:
        m = (t >= a) & (t < b)
        syl = 0.5 + 0.5 * np.sin(2 * np.pi * 4 * t[m]) ** 2
        x[m] = 0.25 * syl * (np.sin(2 * np.pi * 140 * t[m]) + 0.5 * np.sin(2 * np.pi * 420 * t[m]) + 0.1 * rng.standard_normal(m.sum()))
    path = path or tmpdir() / "narration.wav"
    write_wav(path, quantize(x[:, None], 16), sr, 16)
    return path


@lru_cache(maxsize=32)
def run(provider: str, prompt: str, duration_s: float, loopable: bool = False, seed: int = 7, narration: str | None = None,
        sections: str | None = None, tempo: float | None = None, key: str | None = None) -> GenerationResult:
    import json
    req = {"prompt": prompt, "duration_s": duration_s, "loopable": loopable, "seed": seed}
    if sections:
        req["sections"] = json.loads(sections)
    if tempo:
        req["tempo_bpm"] = tempo
    if key:
        req["key"] = key
    return generate(req, get_provider(provider), tmpdir(), job_id="test", narration_path=narration)


def load(res: GenerationResult, rel: str) -> tuple[np.ndarray, int]:
    pcm, sr, bits = read_wav_pcm(res.files[rel])
    return dequantize(pcm, bits), sr


def stem_sum_error(res: GenerationResult) -> int:
    mix, _, _ = read_wav_pcm(res.files["mix.wav"])
    total = sum(read_wav_pcm(res.files[f"stems/{s}.wav"])[0].astype(np.int64) for s in STEMS)
    return int(np.abs(total - mix).max())

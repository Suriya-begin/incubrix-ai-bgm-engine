"""HTTP contract, error format, idempotency, correlation ids, rate limiting, uploads, regeneration, e2e."""
from __future__ import annotations

import hashlib
import json
import threading

import pytest
from fastapi.testclient import TestClient

from app.callbacks import sign, verify
from app.config import Settings
from app.db import Database
from app.main import create_app
from tests.conftest import FakeStorage, drain
from tests.helpers import make_narration

BODY = {"prompt": "calm piano", "duration_s": 8, "seed": 3}


def assert_error(resp, status, code):
    assert resp.status_code == status, resp.text
    e = resp.json()["error"]
    assert set(e) == {"code", "message", "retryable", "details"}
    assert e["code"] == code and e["code"].isupper().__bool__() and isinstance(e["retryable"], bool)


def test_health_and_ready(client):
    assert client.get("/health").json()["status"] == "ok"
    r = client.get("/ready")
    assert r.status_code == 200 and r.json()["checks"]["storage"] == "ok" and r.json()["checks"]["worker"] == "ok"


def test_ready_503_without_worker(settings, storage):
    app = create_app(settings, storage, Database(settings.sqlite_path))  # type: ignore[arg-type]
    assert_error(TestClient(app).get("/ready"), 503, "SERVICE_NOT_READY")


def test_create_job_returns_202_and_job_is_queued(client):
    r = client.post("/api/v1/music/jobs", json=BODY)
    assert r.status_code == 202 and r.json()["status"] == "queued" and r.headers["Location"].endswith(r.json()["job_id"])
    s = client.get(f"/api/v1/jobs/{r.json()['job_id']}").json()
    assert s["status"] == "queued" and s["progress"] == 0 and s["result"] is None


def test_end_to_end_job_produces_all_downloads(env):
    c = env["client"]
    job_id = c.post("/api/v1/music/jobs", json={**BODY, "loopable": True}).json()["job_id"]
    drain(env)
    s = c.get(f"/api/v1/jobs/{job_id}").json()
    assert s["status"] == "succeeded" and s["progress"] == 100
    files = s["result"]["files"]
    for rel in ["mix.wav", "mix.mp3", "music_manifest.json"] + [f"stems/{x}.wav" for x in ("drums", "bass", "harmony", "melody")]:
        assert rel in files, rel
    assert "mix_ducked.wav" not in files and not any(k.startswith("internal") for k in files)
    manifest = json.loads(env["storage"].objects[f"jobs/{job_id}/music_manifest.json"])
    assert manifest["job_id"] == job_id and manifest["timings_ms"]["upload"] >= 0


def test_narration_upload_then_ducked_output(env):
    c = env["client"]
    nar = make_narration([(1, 3)], 6)
    up = c.post("/api/v1/assets/upload", files={"file": ("n.wav", nar.read_bytes(), "audio/wav")})
    assert up.status_code == 201 and up.json()["asset_url"].startswith("asset://")
    job_id = c.post("/api/v1/music/jobs", json={**BODY, "narration_url": up.json()["asset_url"]}).json()["job_id"]
    drain(env)
    s = c.get(f"/api/v1/jobs/{job_id}").json()
    assert s["status"] == "succeeded" and "mix_ducked.wav" in s["result"]["files"]
    assert json.loads(env["storage"].objects[f"jobs/{job_id}/music_manifest.json"])["ducking_curve"]


def test_regenerate_stem_endpoint(env):
    c = env["client"]
    src = c.post("/api/v1/music/jobs", json=BODY).json()["job_id"]
    assert_error(c.post(f"/api/v1/music/jobs/{src}/regenerate-stem", json={"stem": "drums"}), 400, "SOURCE_JOB_NOT_SUCCEEDED")
    drain(env)
    r = c.post(f"/api/v1/music/jobs/{src}/regenerate-stem", json={"stem": "drums", "seed": 99, "prompt_override": "techno"})
    assert r.status_code == 202 and r.json()["job_id"] != src
    drain(env)
    new = c.get(f"/api/v1/jobs/{r.json()['job_id']}").json()
    assert new["status"] == "succeeded" and new["parent_job_id"] == src
    st = env["storage"].objects
    for s in ("bass", "harmony", "melody"):
        assert st[f"jobs/{src}/stems/{s}.wav"] == st[f"jobs/{r.json()['job_id']}/stems/{s}.wav"]
    assert st[f"jobs/{src}/stems/drums.wav"] != st[f"jobs/{r.json()['job_id']}/stems/drums.wav"]
    assert_error(c.post("/api/v1/music/jobs/nope/regenerate-stem", json={"stem": "drums"}), 404, "JOB_NOT_FOUND")
    assert_error(c.post(f"/api/v1/music/jobs/{src}/regenerate-stem", json={"stem": "violin"}), 422, "VALIDATION_ERROR")


# ---------------------------------------------------------------- errors
def test_error_shapes(client):
    assert_error(client.post("/api/v1/music/jobs", json={**BODY, "duration_s": 2}), 422, "DURATION_OUT_OF_RANGE")
    assert_error(client.post("/api/v1/music/jobs", json={**BODY, "duration_s": 301}), 422, "DURATION_OUT_OF_RANGE")
    assert_error(client.post("/api/v1/music/jobs", json={"duration_s": 10}), 422, "VALIDATION_ERROR")
    assert_error(client.post("/api/v1/music/jobs", json={**BODY, "narration_url": "ftp://x/y.wav"}), 422, "INVALID_NARRATION_URL")
    assert_error(client.post("/api/v1/music/jobs", json={**BODY, "callback_url": "javascript:1"}), 422, "INVALID_CALLBACK_URL")
    assert_error(client.get("/api/v1/jobs/does-not-exist"), 404, "JOB_NOT_FOUND")
    assert_error(client.get("/api/v1/nothing"), 404, "NOT_FOUND")
    assert_error(client.put("/api/v1/music/jobs", json=BODY), 405, "METHOD_NOT_ALLOWED")
    assert_error(client.post("/api/v1/music/jobs", content=b"{not json", headers={"Content-Type": "application/json"}), 422, "VALIDATION_ERROR")


def test_unhandled_exception_is_500_json(settings, storage):
    app = create_app(settings, storage, Database(settings.sqlite_path))  # type: ignore[arg-type]

    @app.get("/boom")
    def boom():
        raise RuntimeError("x")
    assert_error(TestClient(app, raise_server_exceptions=False).get("/boom"), 500, "INTERNAL_ERROR")


def test_worker_failure_surfaces_job_error(env):
    c = env["client"]
    job_id = c.post("/api/v1/music/jobs", json={**BODY, "narration_url": "asset://missing"}).json()["job_id"]
    drain(env)
    s = c.get(f"/api/v1/jobs/{job_id}").json()
    assert s["status"] == "failed" and s["error"]["code"] == "NARRATION_FETCH_FAILED" and set(s["error"]) == {"code", "message", "retryable", "details"}


# ---------------------------------------------------------------- idempotency
def test_idempotency_key_returns_same_job_without_new_work(env):
    c, db = env["client"], env["db"]
    h = {"Idempotency-Key": "abc-123"}
    a = c.post("/api/v1/music/jobs", json=BODY, headers=h)
    b = c.post("/api/v1/music/jobs", json=BODY, headers=h)
    assert a.json()["job_id"] == b.json()["job_id"] and b.headers["Idempotent-Replayed"] == "true"
    assert db.counts() == {"queued": 1}
    assert_error(c.post("/api/v1/music/jobs", json={**BODY, "duration_s": 9}, headers=h), 400, "IDEMPOTENCY_KEY_MISMATCH")
    drain(env)
    again = c.post("/api/v1/music/jobs", json=BODY, headers=h)
    assert again.json()["job_id"] == a.json()["job_id"] and again.json()["status"] == "succeeded" and db.counts() == {"succeeded": 1}


def test_concurrent_identical_requests_create_one_job(env):
    c, db = env["client"], env["db"]
    ids: list[str] = []

    def go():
        ids.append(c.post("/api/v1/music/jobs", json=BODY, headers={"Idempotency-Key": "race"}).json()["job_id"])
    ts = [threading.Thread(target=go) for _ in range(12)]
    [t.start() for t in ts]; [t.join() for t in ts]
    assert len(set(ids)) == 1 and sum(db.counts().values()) == 1


def test_idempotency_on_regenerate_and_upload(env):
    c = env["client"]
    src = c.post("/api/v1/music/jobs", json=BODY).json()["job_id"]
    drain(env)
    h = {"Idempotency-Key": "regen-1"}
    a = c.post(f"/api/v1/music/jobs/{src}/regenerate-stem", json={"stem": "bass"}, headers=h).json()["job_id"]
    b = c.post(f"/api/v1/music/jobs/{src}/regenerate-stem", json={"stem": "bass"}, headers=h).json()["job_id"]
    assert a == b
    f = {"file": ("n.wav", b"RIFFxxxx", "audio/wav")}
    u1 = c.post("/api/v1/assets/upload", files=f, headers={"Idempotency-Key": "up-1"}).json()
    u2 = c.post("/api/v1/assets/upload", files=f, headers={"Idempotency-Key": "up-1"}).json()
    assert u1 == u2
    assert_error(c.post("/api/v1/assets/upload", files={"file": ("n.wav", b"different", "audio/wav")}, headers={"Idempotency-Key": "up-1"}), 400, "IDEMPOTENCY_KEY_MISMATCH")


# ---------------------------------------------------------------- headers, limits
def test_correlation_id_generated_and_echoed(client):
    r = client.get("/health")
    assert len(r.headers["X-Correlation-Id"]) >= 16
    assert client.get("/health", headers={"X-Correlation-Id": "abc"}).headers["X-Correlation-Id"] == "abc"
    assert client.get("/api/v1/jobs/x", headers={"X-Correlation-Id": "err-1"}).headers["X-Correlation-Id"] == "err-1"


def test_rate_limit_returns_429(tmp_path):
    s = Settings(music_provider="mock", data_dir=str(tmp_path), rate_limit_enabled=True, rate_limit_jobs_per_minute=3, rate_limit_per_minute=100)
    c = TestClient(create_app(s, FakeStorage(), Database(s.sqlite_path)))  # type: ignore[arg-type]
    codes = [c.post("/api/v1/music/jobs", json=BODY).status_code for _ in range(5)]
    assert codes[:3] == [202, 202, 202] and codes[3:] == [429, 429]
    r = c.post("/api/v1/music/jobs", json=BODY)
    assert_error(r, 429, "RATE_LIMITED")
    assert r.json()["error"]["retryable"] is True and int(r.headers["Retry-After"]) >= 1


def test_logs_are_json_with_ids(client, capsys):
    client.get("/health", headers={"X-Correlation-Id": "log-test"})
    lines = [json.loads(x) for x in capsys.readouterr().out.splitlines() if x.startswith("{")]
    rec = next(x for x in lines if x.get("path") == "/health")
    assert {"timestamp", "level", "job_id", "correlation_id"} <= set(rec) and rec["correlation_id"] == "log-test"


def test_callback_signature_roundtrip():
    body = b'{"job_id":"1"}'
    sig = sign("s", body)
    assert sig.startswith("sha256=") and verify("s", body, sig) and not verify("s", body + b" ", sig) and not verify("t", body, sig)


def test_openapi_documents_required_routes(client):
    spec = client.get("/openapi.json").json()
    assert spec["openapi"].startswith("3.1")
    for p in ("/api/v1/music/jobs", "/api/v1/jobs/{job_id}", "/api/v1/music/jobs/{job_id}/regenerate-stem", "/api/v1/assets/upload", "/health", "/ready"):
        assert p in spec["paths"], p


def test_committed_openapi_yaml_matches_app(client):
    import pathlib, yaml
    if not pathlib.Path("openapi.yaml").exists():
        pytest.skip("openapi.yaml not generated yet: run python -m scripts.export_openapi")
    committed = yaml.safe_load(pathlib.Path("openapi.yaml").read_text())
    live = client.get("/openapi.json").json()
    assert committed == json.loads(json.dumps(live)), "run: python -m scripts.export_openapi"

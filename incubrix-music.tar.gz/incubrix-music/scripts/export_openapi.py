"""Write openapi.yaml from the live FastAPI app (OpenAPI 3.1). `--check` fails if the file is stale."""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

os.environ["INCUBRIX_NO_AUTOAPP"] = "1"
import yaml  # noqa: E402

from app.config import Settings  # noqa: E402
from app.main import create_app  # noqa: E402


class _NoStorage:
    def ensure_bucket(self) -> None: ...
    def ping(self) -> bool: return False


def build() -> dict:
    import tempfile
    from app.db import Database
    s = Settings(data_dir=tempfile.mkdtemp(), music_provider="mock")
    app = create_app(s, _NoStorage(), Database(s.sqlite_path))  # type: ignore[arg-type]
    return json.loads(json.dumps(app.openapi()))


def main() -> int:
    spec = build()
    text = yaml.safe_dump(spec, sort_keys=False, allow_unicode=True)
    path = Path("openapi.yaml")
    if "--check" in sys.argv:
        return 0 if path.exists() and yaml.safe_load(path.read_text()) == spec else 1
    path.write_text(text)
    print(f"wrote {path} (openapi {spec['openapi']}, {len(spec['paths'])} paths)")
    return 0


if __name__ == "__main__":
    sys.exit(main())

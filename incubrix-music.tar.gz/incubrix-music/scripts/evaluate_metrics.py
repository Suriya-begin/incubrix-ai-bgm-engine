"""Measure the engine in-process: latency (cold vs warm), loudness, true peak, stem-sum residual,
stem cross-correlation (bleed), loop click ratio. Writes CSV/JSON/Markdown tables and SVG charts.

    python -m scripts.evaluate_metrics --providers procedural_synth,mock --out report_data
"""
from __future__ import annotations

import argparse
import csv
import itertools
import json
import platform
import resource
import tempfile
import time
from pathlib import Path

import numpy as np

from app.audio_io import dequantize, read_wav_pcm
from app.audio_processor import loop_click_ratio
from app.loudness import integrated_lufs, true_peak_db
from app.pipeline import generate
from app.providers.base import get_provider

STEMS = ("drums", "bass", "harmony", "melody")
CASES = [  # (genre label, prompt, duration_s)
    ("cinematic", "epic cinematic trailer, dramatic orchestral build", 5),
    ("lofi", "lo-fi chill study beats, cozy and mellow", 10),
    ("corporate", "uplifting corporate presentation, optimistic", 20),
    ("electronic", "energetic electronic dance, synthwave club", 30),
    ("acoustic", "warm acoustic folk guitar, natural", 45),
    ("tense", "dark tense thriller suspense", 60),
    ("playful", "playful quirky kids cartoon", 90),
    ("energetic", "upbeat sports workout, powerful", 120),
    ("calm", "calm peaceful ambient meditation", 180),
    ("melancholic", "sad nostalgic melancholic piano mood", 300),
]


def bleed(res_files: dict[str, Path]) -> float:
    mono = []
    for s in STEMS:
        pcm, _, bits = read_wav_pcm(res_files[f"stems/{s}.wav"])
        mono.append(dequantize(pcm, bits).mean(axis=1)[::4])
    m = np.array([x - x.mean() for x in mono])
    c = np.corrcoef(m)
    return float(max(abs(c[i, j]) for i, j in itertools.combinations(range(4), 2)))


def run_case(provider: str, genre: str, prompt: str, dur: float, loop: bool = False) -> dict:
    prov = get_provider(provider)
    t0 = time.perf_counter()
    r = generate({"prompt": prompt, "duration_s": dur, "seed": 42, "loopable": loop}, prov, tempfile.mkdtemp(), job_id="eval")
    wall = time.perf_counter() - t0
    pcm, sr, bits = read_wav_pcm(r.files["mix.wav"])
    x = dequantize(pcm, bits)
    stems_sum = sum(read_wav_pcm(r.files[f"stems/{s}.wav"])[0].astype(np.int64) for s in STEMS)
    m = r.manifest
    return {
        "provider": provider, "genre": genre, "duration_s": dur, "loopable": loop, "tempo_bpm": round(m["tempo_bpm"], 2), "key": m["key"],
        "duration_actual_s": round(pcm.shape[0] / sr, 6), "duration_delta_ms": round(abs(pcm.shape[0] / sr - dur) * 1000, 4),
        "lufs": round(integrated_lufs(x, sr), 2), "true_peak_dbtp": round(true_peak_db(x), 2),
        "stem_sum_max_err_lsb": int(np.abs(stems_sum - pcm).max()), "stem_sum_residual_db": m["loudness"]["stem_sum_residual_db"],
        "max_stem_correlation": round(bleed(r.files), 3),
        "loop_click_ratio": round(loop_click_ratio(x), 3) if loop else None,
        "wall_s": round(wall, 2), "realtime_factor": round(dur / wall, 1), "cost_usd": m["estimated_cost_usd"],
        "cost_usd_per_audio_min": round(m["estimated_cost_usd"] / (dur / 60), 6),
        "warnings": len(m["warnings"]),
    }


def svg_bars(title: str, rows: list[tuple[str, float]], path: Path, unit: str) -> None:
    w, h, left = 760, 40 + 26 * len(rows), 150
    mx = max(v for _, v in rows) or 1
    out = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" font-family="sans-serif" font-size="12">',
           f'<text x="10" y="20" font-weight="bold">{title}</text>']
    for i, (label, v) in enumerate(rows):
        y = 34 + i * 26
        bw = (w - left - 90) * v / mx
        out.append(f'<text x="10" y="{y + 13}">{label}</text><rect x="{left}" y="{y}" width="{bw:.1f}" height="18" fill="#4a7bd0"/>'
                   f'<text x="{left + bw + 6:.1f}" y="{y + 13}">{v:g} {unit}</text>')
    out.append("</svg>")
    path.write_text("\n".join(out))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--providers", default="procedural_synth,mock")
    ap.add_argument("--out", default="report_data")
    ap.add_argument("--max-duration", type=float, default=300)
    a = ap.parse_args()
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    rows: list[dict] = []
    cold_warm: dict[str, dict] = {}
    for provider in a.providers.split(","):
        # cold: first generate in this process; warm: same request again
        c = run_case(provider, "cold-start probe", "calm", 5)
        w = run_case(provider, "warm probe", "calm", 5)
        cold_warm[provider] = {"cold_wall_s": c["wall_s"], "warm_wall_s": w["wall_s"]}
        for genre, prompt, dur in CASES:
            if dur <= a.max_duration:
                rows.append(run_case(provider, genre, prompt, dur))
        for genre, prompt, dur in CASES[:3]:
            rows.append(run_case(provider, genre + " (loop)", prompt, min(dur, 20) if dur > 20 else dur, True))
    rows_meta = {"machine": platform.platform(), "python": platform.python_version(), "peak_rss_mb": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss // 1024,
                 "cold_vs_warm": cold_warm}
    (out / "metrics.json").write_text(json.dumps({"meta": rows_meta, "rows": rows}, indent=2))
    with open(out / "metrics.csv", "w", newline="") as fh:
        wr = csv.DictWriter(fh, fieldnames=list(rows[0]))
        wr.writeheader()
        wr.writerows(rows)
    md = ["| provider | genre | dur s | bpm | LUFS | TP dBTP | sum err (LSB) | max stem corr | wall s | x realtime |", "|---|---|---|---|---|---|---|---|---|---|"]
    for r in rows:
        md.append(f"| {r['provider']} | {r['genre']} | {r['duration_s']:g} | {r['tempo_bpm']} | {r['lufs']} | {r['true_peak_dbtp']} | {r['stem_sum_max_err_lsb']} | {r['max_stem_correlation']} | {r['wall_s']} | {r['realtime_factor']} |")
    (out / "metrics_table.md").write_text("\n".join(md))
    for provider in a.providers.split(","):
        sub = [r for r in rows if r["provider"] == provider and not r["loopable"]]
        svg_bars(f"Render time by clip length ({provider})", [(f"{r['genre']} {r['duration_s']:g}s", r["wall_s"]) for r in sub], out / f"latency_{provider}.svg", "s")
    print(json.dumps(rows_meta, indent=2))
    print("\n".join(md))


if __name__ == "__main__":
    main()

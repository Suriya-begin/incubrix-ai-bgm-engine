"""Generate a deterministic speech-like narration clip for demos and the batch runner."""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

from app.audio_io import quantize, write_wav


def main(path: str = "tests/assets/narration_sample.wav", sr: int = 22050) -> None:
    t = np.arange(int(20 * sr)) / sr
    rng = np.random.default_rng(1)
    x = np.zeros_like(t)
    for a, b in [(2, 5), (9, 11), (16, 19)]:
        m = (t >= a) & (t < b)
        syl = 0.5 + 0.5 * np.sin(2 * np.pi * 4 * t[m]) ** 2
        x[m] = 0.25 * syl * (np.sin(2 * np.pi * 140 * t[m]) + 0.5 * np.sin(2 * np.pi * 420 * t[m]) + 0.1 * rng.standard_normal(m.sum()))
    write_wav(Path(path), quantize(x[:, None], 16), sr, 16)


if __name__ == "__main__":
    main(*sys.argv[1:])

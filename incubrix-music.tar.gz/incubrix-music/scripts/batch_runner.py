"""Submit a test pack to a running API, poll, download everything, verify, and report.

    python -m scripts.batch_runner --input tests/batch_inputs.json --output ./test_pack_output --api-url http://localhost:8000
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import sys
import time
from pathlib import Path
from typing import Any

import httpx
import numpy as np

from app.audio_io import dequantize, read_wav_pcm
from app.loudness import integrated_lufs, true_peak_db

STEMS = ("drums", "bass", "harmony", "melody")
FIELDS = ["case", "status", "job_id", "duration_delta_s", "lufs", "true_peak_dbtp", "stem_sum_residual_db", "non_silent", "ducking_ok",
          "warnings", "latency_s", "checks_passed", "failed_checks"]


def request(client: httpx.Client, method: str, url: str, **kw: Any) -> httpx.Response:
    for _ in range(6):
        r = client.request(method, url, **kw)
        if r.status_code == 429:
            time.sleep(float(r.headers.get("Retry-After", "2")))
            continue
        return r
    return r


def verify(case: dict[str, Any], out: Path, manifest: dict[str, Any], has_narration: bool) -> tuple[dict[str, Any], list[str]]:
    failed: list[str] = []
    mix_pcm, sr, bits = read_wav_pcm(out / "mix.wav")
    mix = dequantize(mix_pcm, bits)
    want = float(case["request"]["duration_s"])
    delta = abs(mix.shape[0] / sr - want)
    target = float(case["request"].get("output", {}).get("target_lufs", -16.0))
    lufs, tp = integrated_lufs(mix, sr), true_peak_db(mix)
    total = np.zeros_like(mix_pcm, dtype=np.int64)
    silent: list[str] = []
    for s in STEMS:
        pcm, _, _ = read_wav_pcm(out / "stems" / f"{s}.wav")
        if pcm.shape != mix_pcm.shape:
            failed.append(f"stem_{s}_length")
        total += pcm
        if 20 * np.log10(np.sqrt(np.mean(dequantize(pcm, bits) ** 2)) + 1e-12) < -60:
            silent.append(s)
    diff = np.sqrt(np.mean((dequantize(total, bits) - mix) ** 2))
    residual = 20 * np.log10(diff / np.sqrt(np.mean(mix ** 2))) if diff > 0 else -300.0
    if delta >= 0.05:
        failed.append("duration_delta")
    if abs(lufs - target) > 0.5:
        failed.append("lufs")
    if tp > -1.0:
        failed.append("true_peak")
    if residual > -90:
        failed.append("stem_sum_residual")
    if silent or 20 * np.log10(np.sqrt(np.mean(mix ** 2)) + 1e-12) < -50:
        failed.append("non_silence")
    ducking_ok = None
    if has_narration and (out / "mix_ducked.wav").exists():
        d_pcm, _, _ = read_wav_pcm(out / "mix_ducked.wav")
        ducked = dequantize(d_pcm, bits)
        gains = [p["gain_db"] for p in manifest.get("ducking_curve", [])]
        speech = manifest.get("ducking", {}).get("segments", [])
        ducking_ok = True
        if speech:
            a, b = speech[0]["start_s"] + 0.3, speech[0]["end_s"] - 0.1
            if b > a:
                sl = slice(int(a * sr), int(b * sr))
                dd = 10 * np.log10(np.mean(ducked[sl] ** 2) / (np.mean(mix[sl] ** 2) + 1e-20))
                ducking_ok = -12.5 <= dd <= -9.5
        elif gains and min(gains) < -0.1:
            ducking_ok = False
        if not ducking_ok:
            failed.append("ducking")
    metrics = {"duration_delta_s": round(float(delta), 6), "lufs": round(float(lufs), 2), "true_peak_dbtp": round(float(tp), 2),
               "stem_sum_residual_db": round(float(residual), 2), "non_silent": not silent, "ducking_ok": ducking_ok}
    return metrics, failed


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--output", required=True)
    ap.add_argument("--api-url", default="http://localhost:8000")
    ap.add_argument("--timeout", type=float, default=900.0)
    a = ap.parse_args()
    cases = json.loads(Path(a.input).read_text())
    base = Path(a.input).parent
    out_root = Path(a.output)
    out_root.mkdir(parents=True, exist_ok=True)
    rows: list[dict[str, Any]] = []
    with httpx.Client(base_url=a.api_url, timeout=60.0) as client:
        submitted: list[tuple[dict[str, Any], str, float]] = []
        for case in cases:
            name = case["name"]
            body = dict(case["request"])
            if case.get("narration_file"):
                p = (base / case["narration_file"]) if not Path(case["narration_file"]).is_absolute() else Path(case["narration_file"])
                up = request(client, "POST", "/api/v1/assets/upload", files={"file": (p.name, p.read_bytes(), "audio/wav")},
                             headers={"Idempotency-Key": f"batch-up-{name}-{hashlib.sha1(p.read_bytes()).hexdigest()[:10]}"})
                up.raise_for_status()
                body["narration_url"] = up.json()["asset_url"]
            key = "batch-" + hashlib.sha1(json.dumps([name, body], sort_keys=True).encode()).hexdigest()[:16]
            r = request(client, "POST", "/api/v1/music/jobs", json=body, headers={"Idempotency-Key": key})
            expect = case.get("expect_http_status")
            if expect:
                ok = r.status_code == expect and r.json().get("error", {}).get("code") == case.get("expect_error_code", r.json().get("error", {}).get("code"))
                rows.append({"case": name, "status": f"http_{r.status_code}", "job_id": "", "checks_passed": ok, "failed_checks": "" if ok else f"expected {expect} {case.get('expect_error_code', '')}",
                             "warnings": 0, "latency_s": 0})
                print(f"[{name}] expected error -> {r.status_code} {'OK' if ok else 'MISMATCH'}")
                continue
            if r.status_code != 202:
                rows.append({"case": name, "status": f"http_{r.status_code}", "job_id": "", "checks_passed": False, "failed_checks": r.text[:200], "warnings": 0, "latency_s": 0})
                print(f"[{name}] submit failed: {r.status_code} {r.text[:200]}")
                continue
            submitted.append((case, r.json()["job_id"], time.time()))
            print(f"[{name}] queued {r.json()['job_id']}")

        for case, job_id, t0 in submitted:
            name = case["name"]
            status: dict[str, Any] = {}
            while time.time() - t0 < a.timeout:
                status = request(client, "GET", f"/api/v1/jobs/{job_id}").json()
                if status.get("status") in ("succeeded", "failed"):
                    break
                time.sleep(1.0)
            latency = round(time.time() - t0, 2)
            row: dict[str, Any] = {"case": name, "status": status.get("status", "timeout"), "job_id": job_id, "latency_s": latency,
                                   "warnings": len(status.get("warnings", [])), "checks_passed": False, "failed_checks": ""}
            if status.get("status") != "succeeded":
                row["failed_checks"] = json.dumps(status.get("error") or "timeout")
                rows.append(row)
                print(f"[{name}] {row['status']} {row['failed_checks']}")
                continue
            out = out_root / name
            for rel, url in status["result"]["files"].items():
                dest = out / rel
                dest.parent.mkdir(parents=True, exist_ok=True)
                dest.write_bytes(httpx.get(url, timeout=120).content)
            manifest = json.loads((out / "music_manifest.json").read_text())
            metrics, failed = verify(case, out, manifest, bool(case.get("narration_file")))
            for want in case.get("expect_warnings", []):
                if not any(w.startswith(want) for w in manifest["warnings"]):
                    failed.append(f"missing_warning:{want}")
            row.update(metrics, checks_passed=not failed, failed_checks=",".join(failed))
            rows.append(row)
            print(f"[{name}] {'PASS' if not failed else 'FAIL ' + ','.join(failed)}  {latency}s  {metrics['lufs']} LUFS  {metrics['true_peak_dbtp']} dBTP")
            if case.get("regenerate_stem"):
                rg = dict(case["regenerate_stem"])
                rr = request(client, "POST", f"/api/v1/music/jobs/{job_id}/regenerate-stem", json=rg, headers={"Idempotency-Key": f"batch-regen-{job_id}-{rg['stem']}"})
                new_id = rr.json().get("job_id")
                while new_id and time.time() - t0 < a.timeout:
                    st = request(client, "GET", f"/api/v1/jobs/{new_id}").json()
                    if st["status"] in ("succeeded", "failed"):
                        break
                    time.sleep(1.0)
                good = bool(new_id) and st["status"] == "succeeded"
                if good:
                    rout = out_root / f"{name}__regen_{rg['stem']}"
                    for rel, url in st["result"]["files"].items():
                        (rout / rel).parent.mkdir(parents=True, exist_ok=True)
                        (rout / rel).write_bytes(httpx.get(url, timeout=120).content)
                    same = all((out / f"stems/{s}.wav").read_bytes() == (rout / f"stems/{s}.wav").read_bytes() for s in STEMS if s != rg["stem"])
                    changed = (out / f"stems/{rg['stem']}.wav").read_bytes() != (rout / f"stems/{rg['stem']}.wav").read_bytes()
                    m2, f2 = verify(case, rout, json.loads((rout / "music_manifest.json").read_text()), False)
                    f2 = [f for f in f2 if f != "lufs"]  # mix level may drift slightly by design; reported as a warning
                    ok = same and changed and not f2
                    rows.append({"case": f"{name}__regen_{rg['stem']}", "status": st["status"], "job_id": new_id, "checks_passed": ok, "warnings": len(st.get("warnings", [])),
                                 "failed_checks": "" if ok else f"others_unchanged={same} stem_changed={changed} {f2}", "latency_s": 0, **m2})
                    print(f"[{name}] regenerate {rg['stem']}: {'PASS' if ok else 'FAIL'}")
                else:
                    rows.append({"case": f"{name}__regen_{rg['stem']}", "status": "failed", "job_id": new_id or "", "checks_passed": False, "failed_checks": "regenerate job failed", "warnings": 0, "latency_s": 0})

    passed = sum(1 for r in rows if r["checks_passed"])
    summary = {"api_url": a.api_url, "cases": len(rows), "passed": passed, "failed": len(rows) - passed, "results": rows}
    (out_root / "summary_report.json").write_text(json.dumps(summary, indent=2))
    with open(out_root / "metrics.csv", "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=FIELDS, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)
    print(f"\n{passed}/{len(rows)} cases passed. Report: {out_root / 'summary_report.json'}")
    return 0 if passed == len(rows) else 1


if __name__ == "__main__":
    sys.exit(main())

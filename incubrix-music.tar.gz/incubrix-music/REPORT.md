# Engineering report: AI Background Music Engine

## 1. Approach and trade-offs

The brief needs four stems that add up to the mix, an exact duration, and no clicks at loop points.
Those are structural guarantees, so the engine composes symbolically on one bar grid and renders each
stem separately, instead of generating audio and hoping it can be taken apart.

| | Symbolic multi-stem (chosen) | Procedural DSP synth | Neural audio + Demucs |
|---|---|---|---|
| Stem sum equals mix | exact by construction | exact by construction | no: separation leaves bleed and a residual |
| Exact duration, bar-locked sections | exact: tempo is snapped to whole bars | exact | needs trimming or time-stretch, sections drift |
| Single-stem regeneration | re-render one stem, others untouched | same | regenerates the whole mix, then re-separates |
| Sound quality | sampled GM instruments: familiar, dated | thin, clearly synthetic | best timbre, least control |
| Licence exposure | SoundFont licence only | none (no samples) | model and training-data terms, harder to audit |
| Cost per audio minute | CPU only | CPU only | GPU |
| Determinism | same seed gives same bytes | same | usually not |

I built two providers behind one interface so they can be compared: `fluidsynth_symbolic` (default) and
`procedural_synth`, plus `mock` for CI. Only `procedural_synth` and `mock` were executed here, so the
comparison below is measured for those two and argued, not measured, for FluidSynth.

Design decisions that matter:

* **Tempo snapping.** `bpm = bars * 240 / duration_s` with `bars` the whole number nearest the requested
  tempo. A 90 BPM request for 90 s becomes exactly 90 BPM; for 90 s at 120 BPM-ish moods it lands on
  122.67 BPM. This is why section starts always sit on bar lines and the file length is exact.
* **One scalar, one gain curve.** Loudness normalisation and the true-peak limiter apply the same
  scalar and the same time-varying gain to every stem. The mix file is then defined as the integer sum
  of the quantized stem files, so the residual is exactly zero rather than merely small.
* **Loops.** Rendering keeps a 3 s tail that is added back onto bar 1, and the limiter is circular.
* **Regeneration.** The new stem is loudness-matched to the one it replaces and passed through the
  stored limiter curve, so other stems stay byte-identical. Cost: the mix level can drift from
  -16 LUFS by a few tenths, which is reported as `LOUDNESS_DRIFT` instead of hidden.

## 2. Measured results

Machine: sandbox VM, Linux x86_64, Python 3.12, one process, `peak_rss` 2.1 GB at 300 s.
Provider `procedural_synth`, seed 42, 24-bit 48 kHz, target -16 LUFS. Raw data: `report_data/metrics.csv`.

| genre | dur s | bpm | key | LUFS | TP dBTP | sum err (LSB) | max stem corr | wall s | x realtime |
|---|---|---|---|---|---|---|---|---|---|
| cinematic | 5 | 96.0 | F minor | -16.0 | -3.92 | 0 | 0.056 | 1.15 | 4.3 |
| lofi | 10 | 72.0 | G dorian | -16.0 | -1.73 | 0 | 0.039 | 1.2 | 8.3 |
| corporate | 20 | 108.0 | A major | -16.0 | -1.6 | 0 | 0.03 | 2.15 | 9.3 |
| electronic | 30 | 128.0 | D minor | -16.0 | -1.72 | 0 | 0.016 | 2.83 | 10.6 |
| acoustic | 45 | 96.0 | A major | -16.02 | -1.5 | 0 | 0.026 | 3.93 | 11.4 |
| tense | 60 | 100.0 | D phrygian | -16.0 | -1.7 | 0 | 0.006 | 5.45 | 11.0 |
| playful | 90 | 122.67 | D major | -16.0 | -1.5 | 0 | 0.057 | 8.62 | 10.4 |
| energetic | 120 | 132.0 | G mixolydian | -16.0 | -1.5 | 0 | 0.09 | 12.61 | 9.5 |
| calm | 180 | 68.0 | D major | -16.0 | -1.5 | 0 | 0.036 | 18.66 | 9.6 |
| melancholic | 300 | 70.4 | C minor | -16.0 | -1.56 | 0 | 0.03 | 28.66 | 10.5 |

* Duration error was 0.0 ms in all 26 runs (sample counts equal `round(duration_s * 48000)`).
* Stem-sum residual was 0 LSB everywhere, reported in the manifest as the floor value `-300 dB`.
  This is a property of defining the mix as the stem sum, not a measurement of independent rounding.
* Bleed: largest absolute zero-lag correlation between any two stems was 0.11 (mock) and 0.09 (procedural).
* Loop seam (boundary jump divided by the 99.9th percentile sample step, click if above about 1.5):
  0.008 to 0.051 for procedural, 0.0 for mock.
* Loudness was within 0.02 LU of target for procedural. **`mock` missed on long clips**: -16.28 LUFS at
  180 s and -16.87 LUFS at 300 s, which raised `LOUDNESS_TARGET_MISSED`. Its sparse blips force the
  limiter to engage hard, so no scalar reaches the target. It is a CI stand-in, and I left the miss visible.
* `mock` is not "instant" in practice: 0.7 s for 5 s and 48 s for 300 s, because mastering, quantizing
  and MP3 encoding cost the same as for real audio.
* Cold versus warm in one process: 0.84 s versus 0.98 s (procedural) and 0.80 s versus 0.70 s (mock),
  so in-process warm-up is noise. Real cold start (container boot, first import, ffmpeg spawn) was
  **not measured**. The worker runs a 5 s warm-up render at boot and `/ready` exposes whether it finished.

### Hard cases (executed, `tests/test_hard_cases.py`, all pass)

| # | Case | Result |
|---|---|---|
| 1 | artist reference ("like Coldplay", "in the style of Taylor Swift", "sounds like Hans Zimmer") | name stripped from the effective prompt, exact `ARTIST_REFERENCE_SANITIZED` warning |
| 2 | vocals and lyrics requested | stripped, exact `VOCAL_REQUEST_IGNORED` warning; "no vocals" does not warn |
| 3 | non-English (Spanish, Chinese, French, Japanese with no known keyword) | `NON_ENGLISH_PROMPT`; keyword map picks calm and cinematic; unknown words fall back with `MOOD_FALLBACK` |
| 4 | "calm but aggressive" | `CONTRADICTORY_PROMPT`; 80 BPM, sustained pad harmony, driving 8th bass and drums |
| 5 | sections under 1.5 s apart | merged, `SECTIONS_MERGED`, remaining starts at least 1.5 s apart |
| 6 | `start_s` at or beyond duration | dropped, `SECTION_OUT_OF_RANGE` per section |
| 7 | narration with no speech | un-ducked mix, flat 0 dB curve, `NARRATION_NO_SPEECH` |
| 8 | narration shorter or longer than the music, long silences | padded or trimmed with a warning; music fully restored in silences |

Ducking (synthetic speech bursts at 2 to 5 s, 9 to 11 s, 16 to 19 s): the music dropped by 11.0 dB
during speech and by 0.03 dB or less in silences. The test narration is synthetic, so this validates
the detector and the curve, not behaviour on real recorded speech with breaths and room noise.

## 3. Production throughput and cost

On this machine procedural rendering ran about 10x real time on one core (4x for a 5 s clip, where fixed
costs dominate). One core therefore produces roughly 600 audio minutes per hour. With the assumed
`$0.04` per CPU-hour (`COMPUTE_COST_USD_PER_CPU_HOUR`, my assumption, not a quote), `estimated_cost_usd`
came to `$0.00006` to `$0.00016` per audio minute. Object storage and egress are excluded.

Limits found: peak memory was 2.1 GB for a 300 s clip because stems are held as float32 stereo plus one
float64 mix during mastering. Plan for 3 GB per worker if 300 s jobs are common; `WORKER_CONCURRENCY`
should stay at 1 per 4 GB. FluidSynth rendering adds an unmeasured subprocess cost per stem.

## 4. What was and was not verified

Executed: planner, arranger, procedural and mock providers, mastering, ducking, regeneration, the SQLite
job and idempotency layer (16 concurrent identical requests produced one job), 23 engine and hard-case
tests, and the benchmark above.

Not executed (no network, no Docker, only NumPy, SciPy, PyYAML and ffmpeg available):

* FastAPI routes, middleware, error handlers, and the 18 tests in `tests/test_api.py` (compiled only).
* MinIO and boto3, the worker's process isolation and callbacks, `docker compose up`, the Dockerfile.
* FluidSynth rendering and the MIDI writer against a real SoundFont. Only syntax was checked.
* `pyloudnorm`. The measurements used my own BS.1770-4 implementation, which should agree but was not
  cross-checked against it. A K-weighting mismatch would shift every LUFS figure.
* `openapi.yaml` is not committed. It must be generated, not hand-written: `python -m scripts.export_openapi`
  (the Docker build does this). The contract test skips until it exists.
* The audio was never listened to, and the licence rows in `SOURCES.md` were not checked against live pages.

Expect first-run failures in the untested layers. Run `pytest` before trusting any of it.

## 5. Roadmap

1. Run the untested layers and fix what breaks; add a CI job running `pytest` and `batch_runner` on the mock provider.
2. Listening pass per genre; the arranger is rule-based and the melodies are the weakest part.
3. Chunked mastering to cut memory at 300 s; render stems in parallel processes.
4. Replace SQLite with Redis or Postgres when more than one API host is needed; make rate limits shared.
5. Add a stereo-aware limiter option, a real VAD (WebRTC) behind the same interface, and a neural provider
   behind `MusicGeneratorProvider` for A/B quality comparison, keeping the symbolic path for stems.
